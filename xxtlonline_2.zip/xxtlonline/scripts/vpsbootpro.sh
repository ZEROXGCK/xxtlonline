#!/bin/bash
# ══════════════════════════════════════════════════════════════════
# xxtlonline-tune (อิงจาก VPSBOOTPRO.sh — Chaiyakey99/chaiya-vpn)
# จูนเครือข่าย VPS: BBR + FQ + MTU Probing + RPS/RFS + IRQ pinning ฯลฯ
#
# ใช้งาน:
#   sudo xxtlonline-tune            จูน (รันซ้ำได้ — idempotent)
#   sudo xxtlonline-tune --remove   ยกเลิกค่าที่สคริปต์นี้ตั้งไว้ทั้งหมด
#
# หมายเหตุ: ขั้นตอนสุดท้ายจะ restart บริการ tunnel ชั่วครู่ (ผู้ใช้ที่ต่ออยู่จะหลุดแล้วต่อใหม่)
# ══════════════════════════════════════════════════════════════════

set -e

if [ "$EUID" -ne 0 ]; then
  echo "ERROR: ต้องรันด้วย root (sudo)"
  exit 1
fi

SYSCTL_FILE="/etc/sysctl.d/99-vps-network-tune.conf"
SCRIPT_PATH="/usr/local/sbin/vps-rps-apply.sh"
TUNE_SERVICES="dropbear.service xxtlonline-dropbear.service xxtlonline-ws.service xxtlonline-udpgw.service xxtlonline-dash.service chaiya-badvpn.service chaiya-sshws.service chaiya-ssh-api.service x-ui.service"

# ── โหมดยกเลิก ──
if [ "${1:-}" = "--remove" ]; then
  echo "== ยกเลิกค่าจูนเครือข่าย =="
  for u in vps-rps-tune vps-cpu-governor vps-irq-pin vps-disable-thp; do
    systemctl disable --now "$u.service" >/dev/null 2>&1 || true
    rm -f "/etc/systemd/system/$u.service"
  done
  rm -f /usr/local/sbin/vps-rps-apply.sh /usr/local/sbin/vps-irq-pin.sh /usr/local/sbin/vps-disable-thp.sh
  rm -f "$SYSCTL_FILE" /etc/security/limits.d/99-vps-network-tune.conf /etc/systemd/system.conf.d/99-nofile.conf
  rm -rf /etc/systemd/system/irqbalance.service.d
  for svc in $TUNE_SERVICES; do rm -rf "/etc/systemd/system/${svc}.d/priority.conf"; rmdir "/etc/systemd/system/${svc}.d" 2>/dev/null || true; done
  systemctl daemon-reload || true
  sysctl --system >/dev/null 2>&1 || true
  echo "✅ ลบไฟล์ตั้งค่าแล้ว — ค่าที่ใช้อยู่ใน kernel/NIC จะกลับเป็นค่าเดิมหลังรีบูต (แนะนำให้รีบูตหนึ่งครั้ง)"
  exit 0
fi

echo "════════════════════════════════════════"
echo "  VPS Network Tuning"
echo "════════════════════════════════════════"

# ── เครื่องมือที่ต้องใช้ ──
if command -v apt-get >/dev/null 2>&1; then
  apt-get install -y -qq ethtool iproute2 python3 >/dev/null 2>&1 || true
fi

# ── ตรวจจับ interface หลักอัตโนมัติ ──
IFACE=$(ip route show default | awk '/default/ {print $5; exit}')
if [ -z "$IFACE" ]; then
  echo "ERROR: หา default network interface ไม่เจอ"
  exit 1
fi
echo "== Interface: $IFACE"

NCPU=$(nproc)
echo "== CPU cores: $NCPU"

# hex mask สำหรับ RPS (ครบทุกคอร์ เช่น 4 core -> f)
RPS_MASK=$(python3 -c "print(format((1 << $NCPU) - 1, 'x'))")
echo "== RPS CPU mask: $RPS_MASK"

# ══════════════════════════════════════════
# 1. sysctl
# ══════════════════════════════════════════
echo ""
echo "== [1/18] ตั้งค่า sysctl (BBR + FQ + MTU Probing + buffer + keepalive) =="

cp -f "$SYSCTL_FILE" "${SYSCTL_FILE}.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null || true

cat > "$SYSCTL_FILE" << 'SYSEOF'
# xxtlonline-tune — BBR + FQ + MTU Probing profile (v3)
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
net.ipv4.tcp_mtu_probing = 1
net.core.netdev_max_backlog = 4096
net.ipv4.tcp_slow_start_after_idle = 0
net.core.rps_sock_flow_entries = 32768
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_ecn = 1
net.core.somaxconn = 8192
net.ipv4.tcp_max_syn_backlog = 8192

# ── TCP buffer ──
net.core.rmem_max = 67108864
net.core.wmem_max = 67108864
net.core.rmem_default = 4194304
net.core.wmem_default = 4194304
net.ipv4.tcp_rmem = 4096 4194304 67108864
net.ipv4.tcp_wmem = 4096 4194304 67108864
net.ipv4.tcp_adv_win_scale = -2
net.ipv4.tcp_window_scaling = 1
net.ipv4.tcp_moderate_rcvbuf = 1

# ── ลด latency จาก buffering ──
net.ipv4.tcp_notsent_lowat = 131072

# ── connection เปิด/ปิดถี่ ──
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 15
net.ipv4.tcp_keepalive_time = 60
net.ipv4.tcp_keepalive_intvl = 10
net.ipv4.tcp_keepalive_probes = 4

# ── file descriptor / port range ──
fs.file-max = 2097152
net.ipv4.ip_local_port_range = 1024 65535
SYSEOF

sysctl --system > /dev/null 2>&1 || true
echo "[OK] sysctl applied"
sysctl net.core.default_qdisc net.ipv4.tcp_congestion_control net.ipv4.tcp_mtu_probing net.core.netdev_max_backlog net.core.rmem_max net.core.wmem_max net.ipv4.tcp_notsent_lowat net.ipv4.tcp_tw_reuse

# ══════════════════════════════════════════
# 2. qdisc = fq
# ══════════════════════════════════════════
echo ""
echo "== [2/18] ตั้ง qdisc ของ $IFACE เป็น fq =="
CURRENT_QDISC=$(tc qdisc show dev "$IFACE" | head -1 | awk '{print $2}')
if [ "$CURRENT_QDISC" = "fq" ]; then
  echo "[SKIP] qdisc เป็น fq อยู่แล้ว"
else
  tc qdisc replace dev "$IFACE" root fq
  echo "[OK] เปลี่ยน qdisc เป็น fq แล้ว"
fi

# ══════════════════════════════════════════
# 3. RPS/RFS
# ══════════════════════════════════════════
echo ""
echo "== [3/18] เปิด RPS/RFS บนทุก RX queue ของ $IFACE =="

RXQ_DIR="/sys/class/net/$IFACE/queues"
if [ ! -d "$RXQ_DIR" ]; then
  echo "WARN: ไม่พบ $RXQ_DIR — ข้าม RPS/RFS"
else
  for rx in "$RXQ_DIR"/rx-*; do
    if [ -f "$rx/rps_cpus" ]; then
      echo "$RPS_MASK" > "$rx/rps_cpus"
      echo "32768" > "$rx/rps_flow_cnt" 2>/dev/null || true
      echo "[OK] $(basename "$rx"): rps_cpus=$RPS_MASK"
    fi
  done
fi

SERVICE_FILE="/etc/systemd/system/vps-rps-tune.service"

cat > "$SCRIPT_PATH" << SCRIPTEOF
#!/bin/bash
IFACE="$IFACE"
RPS_MASK="$RPS_MASK"
for rx in /sys/class/net/\$IFACE/queues/rx-*; do
  [ -f "\$rx/rps_cpus" ] && echo "\$RPS_MASK" > "\$rx/rps_cpus"
  [ -f "\$rx/rps_flow_cnt" ] && echo "32768" > "\$rx/rps_flow_cnt"
done
tc qdisc replace dev "\$IFACE" root fq 2>/dev/null || true
SCRIPTEOF
chmod +x "$SCRIPT_PATH"

cat > "$SERVICE_FILE" << 'UNITEOF'
[Unit]
Description=Apply RPS/RFS and qdisc tuning after boot
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/vps-rps-apply.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
UNITEOF

systemctl daemon-reload
systemctl enable vps-rps-tune.service > /dev/null 2>&1
systemctl restart vps-rps-tune.service
echo "[OK] vps-rps-tune.service ติดตั้งและ enable แล้ว"

# ══════════════════════════════════════════
# 4. ring buffer + txqueuelen
# ══════════════════════════════════════════
echo ""
echo "== [4/18] เพิ่ม ring buffer / txqueuelen ของ $IFACE =="

if command -v ethtool &>/dev/null; then
  MAX_RX=$(ethtool -g "$IFACE" 2>/dev/null | awk '/^RX:/{print $2; exit}')
  MAX_TX=$(ethtool -g "$IFACE" 2>/dev/null | awk '/^TX:/{print $2; exit}')
  if [ -n "$MAX_RX" ] && [ "$MAX_RX" != "n/a" ]; then
    ethtool -G "$IFACE" rx "$MAX_RX" tx "${MAX_TX:-$MAX_RX}" 2>/dev/null \
      && echo "[OK] ตั้ง ring buffer rx=$MAX_RX tx=${MAX_TX:-$MAX_RX}" \
      || echo "WARN: NIC นี้ (มักเป็น virtio) ไม่รองรับปรับ ring buffer — ข้าม"
  else
    echo "SKIP: ethtool อ่านค่า ring buffer ไม่ได้ (ปกติสำหรับ virtio-net) — ข้าม"
  fi
else
  echo "SKIP: ไม่พบ ethtool"
fi

ip link set dev "$IFACE" txqueuelen 10000 2>/dev/null \
  && echo "[OK] ตั้ง txqueuelen=10000" \
  || echo "WARN: ตั้ง txqueuelen ไม่สำเร็จ"

if ! grep -q "txqueuelen" "$SCRIPT_PATH" 2>/dev/null; then
  cat >> "$SCRIPT_PATH" << 'TXQEOF'
ip link set dev "$IFACE" txqueuelen 10000 2>/dev/null || true
TXQEOF
  echo "[OK] เพิ่ม txqueuelen persist เข้า boot script แล้ว"
fi

# ══════════════════════════════════════════
# 5. initcwnd / initrwnd
# ══════════════════════════════════════════
echo ""
echo "== [5/18] ตั้ง initcwnd/initrwnd = 20 บน default route =="

DEFAULT_ROUTE_LINE=$(ip route show default | head -1)
if [ -z "$DEFAULT_ROUTE_LINE" ]; then
  echo "WARN: ไม่พบ default route — ข้าม"
elif echo "$DEFAULT_ROUTE_LINE" | grep -q "initcwnd 20"; then
  echo "[SKIP] initcwnd ตั้งไว้แล้ว"
else
  BASE_ROUTE=$(echo "$DEFAULT_ROUTE_LINE" | sed -E 's/ initcwnd [0-9]+//; s/ initrwnd [0-9]+//')
  if ip route change $BASE_ROUTE initcwnd 20 initrwnd 20 2>/dev/null; then
    echo "[OK] initcwnd/initrwnd = 20 ตั้งแล้ว"
  else
    echo "WARN: ตั้ง initcwnd ไม่สำเร็จ (ไม่กระทบระบบหลัก)"
  fi
fi

if ! grep -q "initcwnd" "$SCRIPT_PATH" 2>/dev/null; then
  cat >> "$SCRIPT_PATH" << 'ROUTEEOF'
_dr=$(ip route show default | head -1 | sed -E 's/ initcwnd [0-9]+//; s/ initrwnd [0-9]+//')
[ -n "$_dr" ] && ip route change $_dr initcwnd 20 initrwnd 20 2>/dev/null || true
ROUTEEOF
  echo "[OK] เพิ่ม initcwnd persist เข้า boot script แล้ว"
fi

# ══════════════════════════════════════════
# 6. CPU governor
# ══════════════════════════════════════════
echo ""
echo "== [6/18] ตั้ง CPU governor เป็น performance =="

GOV_DIR="/sys/devices/system/cpu/cpu0/cpufreq"
if [ -f "$GOV_DIR/scaling_governor" ]; then
  for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo "performance" > "$gov" 2>/dev/null || true
  done
  echo "[OK] ตั้ง governor เป็น performance ทุกคอร์"

  cat > /etc/systemd/system/vps-cpu-governor.service << 'GOVEOF'
[Unit]
Description=Set CPU governor to performance
After=multi-user.target

[Service]
Type=oneshot
ExecStart=/bin/sh -c 'for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo performance > $g 2>/dev/null || true; done'
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
GOVEOF
  systemctl daemon-reload
  systemctl enable vps-cpu-governor.service > /dev/null 2>&1
  echo "[OK] ตั้ง persist governor หลังรีบูตแล้ว"
else
  echo "SKIP: VPS นี้ไม่มี cpufreq governor ให้ตั้ง (ปกติสำหรับ KVM/virtio)"
fi

# ══════════════════════════════════════════
# 7. file descriptor limit
# ══════════════════════════════════════════
echo ""
echo "== [7/18] เพิ่ม file descriptor limit (ulimit) =="

LIMITS_FILE="/etc/security/limits.d/99-vps-network-tune.conf"
cat > "$LIMITS_FILE" << 'LIMEOF'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
LIMEOF
echo "[OK] ตั้ง nofile=1048576 ใน $LIMITS_FILE"

mkdir -p /etc/systemd/system.conf.d
cat > /etc/systemd/system.conf.d/99-nofile.conf << 'SYSDEOF'
[Manager]
DefaultLimitNOFILE=1048576
SYSDEOF
systemctl daemon-reexec 2>/dev/null || true
echo "[OK] ตั้ง DefaultLimitNOFILE ระดับ systemd แล้ว"

# ══════════════════════════════════════════
# 8. Path MTU (diagnostic)
# ══════════════════════════════════════════
echo ""
echo "== [8/18] ตรวจสอบ Path MTU (diagnostic) =="
CURRENT_MTU=$(cat /sys/class/net/"$IFACE"/mtu 2>/dev/null || echo "?")
echo "MTU ปัจจุบันของ $IFACE: $CURRENT_MTU"
GW=$(ip route show default | awk '/default/ {print $3; exit}')
if [ -n "$GW" ] && command -v ping &>/dev/null; then
  if ping -M do -s 1472 -c 2 -W 2 "$GW" &>/dev/null; then
    echo "[OK] MTU 1500 ไป gateway ผ่านปกติ"
  else
    echo "WARN: ping ขนาด 1472 bytes ไป gateway ไม่ผ่าน — อาจมี PMTU ต่ำกว่า 1500 (เช็คเพิ่มด้วย tracepath)"
  fi
else
  echo "SKIP: หา default gateway ไม่เจอ หรือไม่มีคำสั่ง ping"
fi

# ══════════════════════════════════════════
# 9. irqbalance
# ══════════════════════════════════════════
echo ""
echo "== [9/18] เปิด irqbalance =="
if command -v irqbalance &>/dev/null; then
  echo "[SKIP] irqbalance ติดตั้งอยู่แล้ว"
else
  apt-get install -y irqbalance -q > /dev/null 2>&1
  echo "[OK] ติดตั้ง irqbalance แล้ว"
fi
systemctl enable irqbalance > /dev/null 2>&1
systemctl restart irqbalance
echo "[OK] irqbalance active"

# ══════════════════════════════════════════
# 10. NIC multiqueue + XPS
# ══════════════════════════════════════════
echo ""
echo "== [10/18] เปิด multiqueue บน $IFACE (combined=$NCPU) =="

MQ_SUPPORTED=0
if command -v ethtool &>/dev/null; then
  MAX_COMBINED=$(ethtool -l "$IFACE" 2>/dev/null | awk '/Pre-set maximums:/{f=1;next} f && /Combined:/{print $2; exit}')
  if [ -n "$MAX_COMBINED" ] && [ "$MAX_COMBINED" -gt 1 ] 2>/dev/null; then
    MQ_SUPPORTED=1
    TARGET=$NCPU
    [ "$TARGET" -gt "$MAX_COMBINED" ] && TARGET=$MAX_COMBINED
    if ethtool -L "$IFACE" combined "$TARGET" 2>/dev/null; then
      echo "[OK] ตั้ง combined queues = $TARGET (max รองรับ $MAX_COMBINED)"
    else
      MQ_SUPPORTED=0
      echo "WARN: apply ไม่ผ่าน — ข้าม (VPS นี้อาจ fix คิวไว้ที่ hypervisor)"
    fi
  else
    echo "SKIP: NIC นี้รองรับคิวเดียว (Combined max=${MAX_COMBINED:-1}) — ใช้ RPS/RFS แทน (ทำแล้วใน step 3)"
  fi
else
  echo "SKIP: ไม่พบ ethtool"
fi

if [ "$MQ_SUPPORTED" -eq 1 ]; then
  echo "== ตั้ง XPS (TX queue -> CPU แบบ 1:1) =="
  i=0
  for txq in "$RXQ_DIR"/tx-*; do
    if [ -f "$txq/xps_cpus" ]; then
      CPU_MASK=$(python3 -c "print(format(1 << ($i % $NCPU), 'x'))")
      echo "$CPU_MASK" > "$txq/xps_cpus" 2>/dev/null || true
      echo "[OK] $(basename "$txq"): xps_cpus=$CPU_MASK"
      i=$((i+1))
    fi
  done
  if ! grep -q "xps_cpus" "$SCRIPT_PATH" 2>/dev/null; then
    cat >> "$SCRIPT_PATH" << XPSEOF
ethtool -L "\$IFACE" combined $NCPU 2>/dev/null || true
i=0
for txq in /sys/class/net/\$IFACE/queues/tx-*; do
  [ -f "\$txq/xps_cpus" ] && echo "\$(python3 -c "print(format(1 << (\$i % $NCPU), 'x'))")" > "\$txq/xps_cpus"
  i=\$((i+1))
done
XPSEOF
    echo "[OK] เพิ่ม multiqueue+XPS persist เข้า boot script แล้ว"
  fi
else
  echo "[SKIP] ไม่เปิด XPS เพราะ NIC ไม่รองรับ multiqueue"
fi

# ══════════════════════════════════════════
# 11. offload
# ══════════════════════════════════════════
echo ""
echo "== [11/18] ตรวจสอบ/เปิด GRO/GSO/TSO บน $IFACE =="
if command -v ethtool &>/dev/null; then
  for feat in gro gso tso; do
    STATE=$(ethtool -k "$IFACE" 2>/dev/null | awk -v f="$feat" '$0 ~ "^"f":" {print $2; exit}')
    if [ "$STATE" = "off" ]; then
      ethtool -K "$IFACE" "$feat" on 2>/dev/null \
        && echo "[OK] เปิด $feat" \
        || echo "WARN: เปิด $feat ไม่สำเร็จ"
    else
      echo "[SKIP] $feat เปิดอยู่แล้ว (หรือ NIC ไม่รองรับ)"
    fi
  done
else
  echo "SKIP: ไม่พบ ethtool"
fi

# ══════════════════════════════════════════
# 12. netdev_budget
# ══════════════════════════════════════════
echo ""
echo "== [12/18] ตั้ง net.core.netdev_budget / netdev_budget_usecs =="
if ! grep -q "netdev_budget" "$SYSCTL_FILE" 2>/dev/null; then
  cat >> "$SYSCTL_FILE" << BUDEOF

# ── NAPI budget ต่อรอบ ──
net.core.netdev_budget = 600
net.core.netdev_budget_usecs = 8000
BUDEOF
  sysctl --system > /dev/null 2>&1 || true
  echo "[OK] ตั้ง netdev_budget=600, netdev_budget_usecs=8000"
else
  echo "[SKIP] ตั้งไว้แล้ว"
fi

# ══════════════════════════════════════════
# 13. ตรึง IRQ affinity
# ══════════════════════════════════════════
echo ""
echo "== [13/18] ตรึง NIC IRQ เข้าคอร์คงที่ 1:1 + กัน irqbalance ยุ่งกับคิวเครือข่าย =="

NIC_IRQS=""
MSI_DIR="/sys/class/net/$IFACE/device/msi_irqs"
if [ -d "$MSI_DIR" ] && [ -n "$(ls -A "$MSI_DIR" 2>/dev/null)" ]; then
  NIC_IRQS=$(ls "$MSI_DIR")
  echo "[INFO] หา IRQ จาก $MSI_DIR ได้: $NIC_IRQS"
else
  VIRTIO_DEV=$(basename "$(readlink -f /sys/class/net/"$IFACE"/device 2>/dev/null)" 2>/dev/null)
  if [ -n "$VIRTIO_DEV" ] && grep -q "$VIRTIO_DEV" /proc/interrupts 2>/dev/null; then
    NIC_IRQS=$(grep -E "$VIRTIO_DEV" /proc/interrupts | awk -F: '{print $1}' | tr -d ' ')
    echo "[INFO] หา IRQ จาก /proc/interrupts ผ่านชื่อ device $VIRTIO_DEV ได้: $NIC_IRQS"
  else
    NIC_IRQS=$(grep -E "$IFACE" /proc/interrupts | awk -F: '{print $1}' | tr -d ' ')
  fi
fi
if [ -n "$NIC_IRQS" ]; then
  i=0
  for irq in $NIC_IRQS; do
    CPU=$((i % NCPU))
    if [ -f "/proc/irq/$irq/smp_affinity_list" ]; then
      echo "$CPU" > "/proc/irq/$irq/smp_affinity_list" 2>/dev/null \
        && echo "[OK] irq $irq -> cpu $CPU" \
        || echo "WARN: ตรึง irq $irq ไม่สำเร็จ (อาจถูกล็อกโดย kernel/managed_irq)"
      i=$((i+1))
    fi
  done

  if irqbalance --help 2>&1 | grep -q banirq; then
    BAN_ARGS=""
    for irq in $NIC_IRQS; do BAN_ARGS="$BAN_ARGS --banirq=$irq"; done
    mkdir -p /etc/systemd/system/irqbalance.service.d
    cat > /etc/systemd/system/irqbalance.service.d/override.conf << IRQEOF
[Service]
ExecStart=
ExecStart=/usr/sbin/irqbalance --foreground$BAN_ARGS
IRQEOF
    systemctl daemon-reload
    systemctl restart irqbalance
    echo "[OK] แบน NIC IRQ ออกจาก irqbalance แล้ว"
  else
    systemctl stop irqbalance 2>/dev/null
    systemctl disable irqbalance 2>/dev/null
    echo "[OK] irqbalance รุ่นนี้ไม่รองรับ --banirq เลยปิดไป ใช้ affinity คงที่แทน"
  fi

  cat > /usr/local/sbin/vps-irq-pin.sh << PINEOF
#!/bin/bash
IFACE="$IFACE"
NCPU=$NCPU
MSI_DIR="/sys/class/net/\$IFACE/device/msi_irqs"
if [ -d "\$MSI_DIR" ] && [ -n "\$(ls -A "\$MSI_DIR" 2>/dev/null)" ]; then
  IRQ_LIST=\$(ls "\$MSI_DIR")
else
  VIRTIO_DEV=\$(basename "\$(readlink -f /sys/class/net/"\$IFACE"/device 2>/dev/null)" 2>/dev/null)
  if [ -n "\$VIRTIO_DEV" ] && grep -q "\$VIRTIO_DEV" /proc/interrupts 2>/dev/null; then
    IRQ_LIST=\$(grep -E "\$VIRTIO_DEV" /proc/interrupts | awk -F: '{print \$1}' | tr -d ' ')
  else
    IRQ_LIST=\$(grep -E "\$IFACE" /proc/interrupts | awk -F: '{print \$1}' | tr -d ' ')
  fi
fi
i=0
for irq in \$IRQ_LIST; do
  CPU=\$((i % NCPU))
  [ -f "/proc/irq/\$irq/smp_affinity_list" ] && echo "\$CPU" > "/proc/irq/\$irq/smp_affinity_list" 2>/dev/null
  i=\$((i+1))
done
PINEOF
  chmod +x /usr/local/sbin/vps-irq-pin.sh
  cat > /etc/systemd/system/vps-irq-pin.service << SVCEOF
[Unit]
Description=Pin NIC IRQs to fixed CPUs (ping jitter fix)
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/vps-irq-pin.sh

[Install]
WantedBy=multi-user.target
SVCEOF
  systemctl daemon-reload
  systemctl enable vps-irq-pin.service > /dev/null 2>&1
  echo "[OK] ตั้ง vps-irq-pin.service ให้ตรึง IRQ ใหม่ทุกครั้งที่บูตแล้ว"
else
  echo "SKIP: หา NIC IRQ ของ $IFACE ไม่เจอใน /proc/interrupts"
fi

# ══════════════════════════════════════════
# 14. interrupt coalescing
# ══════════════════════════════════════════
echo ""
echo "== [14/18] ตั้ง interrupt coalescing ต่ำสุด (adaptive off, rx/tx-usecs=0) =="
if command -v ethtool &>/dev/null; then
  ethtool -C "$IFACE" adaptive-rx off adaptive-tx off 2>/dev/null || true
  if ethtool -C "$IFACE" rx-usecs 0 tx-usecs 0 2>/dev/null; then
    echo "[OK] coalescing rx-usecs=0 tx-usecs=0"
  elif ethtool -C "$IFACE" rx-usecs 1 tx-usecs 1 2>/dev/null; then
    echo "[OK] coalescing rx-usecs=1 tx-usecs=1 (ต่ำสุดที่ NIC นี้รองรับ)"
  else
    echo "SKIP: NIC/hypervisor นี้ไม่ให้ปรับ coalescing"
  fi
else
  echo "SKIP: ไม่พบ ethtool"
fi

# ══════════════════════════════════════════
# 15. TCP idle / fastopen / buffer
# ══════════════════════════════════════════
echo ""
echo "== [15/18] ตั้ง tcp_slow_start_after_idle=0, tcp_fastopen=3, tcp_rmem/tcp_wmem =="
if ! grep -q "tcp_rmem = 4096 87380" "$SYSCTL_FILE" 2>/dev/null; then
  cat >> "$SYSCTL_FILE" << TCPEOF

# ── ลด RTT spike หลัง idle + autotuning window ──
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_rmem = 4096 87380 67108864
net.ipv4.tcp_wmem = 4096 65536 67108864
TCPEOF
  sysctl --system > /dev/null 2>&1 || true
  echo "[OK] ตั้งค่าแล้ว"
else
  echo "[SKIP] ตั้งไว้แล้ว"
fi

# ══════════════════════════════════════════
# 16. ปิด THP
# ══════════════════════════════════════════
echo ""
echo "== [16/18] ปิด THP (transparent hugepage) =="
if [ -f /sys/kernel/mm/transparent_hugepage/enabled ]; then
  echo never > /sys/kernel/mm/transparent_hugepage/enabled 2>/dev/null || true
  echo never > /sys/kernel/mm/transparent_hugepage/defrag 2>/dev/null || true
  echo "[OK] ปิด THP ทันที ($(cat /sys/kernel/mm/transparent_hugepage/enabled 2>/dev/null))"

  cat > /usr/local/sbin/vps-disable-thp.sh << 'THPEOF'
#!/bin/bash
echo never > /sys/kernel/mm/transparent_hugepage/enabled 2>/dev/null
echo never > /sys/kernel/mm/transparent_hugepage/defrag 2>/dev/null
THPEOF
  chmod +x /usr/local/sbin/vps-disable-thp.sh
  cat > /etc/systemd/system/vps-disable-thp.service << 'THPSVCEOF'
[Unit]
Description=Disable Transparent Huge Pages (latency stability)
After=sysinit.target
Before=basic.target

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/vps-disable-thp.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
THPSVCEOF
  systemctl daemon-reload
  systemctl enable vps-disable-thp.service > /dev/null 2>&1
  echo "[OK] ตั้ง vps-disable-thp.service แล้ว"
else
  echo "SKIP: kernel นี้ไม่มี THP ให้ปิด"
fi

# ══════════════════════════════════════════
# 17. conntrack
# ══════════════════════════════════════════
echo ""
echo "== [17/18] ขยาย nf_conntrack_max และลด timeout ของ session ที่ไม่ active =="
if [ -f /proc/sys/net/netfilter/nf_conntrack_max ] || sysctl net.netfilter.nf_conntrack_max &>/dev/null; then
  if ! grep -q "nf_conntrack_max" "$SYSCTL_FILE" 2>/dev/null; then
    cat >> "$SYSCTL_FILE" << CTEOF

# ── รองรับ connection พร้อมกันได้เยอะขึ้น ──
net.netfilter.nf_conntrack_max = 1048576
net.netfilter.nf_conntrack_tcp_timeout_established = 86400
net.netfilter.nf_conntrack_udp_timeout = 60
net.netfilter.nf_conntrack_udp_timeout_stream = 180
CTEOF
    sysctl --system > /dev/null 2>&1 || true
    CT_HASHSIZE_PATH="/sys/module/nf_conntrack/parameters/hashsize"
    if [ -w "$CT_HASHSIZE_PATH" ]; then
      echo 262144 > "$CT_HASHSIZE_PATH" 2>/dev/null && echo "[OK] ตั้ง hashsize=262144"
    fi
    echo "[OK] ตั้ง nf_conntrack_max=1048576"
  else
    echo "[SKIP] ตั้งไว้แล้ว"
  fi
else
  echo "SKIP: nf_conntrack module ไม่ได้โหลด — ข้ามได้ปลอดภัย"
fi

# ══════════════════════════════════════════
# 18. Nice priority ของ service tunnel
# ══════════════════════════════════════════
echo ""
echo "== [18/18] ตั้ง Nice=-10 ให้ service tunnel (dropbear / xxtlonline-* / badvpn / x-ui) =="
for svc in $TUNE_SERVICES; do
  if systemctl list-unit-files 2>/dev/null | grep -q "^${svc}"; then
    mkdir -p "/etc/systemd/system/${svc}.d"
    cat > "/etc/systemd/system/${svc}.d/priority.conf" << PRIOEOF
[Service]
Nice=-10
PRIOEOF
    echo "[OK] $svc: Nice=-10"
  else
    echo "[SKIP] $svc: ไม่มี unit นี้บนเครื่อง"
  fi
done
systemctl daemon-reload || true
for svc in $TUNE_SERVICES; do
  if systemctl is-active "$svc" &>/dev/null; then
    systemctl restart "$svc" 2>/dev/null || true
  fi
done
echo "[OK] restart service ที่เกี่ยวข้องให้ priority มีผลแล้ว"

# ══════════════════════════════════════════
# ตรวจสอบผลลัพธ์ (diagnostic)
# ══════════════════════════════════════════
set +e
echo ""
echo "════════════════════════════════════════"
echo "  ตรวจสอบผล"
echo "════════════════════════════════════════"
echo "-- sysctl --"
sysctl net.core.default_qdisc net.ipv4.tcp_congestion_control net.ipv4.tcp_mtu_probing net.ipv4.tcp_slow_start_after_idle net.ipv4.tcp_fastopen net.core.rmem_max net.core.wmem_max net.core.netdev_budget

echo ""
echo "-- default route --"
ip route show default

echo ""
echo "-- qdisc ($IFACE) --"
tc qdisc show dev "$IFACE"

echo ""
echo "-- RPS cpus ($IFACE) --"
for rx in /sys/class/net/"$IFACE"/queues/rx-*; do
  [ -f "$rx/rps_cpus" ] && echo "$(basename "$rx"): $(cat "$rx/rps_cpus")"
done

echo ""
echo "-- multiqueue --"
ethtool -l "$IFACE" 2>/dev/null | grep -A5 "^Current hardware settings:" || echo "(ethtool ไม่รองรับ/ไม่มีข้อมูล)"

echo ""
echo "-- THP --"
cat /sys/kernel/mm/transparent_hugepage/enabled 2>/dev/null

echo ""
echo "-- conntrack --"
sysctl net.netfilter.nf_conntrack_max 2>/dev/null || echo "(module ไม่โหลด)"

echo ""
echo "-- service priority (nice) --"
for svc in $TUNE_SERVICES; do
  PID=$(systemctl show -p MainPID --value "$svc" 2>/dev/null)
  [ -n "$PID" ] && [ "$PID" != "0" ] && echo "$svc (pid $PID): nice=$(ps -o ni= -p "$PID" 2>/dev/null | tr -d ' ')"
done

echo ""
echo "✅ จูนเสร็จสิ้น — ค่าทั้งหมด persist หลังรีบูตแล้ว (ยกเลิกได้ด้วย: sudo xxtlonline-tune --remove)"
