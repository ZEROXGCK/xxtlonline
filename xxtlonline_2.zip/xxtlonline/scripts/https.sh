#!/bin/bash
# ============================================================
#  xxtlonline-https — เปิดแดชบอร์ดผ่าน https://โดเมน (nginx + Let's Encrypt)
#  ใช้:  sudo xxtlonline-https                       (ถามโดเมน/อีเมล)
#        sudo xxtlonline-https --domain panel.example.com --email me@example.com
#
#  พอร์ต 80 ถูกใช้โดย WS proxy ของ xxtlonline → nginx ฟังแค่ 443
#  ตอนขอ/ต่ออายุใบรับรองจะหยุด WS proxy ชั่วคราว (~10-20 วินาที) แล้วเปิดกลับเอง
# ============================================================
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo "ต้องรันด้วย root (sudo)"; exit 1; }

DOMAIN=""; EMAIL=""
while [[ $# -gt 0 ]]; do
  case $1 in
    --domain) DOMAIN=${2:-}; shift 2 ;;
    --email)  EMAIL=${2:-};  shift 2 ;;
    *) echo "ไม่รู้จักตัวเลือก: $1"; exit 1 ;;
  esac
done

[[ -f /opt/xxtlonline-dash/app.py ]] || { echo "ยังไม่ได้ติดตั้งแดชบอร์ด (ติดตั้งโดยไม่ใส่ --no-dashboard)"; exit 1; }
systemctl is-active --quiet xxtlonline-dash || { echo "บริการ xxtlonline-dash ไม่ทำงาน"; exit 1; }

if [[ -z $DOMAIN ]]; then read -rp "โดเมน (เช่น panel.example.com): " DOMAIN; fi
DOMAIN=$(echo "$DOMAIN" | tr 'A-Z' 'a-z' | sed 's|^https\?://||; s|/.*$||')
[[ $DOMAIN =~ ^[a-z0-9]([a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}$ ]] || { echo "รูปแบบโดเมนไม่ถูกต้อง"; exit 1; }
if [[ -z $EMAIL && -t 0 ]]; then read -rp "อีเมลแจ้งเตือนใบรับรองหมดอายุ (เว้นว่างได้): " EMAIL; fi
if [[ -n $EMAIL && ! $EMAIL =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
  echo "รูปแบบอีเมลไม่ถูกต้อง"; exit 1
fi

IP=$(curl -s4 --max-time 5 https://api.ipify.org || hostname -I | awk '{print $1}')
DNS_IP=$(getent ahostsv4 "$DOMAIN" | awk '{print $1; exit}' || true)
if [[ "$DNS_IP" != "$IP" ]]; then
  echo "DNS ของ $DOMAIN ชี้ไปที่ '${DNS_IP:-ไม่พบ}' แต่เซิร์ฟเวอร์นี้คือ $IP"
  echo "ตั้ง A record ให้ชี้มาที่ $IP ก่อน แล้วรันใหม่ (ถ้าใช้ Cloudflare ให้ปิดพร็อกซี/เมฆส้มไว้ก่อน)"
  exit 1
fi

echo "[1/5] ติดตั้ง nginx + certbot..."
apt-get update -qq
# กัน nginx ที่เพิ่งติดตั้งไปแย่งพอร์ต 80 จาก WS proxy
printf '#!/bin/sh\nexit 101\n' > /usr/sbin/policy-rc.d; chmod +x /usr/sbin/policy-rc.d
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq nginx certbot >/dev/null
rm -f /usr/sbin/policy-rc.d
systemctl stop nginx 2>/dev/null || true
rm -f /etc/nginx/sites-enabled/default /etc/nginx/conf.d/default.conf

echo "[2/5] ขอใบรับรอง Let's Encrypt (หยุด WS proxy ชั่วคราว)..."
EMAIL_ARGS=(--register-unsafely-without-email)
[[ -n $EMAIL ]] && EMAIL_ARGS=(-m "$EMAIL")
rc=0
certbot certonly --standalone -d "$DOMAIN" --non-interactive --agree-tos "${EMAIL_ARGS[@]}" \
  --pre-hook  "systemctl stop xxtlonline-ws" \
  --post-hook "systemctl start xxtlonline-ws" \
  --deploy-hook "systemctl try-reload-or-restart nginx" || rc=$?
systemctl start xxtlonline-ws 2>/dev/null || true
if [[ $rc -ne 0 ]]; then
  echo "ขอใบรับรองไม่สำเร็จ (ตรวจว่าพอร์ต 80 เปิดจากภายนอก และ DNS ถูกต้อง)"; exit 1
fi

echo "[3/5] ตั้งค่า nginx (พอร์ต 443 → แดชบอร์ด 127.0.0.1:8088)..."
cat > /etc/nginx/conf.d/xxtlonline-dash.conf <<NGX
server {
    listen 443 ssl;
    listen [::]:443 ssl;
    server_name ${DOMAIN};

    ssl_certificate     /etc/letsencrypt/live/${DOMAIN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${DOMAIN}/privkey.pem;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_session_cache   shared:SSL:5m;
    ssl_session_timeout 10m;

    add_header Strict-Transport-Security "max-age=31536000" always;
    client_max_body_size 8k;

    location / {
        proxy_pass http://127.0.0.1:8088;
        proxy_http_version 1.1;
        proxy_set_header Host              \$host;
        proxy_set_header X-Real-IP         \$remote_addr;
        proxy_set_header X-Forwarded-Proto https;
        proxy_read_timeout 30s;
    }
}
NGX
nginx -t

echo "[4/5] ให้แดชบอร์ดรู้จักโดเมน และเปิด firewall 443..."
printf 'XXTLONLINE_DASH_DOMAIN=%s\n' "$DOMAIN" > /etc/xxtlonline/dashboard.env
chmod 600 /etc/xxtlonline/dashboard.env
systemctl daemon-reload
systemctl restart xxtlonline-dash
ufw allow 443/tcp >/dev/null 2>&1 || true

echo "[5/5] เปิด nginx..."
systemctl enable --now nginx >/dev/null 2>&1
systemctl restart nginx
sleep 1

echo
for s in xxtlonline-ws xxtlonline-dash nginx; do printf '   %-14s %s\n' "$s" "$(systemctl is-active $s)"; done
CODE=$(curl -sk -o /dev/null -w '%{http_code}' --resolve "${DOMAIN}:443:127.0.0.1" "https://${DOMAIN}/" || true)
echo "   ทดสอบ https://${DOMAIN}/ → HTTP ${CODE}"
echo
echo "✅ เปิดใช้งานที่  https://${DOMAIN}"
echo "   ใบรับรองต่ออายุอัตโนมัติผ่าน certbot (ตรวจ: sudo certbot renew --dry-run)"
echo "   แนะนำ: ใช้รหัสผ่านแดชบอร์ดที่ยาวและเดายาก เพราะเข้าได้จากอินเทอร์เน็ต"
