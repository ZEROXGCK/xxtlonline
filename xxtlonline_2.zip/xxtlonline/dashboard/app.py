#!/usr/bin/python3
"""xxtlonline-dashboard: เว็บจัดการ user ของ xxtlonline-lite (stdlib ล้วน)"""
import getpass, hashlib, hmac, json, os, re, secrets, shutil, subprocess, sys, time
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

CONF = os.environ.get("XXTLONLINE_DASH_CONF", "/etc/xxtlonline/dashboard.json")
EXP_DIR = os.environ.get("XXTLONLINE_EXP_DIR", "/etc/xxtlonline/exp")
CLI = os.environ.get("XXTLONLINE_CLI", "/usr/local/bin/xxtlonline")
HOST = os.environ.get("XXTLONLINE_DASH_HOST", "127.0.0.1")
PORT = int(os.environ.get("XXTLONLINE_DASH_PORT", "8088"))
DOMAIN = os.environ.get("XXTLONLINE_DASH_DOMAIN", "").strip().lower()   # ตั้งเมื่อใช้งานผ่าน nginx + HTTPS
NPV_CONF = os.environ.get("XXTLONLINE_NPV_CONF", "/etc/xxtlonline/npv.json")
SYS_CONF = os.environ.get("XXTLONLINE_SYS_CONF", "/etc/xxtlonline/xxtlonline.conf")
SUSP_DIR = os.environ.get("XXTLONLINE_SUSP_DIR", "/etc/xxtlonline/susp")
PW_RE = re.compile(r"^[A-Za-z0-9!@#%^&*_+=.,-]{6,64}$")
DEFAULT_NPV = {
    "template": "Host: {host}\nPort: {port}\nUsername: {user}\nPassword: {pass}\nหมดอายุ: {exp}\n"
                "Payload: GET / HTTP/1.1[crlf]Host: {host}[crlf]Upgrade: websocket[crlf][crlf]",
    "host": "", "port": 0, "ext": "txt", "fname": "{user}",
    # ลิงก์ npvt-ssh:// (NPV Tunnel)
    "npv_remarks": "{user}", "npv_proxy": "", "npv_sni": "",
    "npv_payload": "GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf][crlf]",
}
USER_RE = re.compile(r"^[a-z][a-z0-9_-]{2,15}$")
SESSION_TTL = 8 * 3600
sessions = {}   # token -> (expires, csrf)
fails = {}      # ip -> [count, locked_until]


# ---------- password ----------
def hash_pw(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 200_000).hex()

def set_password(from_stdin=False):
    if from_stdin:
        a = sys.stdin.readline().rstrip("\n")
        if len(a) < 8:
            sys.exit("รหัสผ่านต้องยาวอย่างน้อย 8 ตัว")
        return _save_password(a)
    while True:
        a = getpass.getpass("ตั้งรหัสผ่านแดชบอร์ด (อย่างน้อย 8 ตัว): ")
        if len(a) < 8:
            print("สั้นเกินไป"); continue
        if a != getpass.getpass("ยืนยันรหัสผ่าน: "):
            print("ไม่ตรงกัน"); continue
        break
    _save_password(a)

def _save_password(a):
    salt = secrets.token_bytes(16)
    old = os.umask(0o077)
    with open(CONF, "w") as f:
        json.dump({"salt": salt.hex(), "hash": hash_pw(a, salt)}, f)
    os.umask(old)
    print("บันทึกรหัสผ่านแล้ว")

def check_password(pw):
    try:
        c = json.load(open(CONF))
        return hmac.compare_digest(hash_pw(pw, bytes.fromhex(c["salt"])), c["hash"])
    except Exception:
        return False


# ---------- npv / ระบบ ----------
def sys_conf():
    c = {}
    try:
        for line in open(SYS_CONF):
            if "=" in line:
                k, v = line.strip().split("=", 1)
                c[k] = v
    except Exception:
        pass
    return c

_ip = [0.0, ""]
def public_ip():
    if time.time() < _ip[0]:
        return _ip[1]
    ip = ""
    try:
        import urllib.request
        ip = urllib.request.urlopen("https://api.ipify.org", timeout=3).read().decode().strip()
    except Exception:
        try:
            ip = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=3).stdout.split()[0]
        except Exception:
            ip = ""
    _ip[0], _ip[1] = time.time() + (600 if ip else 30), ip
    return ip

def load_npv():
    cfg = dict(DEFAULT_NPV)
    try:
        cfg.update({k: v for k, v in json.load(open(NPV_CONF)).items() if k in DEFAULT_NPV})
    except Exception:
        pass
    return cfg

def npv_view():
    cfg = load_npv()
    ws = int(sys_conf().get("WS_PORT", "80") or 80)
    cfg["host_eff"] = cfg["host"] or DOMAIN or public_ip()
    cfg["port_eff"] = cfg["port"] or ws
    cfg["udp_port"] = int(sys_conf().get("UDPGW_PORT", "7300") or 7300)
    return cfg

def save_npv(b):
    t = str(b.get("template", ""))
    host = str(b.get("host", "")).strip()
    ext = str(b.get("ext", "txt")).strip().lstrip(".")
    fname = str(b.get("fname", "{user}")).strip()
    try:
        port = int(b.get("port") or 0)
    except Exception:
        return "พอร์ตไม่ถูกต้อง"
    if not 1 <= len(t) <= 4000: return "รูปแบบข้อความต้องยาว 1-4000 ตัวอักษร"
    if host and not re.match(r"^[A-Za-z0-9.-]{1,253}$", host): return "host ไม่ถูกต้อง"
    if not 0 <= port <= 65535: return "พอร์ตไม่ถูกต้อง"
    if not re.match(r"^[A-Za-z0-9]{1,8}$", ext): return "นามสกุลไฟล์ใช้ a-z 0-9 ยาวไม่เกิน 8"
    if not re.match(r"^[A-Za-z0-9_.{}-]{1,40}$", fname): return "ชื่อไฟล์ใช้ได้เฉพาะ a-z 0-9 _ . - และ {user}"
    remarks = str(b.get("npv_remarks", "{user}")).strip()
    proxy = str(b.get("npv_proxy", "")).strip()
    sni = str(b.get("npv_sni", "")).strip()
    payload = str(b.get("npv_payload", DEFAULT_NPV["npv_payload"]))
    if not 1 <= len(remarks) <= 60: return "ชื่อโปรไฟล์ต้องยาว 1-60 ตัวอักษร"
    if proxy and not re.match(r"^[A-Za-z0-9.-]{1,253}:[0-9]{1,5}$", proxy): return "HTTP proxy ต้องเป็นรูปแบบ host:port หรือเว้นว่าง"
    if sni and not re.match(r"^[A-Za-z0-9.-]{1,253}$", sni): return "SNI ไม่ถูกต้อง"
    if not 1 <= len(payload) <= 2000: return "payload ต้องยาว 1-2000 ตัวอักษร"
    old = os.umask(0o077)
    with open(NPV_CONF, "w") as f:
        json.dump({"template": t, "host": host, "port": port, "ext": ext, "fname": fname,
                   "npv_remarks": remarks, "npv_proxy": proxy, "npv_sni": sni, "npv_payload": payload}, f)
    os.umask(old)
    return None

def user_exp(u):
    try:
        return open(os.path.join(EXP_DIR, u)).read().strip()
    except Exception:
        return ""

# ---------- data ----------
def run_cli(*args):
    try:
        r = subprocess.run([CLI, *args], capture_output=True, text=True, timeout=20)
        return r.returncode == 0, (r.stdout + r.stderr).strip()
    except Exception as e:
        return False, str(e)

def online_counts():
    counts = {}
    try:
        out = subprocess.run(["ps", "-eo", "user:32=,comm="], capture_output=True,
                             text=True, timeout=5).stdout
        for line in out.splitlines():
            p = line.split()
            if len(p) == 2 and p[1] in ("dropbear", "sshd") and p[0] != "root":
                counts[p[0]] = counts.get(p[0], 0) + 1
    except Exception:
        pass
    return counts

def list_users():
    today = time.strftime("%Y-%m-%d")
    online = online_counts()
    users = []
    try:
        names = sorted(os.listdir(EXP_DIR))
    except Exception:
        names = []
    for n in names:
        if not USER_RE.match(n):
            continue
        try:
            exp = open(os.path.join(EXP_DIR, n)).read().strip()
        except Exception:
            continue
        users.append({"user": n, "exp": exp, "expired": exp < today, "online": online.get(n, 0),
                      "suspended": os.path.exists(os.path.join(SUSP_DIR, n))})
    return users

def service_state(name):
    r = subprocess.run(["systemctl", "is-active", name], capture_output=True, text=True)
    return r.stdout.strip() == "active"

def stats():
    mem = {}
    for line in open("/proc/meminfo"):
        k, v = line.split(":")
        mem[k] = int(v.split()[0])
    total, avail = mem.get("MemTotal", 1), mem.get("MemAvailable", 0)
    du = shutil.disk_usage("/")
    up = float(open("/proc/uptime").read().split()[0])
    return {"load": round(os.getloadavg()[0], 2),
            "mem_pct": round(100 * (total - avail) / total),
            "disk_pct": round(100 * du.used / du.total),
            "uptime_h": round(up / 3600, 1)}

def state():
    users = list_users()
    svcs = {"Dropbear": "xxtlonline-dropbear", "WS Proxy": "xxtlonline-ws",
            "UDPGW": "xxtlonline-udpgw", "SSH": "ssh"}
    return {"users": users,
            "online_total": sum(u["online"] for u in users),
            "services": {k: service_state(v) for k, v in svcs.items()},
            "stats": stats(), "npv": npv_view()}


# ---------- web ----------
PAGE = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "index.html"), "rb").read()



class Handler(BaseHTTPRequestHandler):
    server_version = "xxtlonline-dash"
    def log_message(self, *a): pass

    def _send(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy",
            "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
            "connect-src 'self'; frame-ancestors 'none'")
        if getattr(self, "_cookie", None):
            self.send_header("Set-Cookie", self._cookie)
        self.end_headers()
        self.wfile.write(data)

    def _host_ok(self):
        if HOST not in ("127.0.0.1", "localhost"):
            return True
        h = (self.headers.get("Host") or "").rsplit(":", 1)[0].lower()
        return h in ("127.0.0.1", "localhost") or (DOMAIN != "" and h == DOMAIN)

    def _ip(self):
        ip = self.client_address[0]
        if ip in ("127.0.0.1", "::1"):          # มาจาก nginx บนเครื่องเดียวกัน
            ip = (self.headers.get("X-Real-IP") or ip).strip()[:64]
        return ip

    def _session(self):
        c = SimpleCookie(self.headers.get("Cookie", ""))
        tok = c["sid"].value if "sid" in c else ""
        s = sessions.get(tok)
        if s and s[0] > time.time():
            return tok, s[1]
        sessions.pop(tok, None)
        return None, None

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        if self.path == "/":
            return self._send(200, PAGE, "text/html")
        if self.path == "/api/state":
            tok, csrf = self._session()
            if not tok:
                return self._send(401, {"error": "login required"})
            d = state(); d["csrf"] = csrf
            return self._send(200, d)
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        try:
            n = int(self.headers.get("Content-Length", 0))
            if n > 16384 or "application/json" not in (self.headers.get("Content-Type") or ""):
                raise ValueError
            body = json.loads(self.rfile.read(n) or b"{}")
            if not isinstance(body, dict):
                raise ValueError
        except Exception:
            return self._send(400, {"ok": False, "error": "bad request"})

        if self.path == "/api/login":
            return self._login(body)

        tok, csrf = self._session()
        if not tok:
            return self._send(401, {"ok": False, "error": "login required"})
        if not hmac.compare_digest(self.headers.get("X-CSRF", ""), csrf):
            return self._send(403, {"ok": False, "error": "csrf"})

        if self.path == "/api/logout":
            sessions.pop(tok, None)
            return self._send(200, {"ok": True})

        if self.path == "/api/npv":
            err = save_npv(body)
            return self._send(200, {"ok": err is None, "error": err, "npv": npv_view()})

        user = str(body.get("user", ""))
        if not USER_RE.match(user):
            return self._send(400, {"ok": False, "error": "ชื่อผู้ใช้ไม่ถูกต้อง"})

        pw = str(body.get("password", "") or "")
        if pw and not PW_RE.match(pw):
            return self._send(400, {"ok": False, "error": "รหัสผ่านต้องยาว 6-64 ตัว ใช้ตัวอักษร ตัวเลข และ !@#%^&*_+=.,- เท่านั้น"})

        if self.path in ("/api/add", "/api/extend"):
            try:
                days = int(body.get("days", 30))
                assert 1 <= days <= 3650
            except Exception:
                return self._send(400, {"ok": False, "error": "จำนวนวันไม่ถูกต้อง (1-3650)"})
            if self.path == "/api/add":
                ok, out = run_cli("add", user, str(days), *([pw] if pw else []))
            else:
                ok, out = run_cli("extend", user, str(days))
        elif self.path == "/api/passwd":
            ok, out = run_cli("passwd", user, *([pw] if pw else []))
        elif self.path == "/api/suspend":
            ok, out = run_cli("suspend", user)
        elif self.path == "/api/resume":
            ok, out = run_cli("resume", user)
        elif self.path == "/api/del":
            ok, out = run_cli("del", user)
        else:
            return self._send(404, {"ok": False, "error": "not found"})

        creds = None
        if ok and self.path in ("/api/add", "/api/passwd"):
            m = re.search(r"Password\s*:\s*(\S+)", out)
            if m:
                creds = {"user": user, "password": m.group(1), "exp": user_exp(user)}
        return self._send(200, {"ok": ok, "output": out, "creds": creds, "error": None if ok else out})

    def _login(self, body):
        ip = self._ip()
        now = time.time()
        f = fails.get(ip, [0, 0])
        if f[1] > now:
            return self._send(429, {"ok": False, "error": "ลองมากเกินไป รอ 5 นาที"})
        if check_password(str(body.get("password", ""))):
            fails.pop(ip, None)
            for t in [t for t, s in sessions.items() if s[0] < now]:
                sessions.pop(t, None)
            tok, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(16)
            sessions[tok] = (now + SESSION_TTL, csrf)
            secure = "; Secure" if self.headers.get("X-Forwarded-Proto") == "https" else ""
            self._cookie = f"sid={tok}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_TTL}{secure}"
            return self._send(200, {"ok": True, "csrf": csrf})
        f[0] += 1
        if f[0] >= 5:
            f = [0, now + 300]
        fails[ip] = f
        time.sleep(1)
        self._send(401, {"ok": False, "error": "รหัสผ่านไม่ถูกต้อง"})


if __name__ == "__main__":
    if "--set-password" in sys.argv:
        set_password("--stdin" in sys.argv)
    else:
        if not os.path.exists(CONF):
            sys.exit("ยังไม่ได้ตั้งรหัสผ่าน: รัน python3 app.py --set-password")
        ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
