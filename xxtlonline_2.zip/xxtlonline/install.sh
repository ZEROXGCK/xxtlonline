#!/bin/bash
# ============================================================
#  xxtlonline installer — SSH over WebSocket + Dashboard (+ HTTPS)
#  Ubuntu 22.04 / 24.04 (หรือ Debian ที่ใช้ apt + systemd)
#
#  ติดตั้งทันทีจาก GitHub:
#    curl -fsSL https://raw.githubusercontent.com/ZEROXGCK/xxtlonline/main/install.sh | sudo bash
#  หรือ clone แล้วรัน:
#    sudo bash install.sh [ตัวเลือก]
#
#  ตัวเลือก:
#    --no-dashboard        ไม่ติดตั้งเว็บแดชบอร์ด
#    --domain DOMAIN       เปิดแดชบอร์ดผ่าน https://DOMAIN ต่อเลย (ต้องตั้ง DNS ไว้แล้ว)
#    --email EMAIL         อีเมลสำหรับ Let's Encrypt
#    --no-firewall         ไม่ยุ่งกับ ufw
#    --tune                จูนเครือข่าย VPS (BBR/FQ/RPS/IRQ ฯลฯ) หลังติดตั้งเสร็จ (แยกเป็นคำสั่ง xxtlonline-tune)
#    --ws-port N           พอร์ต WebSocket (ค่าเริ่มต้น 80)
#  ตัวแปรสภาพแวดล้อม:
#    XXTLONLINE_DASH_PASSWORD  รหัสแดชบอร์ด (ถ้าไม่ตั้งจะถาม; กด Enter = สุ่มให้)
#    XXTLONLINE_REPO / XXTLONLINE_BRANCH  ใช้ fork ของคุณเอง (ค่าเริ่มต้น ZEROXGCK/xxtlonline / main)
# ============================================================
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

REPO="${XXTLONLINE_REPO:-ZEROXGCK/xxtlonline}"
BRANCH="${XXTLONLINE_BRANCH:-main}"
WS_PORT=80; DB_PORT=143; UDPGW_PORT=7300; DASH_PORT=8088
WITH_DASH=1; DOMAIN=""; EMAIL=""; FIREWALL=1; TUNE=0

[[ $EUID -eq 0 ]] || { echo "ต้องรันด้วย root (sudo)"; exit 1; }
command -v apt-get >/dev/null && command -v systemctl >/dev/null || { echo "รองรับเฉพาะระบบที่ใช้ apt + systemd (Ubuntu/Debian)"; exit 1; }

while [[ $# -gt 0 ]]; do
  case $1 in
    --no-dashboard) WITH_DASH=0; shift ;;
    --domain)       DOMAIN=${2:-}; shift 2 ;;
    --email)        EMAIL=${2:-};  shift 2 ;;
    --no-firewall)  FIREWALL=0; shift ;;
    --tune)         TUNE=1; shift ;;
    --ws-port)      WS_PORT=${2:-}; shift 2 ;;
    -h|--help)      sed -n '2,25p' "$0" 2>/dev/null; exit 0 ;;
    *) echo "ไม่รู้จักตัวเลือก: $1"; exit 1 ;;
  esac
done
[[ $WS_PORT =~ ^[0-9]+$ ]] && (( WS_PORT >= 1 && WS_PORT <= 65535 )) || { echo "พอร์ตไม่ถูกต้อง"; exit 1; }
if [[ -n $DOMAIN && $WITH_DASH -eq 0 ]]; then echo "--domain ใช้ร่วมกับ --no-dashboard ไม่ได้"; exit 1; fi
if [[ -n $DOMAIN && $WS_PORT -ne 80 ]]; then echo "--domain ต้องใช้พอร์ต 80 (certbot ใช้ตอนขอใบรับรอง)"; exit 1; fi

# ---------- หาไฟล์ต้นทาง (clone อยู่แล้ว หรือดาวน์โหลดจาก GitHub) ----------
SRC="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd || true)"
if [[ ! -f "$SRC/src/xxtlonline" ]]; then
  echo "ดาวน์โหลดจาก github.com/${REPO} (${BRANCH}) ..."
  apt-get update -qq; apt-get install -y -qq curl ca-certificates >/dev/null
  TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
  curl -fsSL "https://codeload.github.com/${REPO}/tar.gz/refs/heads/${BRANCH}" | tar -xz -C "$TMP" --strip-components=1
  SRC=$TMP
fi
[[ -f "$SRC/src/xxtlonline" ]] || { echo "ไม่พบไฟล์ของโปรเจกต์"; exit 1; }

# ---------- ตรวจพอร์ต ----------
if ss -ltn "sport = :${WS_PORT}" | grep -q LISTEN && ! systemctl is-active --quiet xxtlonline-ws; then
  echo "พอร์ต ${WS_PORT} ถูกใช้งานอยู่ — ปิดโปรแกรมนั้นก่อน (เช่น nginx/apache) หรือใช้ --ws-port"; exit 1
fi
if [[ $WITH_DASH -eq 1 ]] && ss -ltn "sport = :${DASH_PORT}" | grep -q LISTEN && ! systemctl is-active --quiet xxtlonline-dash; then
  echo "พอร์ต ${DASH_PORT} ถูกใช้งานอยู่"; exit 1
fi

# ---------- ตั้งรหัสแดชบอร์ด (ถามก่อนติดตั้ง จะได้ไม่ต้องรอ) ----------
DASH_PW="${XXTLONLINE_DASH_PASSWORD:-}"; PW_GENERATED=0
if [[ $WITH_DASH -eq 1 && ! -f /etc/xxtlonline/dashboard.json && -z $DASH_PW ]]; then
  if [[ -r /dev/tty ]] && : </dev/tty 2>/dev/null; then
    while true; do
      read -rsp "ตั้งรหัสผ่านแดชบอร์ด (อย่างน้อย 8 ตัว, กด Enter = สุ่มให้): " DASH_PW </dev/tty; echo
      [[ -z $DASH_PW ]] && break
      if (( ${#DASH_PW} < 8 )); then echo "สั้นเกินไป"; continue; fi
      read -rsp "ยืนยันรหัสผ่าน: " PW2 </dev/tty; echo
      [[ $DASH_PW == "$PW2" ]] && break || echo "ไม่ตรงกัน"
    done
  fi
  if [[ -z $DASH_PW ]]; then DASH_PW=$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 16); PW_GENERATED=1; fi
fi

# ---------- ถามโดเมน (ถ้าไม่ได้ใส่ --domain; Enter = ข้าม ใช้ SSH tunnel แทน) ----------
if [[ -z $DOMAIN && $WITH_DASH -eq 1 && $WS_PORT -eq 80 ]] && [[ -r /dev/tty ]] && : </dev/tty 2>/dev/null; then
  while true; do
    read -rp "โดเมนสำหรับแดชบอร์ด HTTPS เช่น panel.example.com (ต้องชี้ A record มาที่ VPS นี้แล้ว, Enter = ข้าม): " DOMAIN </dev/tty
    DOMAIN=$(echo "$DOMAIN" | tr 'A-Z' 'a-z' | sed 's|^https\?://||; s|/.*$||')
    [[ -z $DOMAIN ]] && break
    [[ $DOMAIN =~ ^[a-z0-9]([a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}$ ]] && break
    echo "รูปแบบโดเมนไม่ถูกต้อง"
  done
  if [[ -n $DOMAIN && -z $EMAIL ]]; then
    read -rp "อีเมลแจ้งเตือนใบรับรองหมดอายุ (Enter = ข้าม): " EMAIL </dev/tty
  fi
fi

echo "[1/6] ติดตั้งแพ็กเกจ..."
apt-get update -qq
apt-get install -y -qq dropbear-bin python3 curl cron ca-certificates >/dev/null
[[ $FIREWALL -eq 1 ]] && apt-get install -y -qq ufw >/dev/null
# ---------- UDPGW (badvpn-udpgw): ลองจาก apt ก่อน ไม่มีก็ build จาก source (ปักเวอร์ชัน 1.999.130) ----------
build_udpgw() {
  local BV LOG=/var/log/xxtlonline-udpgw-build.log
  : > "$LOG"
  apt-get install -y -qq build-essential cmake pkg-config >>"$LOG" 2>&1 || { echo "  ⚠ ลงเครื่องมือ build ไม่ได้ (ดู $LOG)"; return 1; }
  BV=$(mktemp -d)
  local URLS=("https://github.com/ambrop72/badvpn/archive/refs/tags/1.999.130.tar.gz"
              "https://codeload.github.com/ambrop72/badvpn/tar.gz/refs/tags/1.999.130")
  local ok=0 u
  for u in "${URLS[@]}"; do
    if curl -fsSL --retry 3 --max-time 120 "$u" | tar -xz -C "$BV" --strip-components=1 2>>"$LOG"; then ok=1; break; fi
  done
  [[ $ok -eq 1 && -f $BV/CMakeLists.txt ]] || { echo "  ⚠ โหลด source จาก GitHub ไม่ได้ (ดู $LOG)"; rm -rf "$BV"; return 1; }
  # รองรับ CMake รุ่นใหม่ (4.x ปฏิเสธ cmake_minimum_required เก่า) และ gcc รุ่นใหม่ (-fno-common เป็นค่าเริ่มต้น)
  local FLAGS=(-DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 -DCMAKE_BUILD_TYPE=Release
               -DCMAKE_POLICY_VERSION_MINIMUM=3.5 "-DCMAKE_C_FLAGS=-fcommon -Wno-error -Wno-deprecated-declarations")
  if cmake -S "$BV" -B "$BV/build" "${FLAGS[@]}" >>"$LOG" 2>&1 \
     && cmake --build "$BV/build" -j"$(nproc)" >>"$LOG" 2>&1 \
     && [[ -x $BV/build/udpgw/badvpn-udpgw ]] \
     && install -m 755 "$BV/build/udpgw/badvpn-udpgw" /usr/local/bin/badvpn-udpgw; then
    echo "  build badvpn-udpgw สำเร็จ"; rm -rf "$BV"; return 0
  fi
  echo "  ⚠ build udpgw ไม่สำเร็จ — ข้อความสุดท้ายจาก $LOG:"; tail -n 15 "$LOG" | sed 's/^/    /'
  rm -rf "$BV"; return 1
}
apt-get install -y -qq badvpn >/dev/null 2>&1 || true
if ! command -v badvpn-udpgw >/dev/null 2>&1; then
  echo "  ไม่มี badvpn ใน apt — build udpgw จาก source (ประมาณ 1 นาที) ..."
  build_udpgw || echo "  (ข้าม udpgw — ระบบหลักใช้ได้ แต่ไม่มี UDP ผ่าน SSH; ลองใหม่ภายหลังด้วยการรัน install.sh ซ้ำ)"
fi

grep -qx '/bin/false' /etc/shells || echo '/bin/false' >> /etc/shells
mkdir -p /etc/xxtlonline/exp /etc/xxtlonline/susp /etc/dropbear
cat > /etc/xxtlonline/xxtlonline.conf <<CONF
WS_PORT=${WS_PORT}
DB_PORT=${DB_PORT}
UDPGW_PORT=${UDPGW_PORT}
CONF

echo "[2/6] ติดตั้งโปรแกรม..."
install -m 755 "$SRC/src/xxtlonline-ws" /usr/local/bin/xxtlonline-ws
install -m 755 "$SRC/src/xxtlonline"    /usr/local/bin/xxtlonline
install -m 755 "$SRC/scripts/https.sh" /usr/local/bin/xxtlonline-https
install -m 755 "$SRC/scripts/vpsbootpro.sh" /usr/local/bin/xxtlonline-tune
echo '5 0 * * * root /usr/local/bin/xxtlonline expire' > /etc/cron.d/xxtlonline
chmod 644 /etc/cron.d/xxtlonline

DROPBEAR=$(command -v dropbear || echo /usr/sbin/dropbear)
sed "s|@DROPBEAR@|${DROPBEAR}|" "$SRC/systemd/xxtlonline-dropbear.service" > /etc/systemd/system/xxtlonline-dropbear.service
install -m 644 "$SRC/systemd/xxtlonline-ws.service" /etc/systemd/system/xxtlonline-ws.service
if command -v badvpn-udpgw >/dev/null 2>&1; then
  sed "s|@BADVPN@|$(command -v badvpn-udpgw)|" "$SRC/systemd/xxtlonline-udpgw.service" > /etc/systemd/system/xxtlonline-udpgw.service
fi

if [[ $WITH_DASH -eq 1 ]]; then
  echo "[3/6] ติดตั้งแดชบอร์ด..."
  mkdir -p /opt/xxtlonline-dash
  install -m 700 "$SRC/dashboard/app.py"     /opt/xxtlonline-dash/app.py
  install -m 644 "$SRC/dashboard/index.html" /opt/xxtlonline-dash/index.html
  install -m 644 "$SRC/systemd/xxtlonline-dash.service" /etc/systemd/system/xxtlonline-dash.service
  if [[ ! -f /etc/xxtlonline/dashboard.json ]]; then
    printf '%s\n' "$DASH_PW" | python3 /opt/xxtlonline-dash/app.py --set-password --stdin
  fi
else
  echo "[3/6] ข้ามแดชบอร์ด"
fi

echo "[4/6] เปิดบริการ..."
systemctl daemon-reload
SERVICES=(xxtlonline-dropbear xxtlonline-ws)
[[ -f /etc/systemd/system/xxtlonline-udpgw.service ]] && SERVICES+=(xxtlonline-udpgw)
[[ $WITH_DASH -eq 1 ]] && SERVICES+=(xxtlonline-dash)
for s in "${SERVICES[@]}"; do systemctl enable "$s" >/dev/null 2>&1; systemctl restart "$s"; done

echo "[5/6] ตั้ง firewall..."
if [[ $FIREWALL -eq 1 ]]; then
  SSH_PORT=$(sshd -T 2>/dev/null | awk '/^port /{print $2; exit}'); SSH_PORT=${SSH_PORT:-22}
  ufw allow "${SSH_PORT}/tcp" >/dev/null
  ufw allow "${WS_PORT}/tcp"  >/dev/null
  ufw --force enable >/dev/null
else
  echo "  (ข้าม — ใช้ --no-firewall; อย่าลืมเปิดพอร์ต ${WS_PORT} เอง)"
fi

echo "[6/6] ตรวจสอบ..."
sleep 1
FAILED=0
for s in "${SERVICES[@]}"; do
  st=$(systemctl is-active "$s" || true)
  printf '   %-18s %s\n' "$s" "$st"
  [[ $st == active ]] || FAILED=1
done

if [[ -n $DOMAIN ]]; then
  echo; echo "ตั้งค่า HTTPS สำหรับ ${DOMAIN} ..."
  /usr/local/bin/xxtlonline-https --domain "$DOMAIN" --email "$EMAIL" || echo "⚠ ตั้ง HTTPS ไม่สำเร็จ — แก้ DNS/พอร์ต แล้วรัน: sudo xxtlonline-https"
fi

if [[ $TUNE -eq 1 ]]; then
  echo; echo "จูนเครือข่าย VPS (xxtlonline-tune) ..."
  /usr/local/bin/xxtlonline-tune || echo "⚠ จูนไม่สำเร็จ — ระบบหลักยังใช้งานได้ ลองรันใหม่: sudo xxtlonline-tune"
fi

IP=$(curl -s4 --max-time 5 https://api.ipify.org || hostname -I | awk '{print $1}')
echo
if [[ $FAILED -eq 0 ]]; then echo "✅ ติดตั้งเสร็จแล้ว"; else echo "⚠ มีบริการที่ไม่ทำงาน ดู: journalctl -u xxtlonline-ws -u xxtlonline-dropbear -n 50"; fi
echo "   เซิร์ฟเวอร์ : $IP   WebSocket: พอร์ต ${WS_PORT}"
echo "   UDPGW       : 127.0.0.1:${UDPGW_PORT} (ใช้ผ่าน SSH ในแอป)"
echo "   สร้าง user  : sudo xxtlonline add somchai 30"
echo "   เปิดเมนู    : sudo xxtlonline"
[[ $TUNE -eq 0 ]] && echo "   จูนเครือข่าย (ไม่บังคับ): sudo xxtlonline-tune"
if [[ $WITH_DASH -eq 1 ]]; then
  echo
  [[ $PW_GENERATED -eq 1 ]] && echo "   🔑 รหัสผ่านแดชบอร์ด (สุ่มให้ จดไว้เลย): $DASH_PW"
  if [[ -n $DOMAIN ]]; then
    echo "   แดชบอร์ด    : https://${DOMAIN}"
  else
    echo "   แดชบอร์ด (SSH tunnel จากเครื่องคุณ):"
    echo "     ssh -L ${DASH_PORT}:127.0.0.1:${DASH_PORT} root@${IP}"
    echo "     แล้วเปิด http://127.0.0.1:${DASH_PORT}"
    echo "   เปิดผ่านโดเมน HTTPS: sudo xxtlonline-https"
  fi
  echo "   เปลี่ยนรหัสผ่าน: sudo python3 /opt/xxtlonline-dash/app.py --set-password && sudo systemctl restart xxtlonline-dash"
fi
