# xxtlonline

SSH over WebSocket + เว็บแดชบอร์ดจัดการ user (+ HTTPS ผ่านโดเมน) ติดตั้งบน VPS ด้วยคำสั่งเดียว
รองรับ Ubuntu 22.04 / 24.04 (Debian ที่ใช้ apt + systemd ก็น่าจะได้)

```
client ──(HTTP Upgrade)──> :80 xxtlonline-ws ──> 127.0.0.1:143 Dropbear
                           badvpn-udpgw 127.0.0.1:7300 (UDP ผ่าน SSH, ถ้ามีใน repo)
dashboard 127.0.0.1:8088 ──(SSH tunnel หรือ nginx HTTPS :443)
```

## ติดตั้ง

> แทน `YOUR_GITHUB_USER` ด้วยชื่อ GitHub ของคุณ

```bash
curl -fsSL https://raw.githubusercontent.com/YOUR_GITHUB_USER/xxtlonline/main/install.sh | sudo XXTLONLINE_REPO=YOUR_GITHUB_USER/xxtlonline bash
```

หรือ clone แล้วรัน:

```bash
git clone https://github.com/YOUR_GITHUB_USER/xxtlonline.git
cd xxtlonline && sudo bash install.sh
```

ตัวเลือก

| ตัวเลือก | ความหมาย |
|---|---|
| `--no-dashboard` | ไม่ติดตั้งเว็บแดชบอร์ด |
| `--domain panel.example.com --email me@x.com` | เปิดแดชบอร์ดผ่าน HTTPS ทันที (ต้องชี้ A record มาที่ VPS ก่อน) |
| `--ws-port N` | เปลี่ยนพอร์ต WebSocket (ค่าเริ่มต้น 80; ใช้ร่วมกับ `--domain` ไม่ได้) |
| `--no-firewall` | ไม่แตะ ufw |

ใส่รหัสแดชบอร์ดแบบไม่ถามได้ด้วย `XXTLONLINE_DASH_PASSWORD=...` (ไม่ตั้งและไม่มีเทอร์มินัล = สุ่มให้แล้วแสดงตอนจบ)

## ใช้งาน

```bash
sudo xxtlonline                  # เมนู
sudo xxtlonline add somchai 30   # สร้าง user 30 วัน (ใส่รหัสเองเป็นอาร์กิวเมนต์ที่ 3 ได้)
sudo xxtlonline list
sudo xxtlonline extend somchai 30
sudo xxtlonline passwd somchai [รหัสใหม่]   # ว่าง = สุ่มให้
sudo xxtlonline suspend somchai             # ระงับชั่วคราว + ตัดการเชื่อมต่อ
sudo xxtlonline resume somchai
sudo xxtlonline del somchai
sudo xxtlonline status           # สถานะบริการ
```

user หมดอายุจะถูกล็อกและตัด session อัตโนมัติทุกวันเวลา 00:05 (cron)

### แดชบอร์ด

แอดมินเข้าคนเดียว (รหัสเดียว) และกดจัดการ user ให้ทุกคน:
สร้างบัญชี (ตั้งรหัสเองหรือสุ่ม), ต่ออายุเลือกจำนวนวัน, รีเซ็ตรหัส, ระงับ/เปิดใช้, ลบ,
และปุ่ม **คัดลอก / ดาวน์โหลดไฟล์** ข้อมูลสำหรับส่งให้ลูกค้า

**ตั้งรูปแบบข้อความ/ไฟล์ (NPV Tunnel):** การ์ด "รูปแบบข้อความ / ไฟล์" ในแดชบอร์ดให้กำหนดเทมเพลตเอง
ตัวแปร `{host} {port} {user} {pass} {exp}` พร้อมนามสกุลและชื่อไฟล์ (เช่น `npv4`)
ค่าเริ่มต้นเป็นข้อความธรรมดา (เก็บที่ `/etc/xxtlonline/npv.json`)

**ลิงก์ NPV Tunnel:** ปุ่ม "คัดลอกลิงก์ NPV" สร้างลิงก์ `npvt-ssh://...` พร้อมวางในแอปได้ทันที (โหมด SSH-Proxy-Payload,
ตั้งชื่อโปรไฟล์/payload/HTTP proxy/SNI ได้ในการ์ดเดียวกัน) รูปแบบลิงก์ตรวจเทียบกับลิงก์ตัวอย่างจริงแล้ว
หมายเหตุ: WS proxy ของโปรเจกต์นี้รับ request แรกแล้วตอบ 101 เลย payload แบบหลายช่วง (`[split]`) ที่ต้องมี request ที่สอง จะยังไม่รองรับ — รหัสผ่านแสดงได้เฉพาะตอนสร้าง/รีเซ็ต เพราะระบบเก็บแค่ hash ฝั่งแดชบอร์ด

ค่าเริ่มต้นฟังที่ `127.0.0.1:8088` เท่านั้น เข้าผ่าน SSH tunnel:

```bash
ssh -L 8088:127.0.0.1:8088 root@IP_VPS      # แล้วเปิด http://127.0.0.1:8088
```

เปิดผ่านโดเมน: `sudo xxtlonline-https` (nginx ฟังแค่ 443 + Let's Encrypt ต่ออายุเอง;
ตอนขอ/ต่ออายุใบรับรองจะหยุด WS proxy ชั่วคราว ~10–20 วินาที เพราะ certbot ต้องใช้พอร์ต 80)

เปลี่ยนรหัสผ่าน: `sudo python3 /opt/xxtlonline-dash/app.py --set-password && sudo systemctl restart xxtlonline-dash`

ความปลอดภัยของแดชบอร์ด: เก็บรหัสแบบ PBKDF2 hash, CSRF token, จำกัดการเดารหัส (5 ครั้ง/5 นาที), cookie HttpOnly + SameSite=Strict

## ถอนการติดตั้ง

```bash
sudo bash uninstall.sh            # เก็บ user และ /etc/xxtlonline ไว้
sudo bash uninstall.sh --purge    # ลบ user ที่สร้างด้วย xxtlonline และคอนฟิกทั้งหมด
```

## โครงสร้างรีโป

```
install.sh  uninstall.sh
src/xxtlonline        คำสั่งจัดการ user
src/xxtlonline-ws     WebSocket proxy (ส่งต่อไป Dropbear เท่านั้น ไม่ใช่ open proxy)
dashboard/        app.py + index.html
systemd/          unit files
scripts/https.sh  ติดตั้ง nginx + Let's Encrypt (ติดตั้งเป็นคำสั่ง xxtlonline-https)
```

## หมายเหตุ

- ใช้กับเซิร์ฟเวอร์ของคุณเองและตามกฎหมาย/ข้อกำหนดของผู้ให้บริการ VPS
- `xxtlonline del` ลบได้เฉพาะ user ที่สร้างผ่าน xxtlonline เท่านั้น
- ถ้าติดตั้ง badvpn ผ่าน apt ไม่ได้ ระบบยังทำงานได้ปกติ แค่ไม่มี UDP gateway
