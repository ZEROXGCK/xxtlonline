#!/bin/bash
# ถอนการติดตั้ง xxtlonline:  sudo bash uninstall.sh [--purge]
#   --purge  ลบ user ที่สร้างผ่าน xxtlonline ทั้งหมด + /etc/xxtlonline (รวมรหัสแดชบอร์ด) ด้วย
set -uo pipefail
[[ $EUID -eq 0 ]] || { echo "ต้องรันด้วย root (sudo)"; exit 1; }
PURGE=0; [[ ${1:-} == --purge ]] && PURGE=1

for s in xxtlonline-dash xxtlonline-ws xxtlonline-udpgw xxtlonline-dropbear; do
  systemctl disable --now "$s" >/dev/null 2>&1
  rm -f "/etc/systemd/system/$s.service"
done
rm -rf /etc/systemd/system/xxtlonline-dash.service.d
systemctl daemon-reload

if [[ -f /etc/nginx/conf.d/xxtlonline-dash.conf ]]; then
  rm -f /etc/nginx/conf.d/xxtlonline-dash.conf
  systemctl reload nginx 2>/dev/null || true
  echo "ลบคอนฟิก nginx แล้ว (nginx/certbot ยังติดตั้งอยู่ ลบเองได้ด้วย apt remove)"
fi

if [[ $PURGE -eq 1 && -d /etc/xxtlonline/exp ]]; then
  for f in /etc/xxtlonline/exp/*; do
    [[ -f $f ]] || continue
    u=$(basename "$f"); pkill -KILL -u "$u" 2>/dev/null; userdel -f "$u" 2>/dev/null && echo "ลบ user $u"
  done
fi

rm -f /usr/local/bin/xxtlonline /usr/local/bin/xxtlonline-ws /usr/local/bin/xxtlonline-https /etc/cron.d/xxtlonline
rm -rf /opt/xxtlonline-dash
[[ $PURGE -eq 1 ]] && rm -rf /etc/xxtlonline
echo "✅ ถอนการติดตั้งแล้ว  (firewall ufw ไม่ถูกแก้ไข — ปิดพอร์ตที่ไม่ใช้เองด้วย ufw delete allow ...)"
[[ $PURGE -eq 0 ]] && echo "   เก็บ /etc/xxtlonline และ user ไว้ — ใช้ --purge ถ้าต้องการลบทั้งหมด"
