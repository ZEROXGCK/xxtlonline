const $ = id => document.getElementById(id);
const S = {
  view: 'shop',
  net: 'ALL',
  proto: 'ALL',
  site: {},
  products: [],
  members: 0,
  activeServers: 0,
  user: null,
  credit: 0,
  orders: [],
  tickets: [],
  tkDraft: {},
  topups: [],
  // Admin state
  atab: 'menu',
  adminDash: null,
  need2fa: false,
  authDraft: { u: '', p: '', p2: '', r: '' },
  authMode: 'login',
  unread: 0,
  tsToken: '',
  adminSettings: null,
  adminUsers: [],
  userSearch: '',
  selectedUserDetail: null,
  adminServers: [],
  editingServerId: null,
  serverTestResult: null,
  adminTopups: [],
  adminCoupons: [],
  adminOrders: [],
  adminTickets: [],
  editingProductId: null,
  msg: null,
  q: '',
  sort: 'new',
  authNote: '',
  pendingBuy: null
};

const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => Number(n || 0).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fdate = iso => {
  try {
    return new Date(iso).toLocaleDateString('th-TH', { year: 'numeric', month: 'short', day: 'numeric' });
  } catch {
    return iso || '';
  }
};
const fdt = iso => {
  try {
    return new Date(iso).toLocaleString('th-TH', { dateStyle: 'short', timeStyle: 'short' });
  } catch {
    return iso || '';
  }
};

// =====================================================
// UI ENGINE: ธีม (สวิตช์สว่าง/มืด), toast, เอฟเฟกต์
// =====================================================
const REDUCED = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
const THEME_KEY = 'wselx-theme';

function currentTheme() {
  try {
    const t = localStorage.getItem(THEME_KEY);
    if (t === 'dark' || t === 'light') return t;
  } catch { /* ignore */ }
  const dm = (typeof S !== 'undefined' && S.site) ? S.site.ui_mode : '';
  if (dm === 'dark' || dm === 'light') return dm;
  return matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function applyTheme(t) {
  document.documentElement.dataset.theme = t;
  const m = document.querySelector('meta[name="theme-color"]');
  if (m) m.content = t === 'dark' ? '#0a0a0c' : '#f2f0ec';
  document.querySelectorAll('.theme-switch').forEach(sw => sw.setAttribute('aria-checked', String(t === 'dark')));
}

function toggleTheme(ev) {
  const next = currentTheme() === 'dark' ? 'light' : 'dark';
  try { localStorage.setItem(THEME_KEY, next); } catch { /* ignore */ }
  if (!document.startViewTransition || REDUCED) return applyTheme(next);
  const r = ev && ev.currentTarget ? ev.currentTarget.getBoundingClientRect() : { left: innerWidth - 40, top: 30, width: 0, height: 0 };
  document.documentElement.style.setProperty('--vt-x', (r.left + r.width / 2) + 'px');
  document.documentElement.style.setProperty('--vt-y', (r.top + r.height / 2) + 'px');
  document.startViewTransition(() => applyTheme(next));
}

function toast(type, text) {
  let box = $('toasts');
  if (!box) {
    box = document.createElement('div');
    box.id = 'toasts';
    box.setAttribute('aria-live', 'polite');
    document.body.appendChild(box);
  }
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  t.innerHTML = `<span class="ti">${type === 'ok' ? '✓' : '!'}</span><span>${esc(text)}</span>`;
  t.onclick = () => t.remove();
  box.appendChild(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 320); }, 4200);
}

let _lastView = null;
let _io = null;
const _counted = {};

function postRender() {
  const app = $('app');
  if (_lastView !== S.view) {
    app.classList.remove('page-enter');
    void app.offsetWidth;
    app.classList.add('page-enter');
    if (_lastView !== null) window.scrollTo({ top: 0, behavior: REDUCED ? 'auto' : 'smooth' });
    _lastView = S.view;
  }
  navSave();
  if (S.view === 'auth' && S.authMode === 'register') mountTurnstile();

  // scroll reveal
  const items = app.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window) || REDUCED) {
    items.forEach(el => el.classList.add('in'));
  } else {
    _io = _io || new IntersectionObserver(es => es.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('in'); _io.unobserve(e.target); }
    }), { threshold: 0.06 });
    items.forEach((el, i) => { el.style.setProperty('--d', (i % 8) * 55 + 'ms'); _io.observe(el); });
  }

  // count-up ตัวเลขสถิติ (เล่นครั้งเดียวต่อค่า)
  app.querySelectorAll('[data-count]').forEach(el => {
    const to = Number(el.dataset.count) || 0;
    const key = el.dataset.key || el.dataset.count;
    if (REDUCED || _counted[key] === to || to <= 0) { el.textContent = to.toLocaleString(); _counted[key] = to; return; }
    _counted[key] = to;
    const t0 = performance.now();
    const tick = t => {
      const k = Math.min(1, (t - t0) / 1000);
      el.textContent = Math.round(to * (1 - Math.pow(1 - k, 3))).toLocaleString();
      if (k < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
}

// การ์ดเอียงตามเมาส์ + แสงวิ่งตามเคอร์เซอร์
document.addEventListener('pointermove', e => {
  if (e.pointerType === 'touch' || REDUCED) return;
  const c = e.target.closest && e.target.closest('.tilt');
  if (!c) return;
  const r = c.getBoundingClientRect();
  const x = (e.clientX - r.left) / r.width;
  const y = (e.clientY - r.top) / r.height;
  c.style.setProperty('--rx', ((0.5 - y) * 6).toFixed(2) + 'deg');
  c.style.setProperty('--ry', ((x - 0.5) * 8).toFixed(2) + 'deg');
  c.style.setProperty('--mx', (x * 100).toFixed(1) + '%');
  c.style.setProperty('--my', (y * 100).toFixed(1) + '%');
});
document.addEventListener('pointerout', e => {
  const c = e.target.closest && e.target.closest('.tilt');
  if (c && !c.contains(e.relatedTarget)) { c.style.removeProperty('--rx'); c.style.removeProperty('--ry'); }
});

// ripple บนปุ่ม
document.addEventListener('pointerdown', e => {
  const b = e.target.closest && e.target.closest('.btn');
  if (!b || b.disabled) return;
  const r = b.getBoundingClientRect();
  b.style.setProperty('--px', (e.clientX - r.left) + 'px');
  b.style.setProperty('--py', (e.clientY - r.top) + 'px');
  b.classList.remove('rip');
  void b.offsetWidth;
  b.classList.add('rip');
});

function burst() {
  if (REDUCED) return;
  const host = document.querySelector('#dlgBody .success');
  if (!host) return;
  const box = document.createElement('div');
  box.className = 'confetti';
  const colors = ['#6366f1', '#8b5cf6', '#06b6d4', '#f59e0b', '#10b981', '#f43f5e'];
  for (let i = 0; i < 44; i++) {
    const s = document.createElement('i');
    s.style.cssText = `--x:${(Math.random() * 2 - 1) * 170}px;--y:${-70 - Math.random() * 150}px;--r:${Math.random() * 720 - 360}deg;--c:${colors[i % 6]};--dl:${(Math.random() * 0.18).toFixed(2)}s`;
    box.appendChild(s);
  }
  host.appendChild(box);
  setTimeout(() => box.remove(), 2000);
}

async function api(path, opt = {}) {
  const r = await fetch('/api' + path, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    ...opt,
    body: opt.body ? JSON.stringify(opt.body) : undefined
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { const er = new Error(d.error || 'เกิดข้อผิดพลาด'); er.data = d; throw er; }
  return d;
}

function readImg(file, maxW = 1200) {
  return new Promise((res, rej) => {
    if (!file) return res('');
    if (!file.type.startsWith('image/')) return rej(new Error('กรุณาเลือกไฟล์รูปภาพ'));
    const rd = new FileReader();
    rd.onload = () => {
      const im = new Image();
      im.onload = () => {
        const sc = Math.min(1, maxW / im.width);
        const cv = document.createElement('canvas');
        cv.width = Math.round(im.width * sc);
        cv.height = Math.round(im.height * sc);
        cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
        res(cv.toDataURL('image/jpeg', 0.85));
      };
      im.onerror = () => rej(new Error('อ่านรูปภาพไม่สำเร็จ'));
      im.src = rd.result;
    };
    rd.readAsDataURL(file);
  });
}

function showMsg(type, text) {
  toast(type, text);
  render();
}

function msgHtml() {
  return S.msg ? `<div class="msg ${S.msg.type}">${esc(S.msg.text)}</div>` : '';
}

// ---------- จำหน้าที่เปิดอยู่ (รีเฟรชแล้วไม่เด้งกลับหน้าหลัก) ----------
const MENU_STYLES = [
  ['card', 'การ์ด', 'ไอคอน + ชื่อ + คำอธิบาย'],
  ['grid', 'ไอคอนกริด', 'ปุ่มสี่เหลี่ยมแบบแอป'],
  ['list', 'รายการ', 'แถวเรียงลงมา มีลูกศร'],
  ['chip', 'กะทัดรัด', 'ปุ่มเล็ก เห็นครบในหน้าเดียว']
];
function admMenuStyle() {
  let v = '';
  try { v = localStorage.getItem('wselx_adm_menu_style') || ''; } catch { /* ignore */ }
  return MENU_STYLES.some(m => m[0] === v) ? v : 'card';
}
function setAdmMenuStyle(v) {
  if (!MENU_STYLES.some(m => m[0] === v)) return;
  try { localStorage.setItem('wselx_adm_menu_style', v); } catch { /* ignore */ }
  const hub = document.querySelector('.adm-hub');
  if (hub) hub.dataset.style = v;
  document.querySelectorAll('.adm-style-opt').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.v === v)));
}
const NAV_KEY = 'wselx_nav';
const NAV_VIEWS = ['shop', 'topup', 'history', 'support', 'auth', 'admin'];
const NAV_ATABS = ['menu', 'dash', 'users', 'servers', 'add', 'edit', 'coupons', 'topups', 'orders', 'tickets', 'slip', 'site', 'look'];
let _navReady = false;
function navSave() {
  if (!_navReady) return;
  try { sessionStorage.setItem(NAV_KEY, JSON.stringify({ v: S.view, a: S.atab })); } catch { /* ignore */ }
}
// เรียกครั้งเดียวตอนโหลดหน้า หลังรู้แล้วว่าล็อกอินอยู่ไหม และก่อน render ครั้งแรก
function navRestore() {
  if (_navReady) return;
  _navReady = true;
  let n = null;
  try { n = JSON.parse(sessionStorage.getItem(NAV_KEY) || 'null'); } catch { /* ignore */ }
  if (!n || !NAV_VIEWS.includes(n.v)) return;
  let v = n.v;
  if (!S.user && ['topup', 'history', 'support', 'admin'].includes(v)) v = 'shop';
  if (v === 'admin' && S.user?.role !== 'admin') v = 'shop';
  if (v === 'auth' && S.user) v = 'shop';
  S.view = v;
  if (v === 'admin') {
    if (NAV_ATABS.includes(n.a)) S.atab = n.a;
    loadAdminTab(S.atab);
  }
  if (v === 'history' && S.user) loadUsage();
}

function go(v) {
  S.view = v;
  S.msg = null;
  if (v !== 'auth') { S.authNote = ''; S.pendingBuy = null; }
  if (v === 'admin') {
    S.atab = 'menu';
    S.editingProductId = null;
    S.editingServerId = null;
    S.selectedUserDetail = null;
    window.scrollTo({ top: 0 });
    loadAdminTab('menu');
  }
  if (v === 'history' && S.user) loadUsage();
  if (v === 'support') markSupportRead();
  render();
}

function admMenu(open) {
  S.admMenu = !!open;
  document.body.classList.toggle('adm-lock', !!open);
  const sh = document.querySelector('.adm-sheet');
  if (sh) sh.dataset.open = String(!!open);
  const tg = document.querySelector('.adm-mtrig');
  if (tg) tg.setAttribute('aria-expanded', String(!!open));
}

function setAdminTab(t) {
  admMenu(false);
  window.scrollTo({ top: 0 });
  S.atab = t;
  S.msg = null;
  S.editingProductId = null;
  S.editingServerId = null;
  S.selectedUserDetail = null;
  S.serverTestResult = null;
  loadAdminTab(t);
  render();
}

async function loadAdminTab(t) {
  if (!S.user || S.user.role !== 'admin') return;
  try {
    if (t === 'menu') {
      const [tp, tk] = await Promise.all([
        api('/admin/topups').catch(() => S.adminTopups),
        api('/admin/tickets').catch(() => S.adminTickets)
      ]);
      S.adminTopups = tp || [];
      S.adminTickets = tk || [];
    }
    if (t === 'dash') S.adminDash = await api('/admin/dashboard');
    if (t === 'users') S.adminUsers = await api('/admin/users?q=' + encodeURIComponent(S.userSearch || ''));
    if (t === 'servers') { S.adminServers = await api('/admin/servers'); S.xxtLink = await api('/admin/xxt-link').catch(() => null); }
    if (t === 'add' || t === 'edit') {
      S.adminServers = await api('/admin/servers');
      S.adminPlans = await api('/admin/plans');
    }
    if (t === 'topups') S.adminTopups = await api('/admin/topups');
    if (t === 'coupons') S.adminCoupons = await api('/admin/coupons');
    if (t === 'orders') await loadAdminOrders();
    if (t === 'tickets') S.adminTickets = await api('/admin/tickets');
    if (t === 'site' || t === 'slip' || t === 'look') S.adminSettings = await api('/admin/settings');
    if (t === 'slip') S.slipRecent = await api('/admin/topups-recent').catch(() => []);
    render();
  } catch (e) {
    showMsg('bad', e.message);
  }
}

async function refreshAll() {
  const [siteData, meData] = await Promise.all([api('/site'), api('/me')]);
  S.site = siteData.site || {};
  S.products = siteData.products || [];
  S.members = siteData.members || 0;
  S.activeServers = siteData.activeServers || 0;
  S.user = meData.user || null;
  S.credit = meData.credit || 0;
  S.orders = meData.orders || [];
  S.tickets = meData.tickets || [];
  S.unread = meData.unreadTickets || 0;
  S.topups = meData.topups || [];
  navRestore();
  if (S.view === 'support') markSupportRead();
  render();
}

// =====================================================
// TOPBAR & FOOTER
// =====================================================
// ---------- แจ้งเตือนตอบกลับซัพพอร์ต (ตัวเลขที่เมนู "ซัพพอร์ต") ----------
function markSupportRead() {
  if (!S.user || !S.unread) return;
  S.unread = 0;
  api('/tickets/read', { method: 'POST' }).catch(() => {});
}

async function pollUnread() {
  if (!S.user || document.hidden) return;
  try {
    const r = await api('/me/unread');
    const n = r.unread || 0;
    if (S.view === 'support') {
      if (n > 0) {
        // อยู่หน้าซัพพอร์ตอยู่แล้ว: ดึงคำตอบใหม่มาแสดง (ไม่รีเฟรชถ้ากำลังพิมพ์อยู่)
        const me = await api('/me');
        S.tickets = me.tickets || S.tickets;
        const typing = ($('tkSubject') && $('tkSubject').value) || ($('tkMsg') && $('tkMsg').value) || Object.values(S.tkDraft).some(v => v);
        S.unread = 0;
        api('/tickets/read', { method: 'POST' }).catch(() => {});
        if (!typing) render();
        toast('ok', '💬 แอดมินตอบกลับแล้ว');
      }
      return;
    }
    if (n !== S.unread) {
      const more = n > S.unread;
      S.unread = n;
      renderBar();
      if (more) toast('ok', '💬 แอดมินตอบกลับเรื่องแจ้งปัญหาของคุณแล้ว');
    }
  } catch { /* ignore */ }
}
setInterval(pollUnread, 45000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) pollUnread(); });

function themeSwitchHtml() {
  return `<button class="theme-switch" role="switch" aria-checked="${currentTheme() === 'dark'}" aria-label="สลับโหมดสว่าง / มืด" title="สลับโหมดสว่าง / มืด" onclick="toggleTheme(event)">
    <span class="sun">☀️</span><span class="moon">🌙</span><span class="knob"></span>
  </button>`;
}

// ไอคอนเส้นสำหรับแถบเมนูล่าง (ถ้าชุดไอคอนยังไม่พร้อมจะใช้อีโมจิแทน)
function navIc(name, fallback) {
  if (lookSrc().ui_icon === 'emoji') return fallback;
  try { return admIcon(name); } catch (e) { return fallback; }
}

function renderBar() {
  const s = S.site;
  const navBtn = (id, label, icon, short, badge = 0) =>
    `<button aria-current="${S.view === id ? 'page' : 'false'}" onclick="go('${id}')"${badge > 0 ? ` aria-label="${label} (${badge} ข้อความใหม่)"` : ''}><span class="ni">${icon}</span><span class="nl">${label}</span><span class="ns">${short || label}</span>${badge > 0 ? `<span class="nbadge">${badge > 99 ? '99+' : badge}</span>` : ''}</button>`;
  document.title = (S.user && S.unread > 0 ? `(${S.unread}) ` : '') + (s.name || 'Wselx Shop');
  document.body.classList.toggle('has-tabs', !!S.user);

  let right = '';
  if (S.user) {
    right = `
      <button class="pill" onclick="go('topup')" title="เติมเครดิต">💳 ${money(S.credit)} ฿</button>
      <span class="uname">@${esc(S.user.username)}</span>
      <button class="btn ghost sm" onclick="logout()">ออก</button>
    `;
  } else {
    right = `<button class="btn sm" onclick="go('auth')">เข้าสู่ระบบ / สมัครสมาชิก</button>`;
  }

  $('bar').innerHTML = `
    <div class="brand" onclick="go('shop')">
      ${s.logo ? `<img src="${esc(s.logo)}" alt="logo">` : `<div class="logo-fallback">W</div>`}
      <span>${esc(s.name || 'Wselx Shop')}</span>
    </div>
    <nav class="${S.user ? '' : 'solo'}">
      ${navBtn('shop', 'แพ็กเกจ', navIc('store', '🛍️'))}
      ${S.user ? navBtn('topup', 'เติมเงิน', navIc('wallet', '💳')) : ''}
      ${S.user ? navBtn('history', 'ประวัติ & ไฟล์', navIc('receipt', '🗂️'), 'ประวัติ') : ''}
      ${S.user ? navBtn('support', 'แจ้งปัญหา', navIc('message', '💬'), 'ซัพพอร์ต', S.unread) : ''}
      ${S.user && S.user.role === 'admin' ? navBtn('admin', '⚙️ หลังบ้าน', navIc('settings', '⚙️'), 'หลังบ้าน') : ''}
    </nav>
    ${right}
  `;

  $('foot').innerHTML = `
    <div><b>${esc(s.name || 'Wselx Shop')}</b> • ระบบจำหน่าย VPN / SSH / 3x-ui อัตโนมัติ</div>
    <div>${s.line ? `ติดต่อแอดมิน: <b>${esc(s.line)}</b>` : 'พร้อมให้บริการตลอด 24 ชั่วโมง'}</div>
    <div class="foot-theme"><span>โหมดแสดงผล</span>${themeSwitchHtml()}</div>
    ${lookSrc().footer_text ? `<div style="flex:1 0 100%">${esc(lookSrc().footer_text)}</div>` : ''}
  `;
}

// =====================================================
// CUSTOMER: SHOP VIEW
// =====================================================
function shopFiltered() {
  const q = (S.q || '').trim().toLowerCase();
  let list = S.products.filter(p =>
    !p.offline &&
    (S.net === 'ALL' || p.net === S.net) &&
    (S.proto === 'ALL' || p.proto === S.proto) &&
    (!q || [p.title, p.desc, p.net, p.proto, p.serverName].join(' ').toLowerCase().includes(q))
  );
  const minP = p => (p.plans.length ? Math.min(...p.plans.map(x => x.p)) : Infinity);
  if (S.sort === 'cheap') list = [...list].sort((a, b) => minP(a) - minP(b));
  if (S.sort === 'rating') list = [...list].sort((a, b) => (b.ratingAvg || 0) - (a.ratingAvg || 0));
  return list;
}

function shopGridHtml() {
  const list = shopFiltered();
  if (!list.length) return `<div class="section-card empty reveal"><div style="font-size:38px">🔍</div>ไม่พบแพ็กเกจที่ตรงกับตัวกรอง</div>`;
  return `<div class="grid">${list.map(p => {
    const minP = p.plans.length ? Math.min(...p.plans.map(x => x.p)) : 0;
    const chips = p.plans.slice(0, 3).map(pl =>
      `<button class="chip" onclick="openBuy(${p.id},${pl.id})" title="สั่งซื้อ ${esc(pl.n)}"><span>${esc(pl.d)}</span>${pl.op ? `<s class="was">${money(pl.op)}</s>` : ''}<b>${pl.p === 0 ? 'ฟรี' : money(pl.p) + '฿'}</b></button>`
    ).join('');
    return `
      <div class="card tilt reveal">
        <div class="card-media">
          ${p.img ? `<img src="${esc(p.img)}" alt="${esc(p.title)}" loading="lazy">` : `<div class="media-fallback"><span>${esc(p.proto)}</span></div>`}
          ${p.badge ? `<span class="ribbon">${esc(p.badge)}</span>` : ''}
        </div>
        <div class="b">
          <div class="tags">
            <span class="tag ${esc(p.net)}">${esc(p.net)}</span>
            <span class="tag">${esc(p.proto)}</span>
            ${p.serverName ? `<span class="tag srv">⚡ ${esc(p.serverName)}</span>` : ''}
          </div>
          <h3>${esc(p.title)}</h3>
          <p>${esc(p.desc || 'เชื่อมต่อเสถียร รองรับความเร็วสูง สร้างบัญชีทันทีหลังชำระเงิน')}</p>
          ${p.ratingCount ? `<div class="rate"><span class="stars">★</span> <b>${p.ratingAvg}</b> <span>(${p.ratingCount} รีวิว)</span></div>` : ''}
          ${chips ? `<div class="chips">${chips}</div>` : ''}
          <div class="foot">
            <div class="price"><small>เริ่มต้น </small>${money(minP)} ฿</div>
            <button class="btn sm" onclick="openBuy(${p.id})">สั่งซื้อ →</button>
          </div>
        </div>
        <span class="glare"></span>
      </div>`;
  }).join('')}</div>`;
}

function refreshGrid() {
  const el = $('shopGrid');
  if (!el) return render();
  el.innerHTML = shopGridHtml();
  postRender();
}

function viewShop() {
  const s = S.site;
  const nets = ['ALL', 'AIS', 'TRUE', 'dtac'];
  const protos = ['ALL', 'V2RAY', 'SSH', 'UDP'];
  const sorts = [['new', 'แนะนำ'], ['cheap', 'ราคาถูกสุด'], ['rating', 'รีวิวสูงสุด']];

  return `
    ${expiryBanner()}
    <section class="hero">
      <i class="blob b1"></i><i class="blob b2"></i><i class="blob b3"></i>
      <div class="hero-txt">
        <span class="eyebrow"><i class="dot"></i> ระบบออนไลน์ • สร้างบัญชีอัตโนมัติ</span>
        <h1>${esc(s.title || 'เติมแพ็กเกจเน็ตความเร็วสูง\nสร้างบัญชีอัตโนมัติใน 3 วินาที').replace(/\n/g, '<br>')}</h1>
        <p>${esc(s.sub || 'เลือกโปรที่ตรงกับเครือข่ายของคุณ จ่ายด้วยเครดิต รับไฟล์และลิงก์เชื่อมต่อทันที')}</p>
        <div class="hero-cta">
          <button class="btn light" onclick="${S.user ? `document.getElementById('shopTop').scrollIntoView({behavior:'smooth'})` : `go('auth')`}">${S.user ? '🛒 เลือกแพ็กเกจ' : '🚀 เริ่มต้นใช้งาน'}</button>
          <button class="btn glass" onclick="go('${S.user ? 'topup' : 'auth'}')">${S.user ? '💳 เติมเครดิต' : 'สมัครสมาชิกฟรี'}</button>
        </div>
        <div class="stats">
          <div><b data-count="${S.members}" data-key="members">0</b><span>สมาชิกทั้งหมด</span></div>
          <div><b data-count="${S.products.length}" data-key="products">0</b><span>แพ็กเกจพร้อมขาย</span></div>
          <div><b data-count="${S.activeServers}" data-key="servers">0</b><span>เซิร์ฟเวอร์ออนไลน์</span></div>
          <div><b>${esc(s.open || '2026')}</b><span>เปิดให้บริการ</span></div>
        </div>
      </div>
      <div class="hero-art">
        ${s.hero
          ? `<img src="${esc(s.hero)}" alt="Hero">`
          : `<div class="orbit-card">
               <div class="orbit"><i></i><i></i><i></i></div>
               <div class="oc-t">AUTO PROVISIONING</div>
               <div class="oc-h">3x-ui & SSH<br>Real-Time</div>
               <div class="oc-s">สร้างบัญชีทันทีหลังชำระเงิน<br>ไม่ต้องรอแอดมิน</div>
             </div>`}
      </div>
    </section>

    <div class="perks reveal">
      <div><span>⚡</span><b>ส่งมอบทันที</b><small>รับลิงก์/ไฟล์หลังชำระ</small></div>
      <div><span>🔒</span><b>ชำระด้วยเครดิต</b><small>ตรวจสอบรายการก่อนยืนยัน</small></div>
      <div><span>🔄</span><b>ต่ออายุง่าย</b><small>กดเดียวจากหน้าประวัติ</small></div>
      <div><span>💬</span><b>ซัพพอร์ต</b><small>แจ้งปัญหาได้ตลอด</small></div>
    </div>

    ${s.promo ? `<div class="promo reveal"><img src="${esc(s.promo)}" alt="Promotion"></div>` : ''}
    ${msgHtml()}

    <div id="shopTop" class="filters reveal">
      <div class="search"><span>🔎</span><input id="shopQ" type="search" placeholder="ค้นหาแพ็กเกจ เช่น AIS, SSH..." value="${esc(S.q || '')}" oninput="S.q=this.value;refreshGrid()"></div>
      <div class="seg">
        ${nets.map(n => `<button aria-pressed="${S.net === n}" onclick="S.net='${n}';render()">${n === 'ALL' ? 'ทุกเครือข่าย' : n}</button>`).join('')}
      </div>
      <div class="seg">
        ${protos.map(pr => `<button aria-pressed="${S.proto === pr}" onclick="S.proto='${pr}';render()">${pr === 'ALL' ? 'ทุกโปรโตคอล' : pr}</button>`).join('')}
      </div>
      <div class="seg">
        ${sorts.map(([k, l]) => `<button aria-pressed="${(S.sort || 'new') === k}" onclick="S.sort='${k}';render()">${l}</button>`).join('')}
      </div>
    </div>

    <div id="shopGrid">${shopGridHtml()}</div>
  `;
}

// =====================================================
// CHECKOUT: เลือกแพ็กเกจ → ตรวจสอบ/ชำระเงิน → รับบัญชี
// =====================================================
const DEFAULT_TERMS = 'เป็นสินค้าดิจิทัล ระบบสร้างบัญชีและหักเครดิตทันทีเมื่อกดชำระเงิน\nการคืนเงินเป็นเครดิตในร้าน พิจารณาตามจำนวนวันที่เหลือและเมื่อบัญชีใช้งานไม่ได้จากฝั่งเซิร์ฟเวอร์\nบัญชีทดลองใช้ฟรีได้คนละ 1 ครั้ง และต่ออายุไม่ได้\n(แอดมินแก้ข้อความนี้ได้ที่ ตั้งค่าเว็บไซต์ → เงื่อนไขและนโยบายคืนเงิน)';
const C = { p: null, planId: 0, coupon: '', couponMsg: null, quote: null, step: 1, agree: false, busy: false, result: null, err: '' };

const planOf = () => (C.p ? C.p.plans.find(x => x.id === C.planId) : null);

function stepper(n) {
  const names = ['เลือกแพ็กเกจ', 'ตรวจสอบ & ชำระ', 'รับบัญชี'];
  return `<ol class="stepper">${names.map((t, i) =>
    `<li class="${i + 1 < n ? 'done' : i + 1 === n ? 'now' : ''}"><i>${i + 1 < n ? '✓' : i + 1}</i><span>${t}</span></li>`
  ).join('')}</ol>`;
}

function openBuy(prodId, planId) {
  const p = S.products.find(x => x.id === prodId);
  if (!p || !p.plans.length) return;
  Object.assign(C, {
    p, planId: planId || p.plans[0].id, coupon: '', couponMsg: null, quote: null,
    step: 1, agree: false, busy: false, result: null, err: ''
  });
  renderCheckout();
  if (!$('dlg').open) $('dlg').showModal();
}

function closeDlg() {
  if (C.busy) return;
  $('dlg').close();
}

function pickPlan(id) {
  C.planId = id;
  C.quote = null;
  C.couponMsg = null;
  renderCheckout();
  if (C.coupon && S.user) applyCoupon();
}

async function fetchQuote() {
  C.quote = await api('/quote', { method: 'POST', body: { planId: C.planId, coupon: C.coupon } });
  return C.quote;
}

async function applyCoupon() {
  const inp = $('buyCoupon');
  if (inp) C.coupon = inp.value.trim().toUpperCase();
  if (!C.coupon) { C.couponMsg = { type: 'bad', text: 'กรุณากรอกโค้ดส่วนลด' }; return renderCheckout(); }
  if (!S.user) { C.couponMsg = { type: 'bad', text: 'กรุณาเข้าสู่ระบบก่อนใช้โค้ดส่วนลด' }; return renderCheckout(); }
  const btn = $('btnCoupon');
  if (btn) { btn.disabled = true; btn.textContent = 'กำลังตรวจ...'; }
  try {
    const q = await fetchQuote();
    if (q.couponError) { C.quote = null; C.couponMsg = { type: 'bad', text: q.couponError }; }
    else C.couponMsg = { type: 'ok', text: `ใช้โค้ด ${C.coupon} สำเร็จ ลด ${q.percent}% (−${money(q.couponDiscount ?? q.discount)} ฿)` };
  } catch (e) {
    C.couponMsg = { type: 'bad', text: e.message };
  }
  renderCheckout();
}

async function goReview() {
  const inp = $('buyCoupon');
  if (inp) C.coupon = inp.value.trim().toUpperCase();
  if (!S.user) {
    S.pendingBuy = { prodId: C.p.id, planId: C.planId, coupon: C.coupon };
    S.authNote = 'เข้าสู่ระบบหรือสมัครสมาชิกก่อน แล้วระบบจะพากลับมาสั่งซื้อต่อให้อัตโนมัติ';
    $('dlg').close();
    return go('auth');
  }
  const btn = $('btnNext');
  if (btn) { btn.disabled = true; btn.textContent = 'กำลังตรวจสอบ...'; }
  try {
    const q = await fetchQuote();
    if (q.couponError) {
      C.quote = null;
      C.couponMsg = { type: 'bad', text: q.couponError };
    } else {
      C.step = 2;
      C.agree = false;
      C.err = '';
    }
  } catch (e) {
    C.err = e.message;
  }
  renderCheckout();
}

function backToPlans() { C.step = 1; C.err = ''; renderCheckout(); }

function goTopupFromCheckout() { $('dlg').close(); go('topup'); }

// คัดลอกลงคลิปบอร์ด — มี fallback สำหรับเบราว์เซอร์ในแอป (LINE/FB) และหน้า http ที่ navigator.clipboard ใช้ไม่ได้
async function clip(txt) {
  const t = String(txt ?? '');
  try {
    if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(t); return true; }
  } catch { /* ลองวิธีสำรอง */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = t;
    ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;font-size:16px';
    (document.querySelector('dialog[open]') || document.body).appendChild(ta);   // อยู่ใน dialog ที่เปิด ไม่งั้นโฟกัสไม่ได้
    ta.focus(); ta.select(); ta.setSelectionRange(0, t.length);
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  } catch { return false; }
}

function flashBtn(btn, ok) {
  if (!btn) return;
  if (!btn.dataset.old) btn.dataset.old = btn.innerHTML;
  btn.innerHTML = ok ? '✓ คัดลอกแล้ว' : '✕ ไม่สำเร็จ';
  btn.classList.toggle('done', ok);
  clearTimeout(btn._t);
  btn._t = setTimeout(() => { btn.innerHTML = btn.dataset.old; btn.classList.remove('done'); }, 1600);
}

async function copyIn(btn, txt) {
  const ok = await clip(txt);
  flashBtn(btn, ok);
  if (!ok) toast('bad', 'คัดลอกไม่สำเร็จ — กดค้างที่ข้อความแล้วเลือกคัดลอกเอง');
}

async function doPay() {
  if (C.busy || !C.quote || !C.quote.enough || !C.agree) return;
  C.busy = true;
  C.err = '';
  C.step = 3;
  C.result = null;
  renderCheckout();
  try {
    const res = await api('/buy', { method: 'POST', body: { planId: C.planId, coupon: C.coupon } });
    C.result = res;
    C.busy = false;
    S.credit = res.credit != null ? res.credit : S.credit;
    try { await refreshAll(); } catch { /* ไม่กระทบผลการสั่งซื้อ */ }
  } catch (e) {
    C.busy = false;
    C.step = 2;
    C.err = e.message;
    C.quote = null;
    try { await fetchQuote(); } catch { /* ignore */ }
  }
  renderCheckout();
  if (C.result) {
    burst();
    const cur = C.result;
    loadUsage().finally(() => { cur._uDone = true; if (C.result === cur && C.step === 3) renderCheckout(); });
  }
}

// กล่องข้อมูลหลังสั่งซื้อ: แสดงเฉพาะผู้ใช้ รหัสผ่าน วันหมดอายุ และโควตา (ไม่แสดง payload/ลิงก์/ปุ่มส่งออกแอป — ดูครบได้ที่ "ประวัติ & ไฟล์")
function successInfoHtml(r) {
  const f = parseAccount(r.account).f;
  const u = (S.usage || {})[r.order];
  const quota = !u ? (r._uDone ? '—' : 'กำลังโหลด…') : u.total > 0 ? `${fmtBytes(u.used)} / ${fmtBytes(u.total)}` : 'ไม่จำกัด';
  const row = (k, v, mono) => `<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--line)">
      <span style="color:var(--muted,inherit)">${k}</span>
      <b style="${mono ? 'font-family:ui-monospace,monospace;' : ''}word-break:break-all;text-align:right">${esc(v)}</b></div>`;
  const rows = [];
  if (f.user) rows.push(row('ชื่อผู้ใช้', f.user, true));
  if (f.pass) rows.push(row('รหัสผ่าน', f.pass, true));
  rows.push(row('วันหมดอายุ', fdt(r.expiresAt)));
  rows.push(row('โควตาข้อมูล', quota));
  // แพ็กเกจแบบลิงก์ (ไม่มีผู้ใช้/รหัส): ไม่แสดงลิงก์ ให้มีแค่ปุ่มคัดลอก
  const pr = parseAccount(r.account);
  const link = pr.v2 || pr.npv || pr.netmod || String(r.account || '').trim();
  const note = f.user || f.pass ? '' : `<button class="btn" style="width:100%;font-size:17px;font-weight:800;padding:13px 16px;margin-top:10px" onclick="copyIn(this, ${esc(JSON.stringify(link))})">📋 คัดลอกลิงก์เชื่อมต่อ</button>`;
  return `<div style="margin:12px 0;border:1px solid var(--line);border-radius:14px;padding:0 14px">${rows.join('').replace(/border-bottom:1px solid var\(--line\)">(?![\s\S]*border-bottom)/, '">')}</div>${note}`;
}

function renderCheckout() {
  const p = C.p;
  if (!p) return;
  if (C.step === 2 && !C.quote) C.step = 1;
  const pl = planOf();
  const head = `
    <button class="x" onclick="closeDlg()" aria-label="ปิด">×</button>
    <div class="co-head">
      <div class="co-thumb">${p.img ? `<img src="${esc(p.img)}" alt="">` : `<span>${esc(p.proto)}</span>`}</div>
      <div>
        <h3>${esc(p.title)}</h3>
        <div class="tags">
          <span class="tag ${esc(p.net)}">${esc(p.net)}</span>
          <span class="tag">${esc(p.proto)}</span>
          ${p.serverName ? `<span class="tag srv">⚡ ${esc(p.serverName)}</span>` : ''}
        </div>
      </div>
    </div>
    ${stepper(C.step)}`;

  let body = '';

  if (C.step === 1) {
    const q = C.quote && C.quote.planId === C.planId ? C.quote : null;
    const total = q ? q.total : pl.p;
    body = `
      ${p.desc ? `<p class="co-desc">${esc(p.desc)}</p>` : ''}
      <div class="plans">
        ${p.plans.map(x => `
          <label class="${x.id === C.planId ? 'on' : ''}">
            <input type="radio" name="planId" value="${x.id}" ${x.id === C.planId ? 'checked' : ''} onchange="pickPlan(${x.id})">
            <span class="pl-main"><b>${esc(x.n)}</b><small>อายุการใช้งาน ${esc(x.d)}${x.p === 0 ? ' • ทดลองได้คนละ 1 ครั้ง' : ''}</small></span>
            <b class="pl-price">${x.p === 0 ? '<span style="color:var(--ok,#2a9d5c)">ทดลองฟรี</span>' : `${x.op ? `<s class="was">${money(x.op)}</s> ` : ''}${money(x.p)} ฿`}</b>
          </label>`).join('')}
      </div>
      <label class="lbl">โค้ดส่วนลด (ถ้ามี)</label>
      <div class="coupon">
        <input id="buyCoupon" placeholder="เช่น SAVE10" value="${esc(C.coupon)}" autocomplete="off"
          oninput="C.coupon=this.value.toUpperCase()" onkeydown="if(event.key==='Enter'){event.preventDefault();applyCoupon()}">
        <button class="btn ghost" id="btnCoupon" onclick="applyCoupon()">ใช้โค้ด</button>
      </div>
      ${C.couponMsg ? `<div class="msg ${C.couponMsg.type} slim">${esc(C.couponMsg.text)}</div>` : ''}
      <ul class="includes">
        <li>สร้างบัญชีให้อัตโนมัติทันทีหลังชำระเงิน</li>
        <li>รับลิงก์ / ไฟล์เชื่อมต่อในหน้าประวัติ</li>
        <li>ต่ออายุบัญชีเดิมได้ภายหลัง</li>
      </ul>
      ${C.err ? `<div class="msg bad">${esc(C.err)}</div>` : ''}
      <div class="co-bar">
        <div class="co-total"><small>ยอดที่ต้องชำระ</small><b>${money(total)} ฿</b></div>
        <div class="co-actions">
          <button class="btn ghost" onclick="closeDlg()">ยกเลิก</button>
          <button class="btn" id="btnNext" onclick="goReview()">${S.user ? 'ตรวจสอบคำสั่งซื้อ →' : 'เข้าสู่ระบบเพื่อสั่งซื้อ →'}</button>
        </div>
      </div>
      ${p.reviews && p.reviews.length ? `
        <details class="rv">
          <summary>⭐ รีวิวจากผู้ใช้งาน (${p.ratingCount})</summary>
          ${p.reviews.map(r => `
            <div class="review-item">
              <div><b>${esc(r.user)}</b> <span class="stars">${'★'.repeat(r.rating)}</span></div>
              <div style="color:var(--sub)">${esc(r.comment)}</div>
            </div>`).join('')}
        </details>` : ''}`;
  }

  if (C.step === 2 && C.quote) {
    const q = C.quote;
    const exp = new Date(Date.now() + Number(pl.mins || (pl.hours || 0) * 60) * 60e3);
    body = `
      <div class="sum">
        <div class="sum-row"><span>แพ็กเกจ</span><b>${esc(pl.n)}</b></div>
        <div class="sum-row"><span>อายุการใช้งาน</span><b>${esc(pl.d)}</b></div>
        <div class="sum-row"><span>ประมาณวันหมดอายุ</span><b>${fdt(exp.toISOString())}</b></div>
        ${p.serverName ? `<div class="sum-row"><span>เซิร์ฟเวอร์</span><b>${esc(p.serverName)}</b></div>` : ''}
        <div class="sum-row"><span>การส่งมอบ</span><b>อัตโนมัติทันที</b></div>
      </div>
      <div class="sum">
        <div class="sum-row"><span>ราคาแพ็กเกจ</span><b>${money(q.original)} ฿</b></div>
        ${q.shopPercent > 0 ? `<div class="sum-row ok"><span>ส่วนลดแพ็กเกจ (${q.shopPercent}%)</span><b>−${money(q.shopDiscount)} ฿</b></div>` : ''}
        ${q.percent > 0 ? `<div class="sum-row ok"><span>ส่วนลด ${esc(C.coupon)} (${q.percent}%)</span><b>−${money(q.couponDiscount ?? q.discount)} ฿</b></div>` : ''}
        <div class="sum-row total"><span>ยอดชำระสุทธิ</span><b>${money(q.total)} ฿</b></div>
      </div>
      <div class="wallet ${q.enough ? '' : 'low'}">
        <div><small>เครดิตของคุณ</small><b>${money(q.credit)} ฿</b></div>
        <div class="arrow">→</div>
        <div><small>คงเหลือหลังชำระ</small><b>${q.enough ? money(q.after) : '—'} ฿</b></div>
      </div>
      ${q.blockError ? `<div class="msg bad">${esc(q.blockError)}</div>` : q.enough ? '' : `
        <div class="msg bad">เครดิตไม่พอ ขาดอีก <b>${money(q.shortfall)} ฿</b> กรุณาเติมเครดิตก่อนชำระเงิน</div>
        <button class="btn ok" style="width:100%" onclick="goTopupFromCheckout()">💳 ไปหน้าเติมเครดิต</button>`}
      ${C.err ? `<div class="msg bad">${esc(C.err)}</div>` : ''}
      <details class="terms" style="margin:12px 0;font-size:13px">
        <summary style="cursor:pointer;font-weight:700">📄 เงื่อนไขการใช้บริการและนโยบายคืนเงิน</summary>
        <div style="white-space:pre-wrap;margin-top:8px;color:var(--muted,inherit)">${esc(S.site.terms_text || DEFAULT_TERMS)}</div>
      </details>
      <label class="agree">
        <input type="checkbox" ${C.agree ? 'checked' : ''} onchange="C.agree=this.checked;$('btnPay').disabled=!(C.agree&&C.quote&&C.quote.enough)">
        <span>ฉันตรวจสอบรายการแล้ว และเข้าใจว่าเป็นสินค้าดิจิทัล ระบบจะสร้างบัญชีและ<b>หักเครดิตทันที</b>เมื่อกดชำระเงิน</span>
      </label>
      <div class="co-bar">
        <button class="btn ghost" onclick="backToPlans()">← กลับ</button>
        <button class="btn pay" id="btnPay" onclick="doPay()" ${C.agree && q.enough ? '' : 'disabled'}>🔒 ชำระเงิน ${money(q.total)} ฿</button>
      </div>`;
  }

  if (C.step === 3 && !C.result) {
    body = `
      <div class="processing">
        <div class="spinner"></div>
        <b>กำลังสร้างบัญชีของคุณ...</b>
        <ul class="proc-steps"><li>ตรวจสอบเครดิต</li><li>เชื่อมต่อเซิร์ฟเวอร์</li><li>สร้างบัญชี & ลิงก์เชื่อมต่อ</li></ul>
        <small>กรุณาอย่าปิดหน้านี้</small>
      </div>`;
  }

  if (C.step === 3 && C.result) {
    const r = C.result;
    body = `
      <div class="success">
        <div class="check"><svg viewBox="0 0 52 52"><circle cx="26" cy="26" r="24"/><path d="M14 27l8 8 16-17"/></svg></div>
        <h4>สั่งซื้อสำเร็จ!</h4>
        <p>ออเดอร์ <b>#${r.order}</b> • ชำระแล้ว <b>${money(r.paid)} ฿</b></p>
      </div>
      ${successInfoHtml(r)}
      <div class="co-bar">
        <button class="btn ghost" onclick="closeDlg()">ซื้อเพิ่ม</button>
        <button class="btn" onclick="closeDlg();go('history')">ดูในประวัติ & ไฟล์ →</button>
      </div>`;
  }

  $('dlgBody').innerHTML = head + `<div class="co-body" key="${C.step}">${body}</div>`;
}

// =====================================================
// CUSTOMER: TOPUP, HISTORY, SUPPORT, AUTH
// =====================================================
function viewTopup() {
  if (!S.user) return viewAuth();
  const s = S.site;
  const minTopup = Number(s.min_topup_amount || 20);
  const bonusMin = Number(s.bonus_min_amount || 100);
  const bonusPct = Number(s.bonus_percent || 0);

  return `
    <div class="panel">
      <h2>💳 เติมเครดิตเข้าบัญชี</h2>
      <div style="display:flex;justify-content:space-between;align-items:center;padding:12px 14px;background:var(--brand-soft);border-radius:12px;margin-bottom:14px">
        <span>ยอดเครดิตคงเหลือ</span>
        <b style="font-size:20px;color:var(--brand)">${money(S.credit)} ฿</b>
      </div>
      ${s.bankName || s.bankNo ? `
        <div style="padding:12px 14px;border:1px solid var(--line);border-radius:12px;margin-bottom:14px;font-size:13.5px">
          <div><b>ช่องทางโอนเงิน:</b> ${esc(s.bankName || '-')}</div>
          <div><b>เลขบัญชี / พร้อมเพย์:</b> <span style="font-size:16px;font-weight:800;color:var(--brand)">${esc(s.bankNo || '-')}</span></div>
          <div><b>ชื่อบัญชี:</b> ${esc(s.bankHolder || '-')}</div>
        </div>
      ` : ''}
      <div class="hint" style="margin-bottom:10px">
        • เติมเงินขั้นต่ำ <b>${money(minTopup)} บาท</b>
        ${bonusPct > 0 ? `<br>• โปรโมชั่น: เติมตั้งแต่ <b>${money(bonusMin)} บาท</b> รับโบนัสเพิ่มทันที <b>+${bonusPct}%</b>` : ''}
      </div>
      ${msgHtml()}
      <label>ช่องทางการเติมเงิน</label>
      <select id="tpMethod" onchange="toggleTopupMethod()">
        <option value="bank">โอนผ่านธนาคาร / สแกน QR (แนบสลิป)</option>
        <option value="truemoney">ซองอั่งเปา TrueMoney Wallet</option>
      </select>

      <label>จำนวนเงิน (บาท) — ขั้นต่ำ ${minTopup} บาท</label>
      <input id="tpAmount" type="number" min="${minTopup}" step="1" value="${Math.max(minTopup, 50)}">
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">
        ${[minTopup, 50, 100, 300, 500].filter((v, i, a) => v >= minTopup && a.indexOf(v) === i).map(v =>
          `<button type="button" class="btn ghost sm" onclick="$('tpAmount').value=${v}">${v} ฿</button>`
        ).join('')}
      </div>

      <div id="tpBankBox">
        <label>อัปโหลดรูปสลิปโอนเงิน</label>
        <input id="tpSlipFile" type="file" accept="image/*">
      </div>
      <div id="tpTmnBox" style="display:none">
        <label>ลิงก์ซองอั่งเปา TrueMoney</label>
        <input id="tpTmnUrl" placeholder="https://gift.truemoney.com/campaign/?v=...">
      </div>

      <button class="btn" style="width:100%;margin-top:16px" id="btnTopup" onclick="submitTopup()">แจ้งเติมเงิน</button>

      ${S.topups.length ? `
        <h3 style="margin-top:26px;font-size:15.5px">ประวัติการเติมเงินล่าสุด</h3>
        <div class="table-wrap">
          <table>
            <thead><tr><th>วันที่</th><th>ช่องทาง</th><th>ยอดเงิน</th><th>สถานะ</th></tr></thead>
            <tbody>
              ${S.topups.map(t => `
                <tr>
                  <td>${fdt(t.created_at)}</td>
                  <td>${t.method === 'bank' ? 'โอนธนาคาร' : 'TrueMoney'}</td>
                  <td><b>${money(t.amount)} ฿</b>${Number(t.bonus_amount) > 0 ? ` <small style="color:var(--ok)">(+${money(t.bonus_amount)})</small>` : ''}</td>
                  <td><span class="tag ${topupStClass(t.status)}">${topupStTh(t.status)}</span></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      ` : ''}
    </div>
  `;
}

const TOPUP_ST = { pending: 'รอตรวจสอบ', approved: 'อนุมัติแล้ว', rejected: 'ปฏิเสธ' };
const topupStTh = st => TOPUP_ST[st] || String(st || '-');
const topupStClass = st => st === 'approved' ? 'ok' : st === 'rejected' ? 'bad' : 'promo';
const TOPUP_METHOD = { bank: 'โอนธนาคาร', truemoney: 'TrueMoney' };

function toggleTopupMethod() {
  const m = $('tpMethod').value;
  $('tpBankBox').style.display = m === 'bank' ? 'block' : 'none';
  $('tpTmnBox').style.display = m === 'truemoney' ? 'block' : 'none';
}

async function submitTopup() {
  const method = $('tpMethod').value;
  const amount = parseFloat($('tpAmount').value);
  const btn = $('btnTopup');
  btn.disabled = true;
  try {
    let proof = '';
    if (method === 'bank') {
      const f = $('tpSlipFile').files[0];
      if (!f) throw new Error('กรุณาเลือกรูปสลิปโอนเงิน');
      proof = await readImg(f, 1000);
    } else {
      proof = $('tpTmnUrl').value.trim();
    }
    const res = await api('/topup', { method: 'POST', body: { method, amount, proof } });
    await refreshAll();
    if (res.autoApproved) {
      showMsg('ok', `ตรวจสอบสลิปสำเร็จ! เติมเครดิต ${money(amount + (res.bonusAmount || 0))} บาท เข้าบัญชีเรียบร้อย`);
    } else {
      showMsg('ok', 'ส่งข้อมูลแจ้งเติมเงินเรียบร้อยแล้ว สถานะ: รอตรวจสอบ — ระบบจะปรับยอดให้ทันทีหลังตรวจสอบ');
    }
  } catch (e) {
    showMsg('bad', e.message);
  } finally {
    if ($('btnTopup')) $('btnTopup').disabled = false;
  }
}

// =====================================================
// EXPORT: NPV Tunnel / NetMod / Dark Tunnel
// =====================================================
const b64 = s => btoa(unescape(encodeURIComponent(String(s))));

function parseAccount(text) {
  const t = String(text || '');
  const pick = re => (t.match(re) || [])[0] || '';
  const g = re => { const m = t.match(re); return m ? m[1].trim() : ''; };
  const a = {
    npv: pick(/npvt-ssh:\/\/[^\s]+/),
    netmod: pick(/(?<![\w-])ssh:\/\/[^\s]+/),
    v2: pick(/(?:vless|vmess|trojan):\/\/[^\s]+/),
    f: {
      host: g(/\bhost\s*[:=]\s*([^\s]+)/i),
      port: g(/\bport\s*[:=]\s*([^\s]+)/i),
      user: g(/\buser(?:name)?\s*[:=]\s*([^\s]+)/i),
      pass: g(/\bpass(?:word)?\s*[:=]\s*([^\s]+)/i),
      sni: g(/\bsni\s*[:=]\s*([^\s]+)/i),
      payload: g(/^\s*payload\s*[:=]\s*(.+)$/im),
      // รองรับทั้ง "Proxy: x" และ "HTTP Proxy: x" (ข้อความ NetMod ของ xxtlonline) — ค่า "-" = ไม่มี
      proxy: g(/^\s*(?:http\s*)?proxy\s*[:=]\s*(.+)$/im).replace(/^-$/, '')
    },
    v: null
  };
  // ข้อความบัญชีไม่มีบรรทัด Proxy/Payload → อ่านจากลิงก์ NPV (npvs1: + base64) ที่แดชบอร์ด xxtlonline ใส่มาให้
  if (a.npv && (!a.f.proxy || !a.f.payload)) {
    try {
      const j = JSON.parse(atob(a.npv.slice('npvt-ssh://'.length)));
      const un = v => (typeof v === 'string' && v.startsWith('npvs1:')) ? decodeURIComponent(escape(atob(v.slice(6)))) : '';
      a.f.proxy = a.f.proxy || un(j.httpProxy);
      a.f.payload = a.f.payload || un(j.payload);
    } catch { /* ignore */ }
  }
  if (a.netmod && (!a.f.host || !a.f.user)) {
    try {
      const u = new URL(a.netmod);
      a.f.host = a.f.host || u.hostname;
      a.f.port = a.f.port || u.port;
      a.f.user = a.f.user || decodeURIComponent(u.username);
      a.f.pass = a.f.pass || decodeURIComponent(u.password);
    } catch { /* ignore */ }
  }
  if (a.v2 && /^(vless|trojan):/.test(a.v2)) {
    try {
      const u = new URL(a.v2);
      const p = u.searchParams;
      a.v = {
        type: u.protocol.replace(':', '').toUpperCase(), host: u.hostname, port: u.port,
        id: decodeURIComponent(u.username), network: p.get('type') || 'tcp', security: p.get('security') || 'none',
        path: p.get('path') || '', sni: p.get('sni') || p.get('host') || ''
      };
    } catch { /* ignore */ }
  } else if (a.v2 && /^vmess:/.test(a.v2)) {
    try {
      const j = JSON.parse(decodeURIComponent(escape(atob(a.v2.slice(8)))));
      a.v = { type: 'VMESS', host: j.add, port: j.port, id: j.id, network: j.net, security: j.tls || 'none', path: j.path || '', sni: j.sni || j.host || '' };
    } catch { /* ignore */ }
  }
  return a;
}

// Dark Tunnel: darktunnel://<base64(JSON)> — โครงสร้างตรงกับลิงก์ที่แอปส่งออกจริง
// {type, name, sshTunnelConfig:{ sshConfig:{host,port,username,password}, injectConfig:{mode,proxyHost,proxyPort,payload} }}
// payload ใช้โทเคนของแอป: [crlf] [host] [ua] [split] (ไม่ใช่ \r\n จริง)
function darkPayload(raw, host) {
  const t = String(raw || '');
  if (!t.trim()) return 'GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf][crlf]';
  return t.replace(/\{host\}/gi, '[host]').replace(/\r\n|\n/g, '[crlf]');
}
function buildDarkLink(f, name) {
  const host = String(f.host || '').trim();
  const port = Number(f.port) || 80;
  const px = String(f.proxy || '').trim().replace(/^https?:\/\//i, '');
  const pm = px.match(/^(.+?)(?::(\d+))?$/);
  // ไม่มี proxy → ใช้เซิร์ฟเวอร์เองเป็นปลายทางของ payload (โหมด PROXY โหมดเดียวที่ยืนยันชื่อกับแอปแล้ว)
  const proxyHost = pm && pm[1] ? pm[1] : host;
  const proxyPort = pm && pm[1] ? (Number(pm[2]) || 80) : port;
  const o = {
    type: 'SSH',
    name: String(name),
    sshTunnelConfig: {
      sshConfig: { host, port, username: f.user, password: f.pass },
      injectConfig: { mode: 'PROXY', proxyHost, proxyPort, payload: darkPayload(f.payload, host) }
    }
  };
  return 'darktunnel://' + b64(JSON.stringify(o));
}

function buildNpvLink(f, name) {
  const w = v => (v ? 'npvs1:' + b64(v) : '');
  const o = {
    sshConfigType: w(f.payload || f.proxy ? 'SSH-Proxy-Payload' : 'SSH-Direct'), remarks: w(name), sshHost: w(f.host), sshPort: Number(f.port) || 22,
    sshUsername: w(f.user), sshPassword: w(f.pass), sshAuthMethod: w('PASSWORD'), sshPrivateKey: '', sshPrivateKeyPassphrase: '',
    sni: f.sni || '', tlsVersion: w('DEFAULT'), httpProxy: w(f.proxy), authenticateProxy: false, proxyUsername: '', proxyPassword: '',
    payload: w(f.payload), dnsTTMode: w('UDP'), dnsServer: '', nameserver: '', publicKey: '', udpgwPort: 7300, udpgwTransparentDNS: true
  };
  return 'npvt-ssh://' + b64(JSON.stringify(o));
}

function exportFormats(account, orderId) {
  const a = parseAccount(account);
  const name = 'wselx-' + orderId;
  const ssh = !!(a.f.host && a.f.user && a.f.pass);
  const npv = a.npv || a.v2 || (ssh ? buildNpvLink(a.f, name) : '');
  const blobRaw = String((S.site && S.site.netmod_blob) || '').trim().replace(/\s+/g, '');
  const blob = blobRaw.includes('?') ? blobRaw.slice(blobRaw.indexOf('?') + 1) : blobRaw;
  const hasBlob = !!blob && !/^ssh:\/\//.test(blob);
  const nmOwn = a.netmod && /@[^?\s]+\?\S{40,}/.test(a.netmod) ? a.netmod : '';
  const nmEnc = ssh && hasBlob ? `ssh://${encodeURIComponent(a.f.user)}:${encodeURIComponent(a.f.pass)}@${a.f.host}:${a.f.port || 22}?${blob}` : '';
  const nm = nmOwn || nmEnc || a.netmod || a.v2 ||
    (ssh ? `ssh://${encodeURIComponent(a.f.user)}:${encodeURIComponent(a.f.pass)}@${a.f.host}:${a.f.port || 22}#${encodeURIComponent(name)}` : '');
  const nmIsEnc = !!(nmOwn || nmEnc);
  const dark = ssh ? buildDarkLink(a.f, name) : '';

  const rows = [];
  if (a.v) {
    rows.push(['ประเภท', a.v.type], ['Address', a.v.host], ['Port', a.v.port], ['UUID / ID', a.v.id], ['Network', a.v.network],
      ['Security', a.v.security], ['WS Path', a.v.path], ['SNI / Host', a.v.sni]);
  } else if (ssh) {
    rows.push(['ประเภท', 'SSH'], ['Host', a.f.host], ['Port', a.f.port || '22'], ['Username', a.f.user], ['Password', a.f.pass], ['SNI', a.f.sni], ['Proxy', a.f.proxy], ['Payload', a.f.payload]);
  }
  const sheet = rows.length
    ? `Dark Tunnel — ข้อมูลสำหรับตั้งค่า (${name})\n` + rows.filter(r => r[1]).map(r => `${r[0]}: ${r[1]}`).join('\n') +
      (a.v2 ? `\n\nลิงก์ต้นฉบับ:\n${a.v2}` : '')
    : '';

  return [
    { id: 'npv', label: 'NPV Tunnel', icon: '🛡️', text: npv, file: `${name}-npv-tunnel.txt`,
      note: 'คัดลอกลิงก์ แล้วเปิด NPV Tunnel → กดเมนู/+ → Import from clipboard' + (!a.npv && !a.v2 && ssh ? ' (ลิงก์นี้สร้างจากข้อมูล SSH พื้นฐาน ยังไม่มีพารามิเตอร์ payload/proxy)' : '') },
    { id: 'netmod', label: 'NetMod', icon: '🌐', text: nm, file: `${name}-netmod.${nmIsEnc ? 'nm' : 'txt'}`, ext: nmIsEnc ? '.nm' : '.txt',
      extra: nmIsEnc ? '' : [a.f.payload && 'Payload: ' + a.f.payload, a.f.proxy && 'Proxy: ' + a.f.proxy, a.f.sni && 'SNI: ' + a.f.sni].filter(Boolean).join('\n'),
      note: nmIsEnc ? 'คัดลอกลิงก์ แล้วเปิด NetMod → เมนู ⋮ → Import config from clipboard (ลิงก์นี้พก payload/SNI ที่เข้ารหัสไว้ครบแล้ว)' : 'คัดลอกลิงก์ แล้วเปิด NetMod → เมนู ⋮ → Import config from clipboard' },
    { id: 'dark', label: 'Dark Tunnel', icon: '🌑', text: dark || sheet, file: dark ? `${name}-darktunnel.txt` : `${name}-darktunnel-info.txt`,
      extra: dark ? '' : undefined,
      note: dark
        ? 'คัดลอกลิงก์ darktunnel:// แล้วเปิด Dark Tunnel → เมนู Import → Import from clipboard (ลิงก์พก payload/proxy ครบแล้ว)'
        : 'Dark Tunnel ใช้ไฟล์ .dark ที่เข้ารหัสเฉพาะแอป จึงให้ข้อมูลสำหรับกรอกในแอป จากนั้นใช้ Config → Export → File เพื่อสร้างไฟล์ .dark ของคุณเอง' }
  ];
}

const EXP = {};
function exportPanel(scope, account, orderId) {
  EXP[scope] = { account, orderId, sel: 'npv' };
  return `<div class="export" id="exp-${scope}"><div class="lbl" style="margin-top:14px">ส่งออกสำหรับแอป</div>${exportInner(scope)}</div>`;
}
function expCur(scope) {
  const e = EXP[scope];
  const fm = exportFormats(e.account, e.orderId);
  return fm.find(x => x.id === e.sel) || fm[0];
}
function exportInner(scope) {
  const e = EXP[scope];
  const fm = exportFormats(e.account, e.orderId);
  const cur = fm.find(x => x.id === e.sel) || fm[0];
  return `
    <div class="exp-tabs">${fm.map(x =>
      `<button aria-pressed="${x.id === cur.id}" onclick="selExport('${scope}','${x.id}')">${x.icon} ${x.label}</button>`).join('')}</div>
    ${cur.text
      ? `<div class="acct">${esc(cur.text)}</div>
         <div class="hint">${esc(cur.note)}</div>
         ${cur.extra ? `<div class="hint" style="margin-top:8px"><b>ลิงก์ ssh:// พก payload/SNI/proxy ไม่ได้ ให้ตั้งค่าเหล่านี้เพิ่มในแอป:</b></div><div class="acct">${esc(cur.extra)}</div>` : ''}
         <div class="co-actions wrap">
           <button class="btn sm" onclick="copyIn(this, expCur('${scope}').text)">📋 คัดลอก${cur.id === 'dark' ? 'ข้อมูล' : 'ลิงก์'}</button>
           <button class="btn ghost sm" onclick="const c=expCur('${scope}');downloadConfig(c.file,c.text)">⬇️ ดาวน์โหลดไฟล์ (${cur.ext || '.txt'})</button>
         </div>`
      : `<div class="msg bad slim">ไม่พบข้อมูลบัญชีที่แปลงเป็นรูปแบบนี้ได้ กรุณาใช้ข้อมูลเชื่อมต่อด้านบนหรือแจ้งแอดมิน</div>`}`;
}
function selExport(scope, id) {
  EXP[scope].sel = id;
  const el = $('exp-' + scope);
  if (el) el.innerHTML = `<div class="lbl" style="margin-top:14px">ส่งออกสำหรับแอป</div>` + exportInner(scope);
}

function copyText(txt) {
  // ใช้ toast อย่างเดียว ไม่เรียก render() เพื่อไม่ให้หน้า/ส่วนที่กางไว้ถูกรีเซ็ต
  clip(txt).then(ok => toast(ok ? 'ok' : 'bad', ok ? 'คัดลอกเรียบร้อยแล้ว' : 'คัดลอกไม่สำเร็จ — กดค้างที่ข้อความแล้วเลือกคัดลอกเอง'));
}

function downloadConfig(filename, content) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

const fmtBytes = n => {
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0, v = Number(n) || 0;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return v.toFixed(i ? 2 : 0) + ' ' + u[i];
};
async function loadUsage() {
  try {
    S.usage = await api('/orders/usage');
    if (S.view === 'history') render();
  } catch { /* ไม่แสดงข้อมูลการใช้งานถ้าดึงไม่ได้ */ }
}
function usageBar(o) {
  const u = (S.usage || {})[o.id];
  if (!u) return '';
  const pct = u.total > 0 ? Math.min(100, Math.round(u.used / u.total * 100)) : 0;
  return `<div style="margin:0">
    <div class="hint" style="margin:0 0 4px">📶 ใช้ข้อมูลไปแล้ว <b>${fmtBytes(u.used)}</b> ${u.total > 0 ? `จาก ${fmtBytes(u.total)} (${pct}%)` : '(ไม่จำกัดโควตา)'}</div>
    ${u.total > 0 ? `<div style="height:7px;border-radius:99px;background:var(--line);overflow:hidden"><div style="height:100%;width:${pct}%;background:${pct >= 90 ? 'var(--bad)' : 'var(--brand)'}"></div></div>` : ''}
  </div>`;
}

function expiryBanner() {
  if (!S.user) return '';
  const soon = S.orders.filter(o => o.status === 'active' && !o.autoRenew && new Date(o.exp) - Date.now() < 3 * 864e5 && new Date(o.exp) > Date.now());
  if (!soon.length) return '';
  return `<div class="msg bad" style="cursor:pointer" onclick="go('history')">⏰ มี ${soon.length} บัญชีใกล้หมดอายุภายใน 3 วัน (${soon.map(o => '#' + o.id + ' หมด ' + fdt(o.exp)).join(', ')}) — กดเพื่อไปต่ออายุหรือเปิดต่ออายุอัตโนมัติ</div>`;
}

async function toggleAutoRenew(id, on) {
  try {
    await api('/orders/' + id + '/auto-renew', { method: 'POST', body: { enabled: on } });
    await refreshAll();
    showMsg('ok', on ? 'เปิดต่ออายุอัตโนมัติแล้ว (ตัดเครดิตก่อนหมดอายุประมาณ 6 ชั่วโมง ถ้าเครดิตพอ)' : 'ปิดต่ออายุอัตโนมัติแล้ว');
  } catch (e) { showMsg('bad', e.message); }
}

async function open2faSetup() {
  try {
    const r = await api('/admin/2fa/setup', { method: 'POST' });
    $('dlgBody').innerHTML = `
      <h3>🛡️ เปิดใช้ 2FA</h3>
      <p class="hint" style="margin-top:0">ในแอป Google Authenticator / Authy เลือก "ป้อนคีย์ตั้งค่า" แล้วกรอกคีย์ด้านล่าง (ประเภทตามเวลา)</p>
      <div class="acct" style="text-align:center;font-weight:800;letter-spacing:2px;word-break:break-all">${esc(r.secret)}</div>
      <button class="btn ghost sm" style="margin-top:8px" onclick="copyText('${esc(r.secret)}')">📋 คัดลอกคีย์</button>
      <label>กรอกรหัส 6 หลักจากแอปเพื่อยืนยัน</label>
      <input id="tfCode" inputmode="numeric" maxlength="6" placeholder="123456">
      <div class="hint">⚠️ ถ้าทำมือถือหาย จะเข้าระบบแอดมินไม่ได้ ต้องแก้ในฐานข้อมูลเอง จดคีย์นี้เก็บไว้ในที่ปลอดภัย</div>
      <div id="tfErr" class="msg bad slim" style="display:none"></div>
      <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">
        <button class="btn ghost" onclick="$('dlg').close()">ปิด</button>
        <button class="btn" onclick="submit2faEnable()">ยืนยันและเปิดใช้</button>
      </div>`;
    $('dlg').showModal();
  } catch (e) { showMsg('bad', e.message); }
}
async function submit2faEnable() {
  try {
    await api('/admin/2fa/enable', { method: 'POST', body: { code: $('tfCode').value } });
    $('dlg').close();
    await refreshAll();
    showMsg('ok', 'เปิดใช้ 2FA แล้ว ครั้งต่อไปที่ล็อกอินต้องกรอกรหัสจากแอป');
  } catch (e) { $('tfErr').textContent = e.message; $('tfErr').style.display = ''; }
}
function open2faDisable() {
  $('dlgBody').innerHTML = `
    <h3>🛡️ ปิด 2FA</h3>
    <label>รหัสผ่านปัจจุบัน</label><input id="tdPass" type="password" autocomplete="current-password">
    <label>รหัส 2FA 6 หลัก</label><input id="tdCode" inputmode="numeric" maxlength="6">
    <div id="tdErr" class="msg bad slim" style="display:none"></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">
      <button class="btn ghost" onclick="$('dlg').close()">ปิด</button>
      <button class="btn danger" onclick="submit2faDisable()">ปิด 2FA</button>
    </div>`;
  $('dlg').showModal();
}
async function submit2faDisable() {
  try {
    await api('/admin/2fa/disable', { method: 'POST', body: { password: $('tdPass').value, code: $('tdCode').value } });
    $('dlg').close();
    await refreshAll();
    showMsg('ok', 'ปิด 2FA แล้ว');
  } catch (e) { $('tdErr').textContent = e.message; $('tdErr').style.display = ''; }
}

function viewHistory() {
  if (!S.user) return viewAuth();
  const s = S.site;
  return `
    ${msgHtml()}
    ${expiryBanner()}
    <div class="section-card ref">
      <div class="ref-row">
        <div><small>🎁 รหัสแนะนำเพื่อน</small><b class="ref-code">${esc(S.user.referral_code || '-')}</b></div>
        <button class="btn ghost sm" onclick="copyIn(this,'${esc(S.user.referral_code || '')}')">📋 คัดลอก</button>
      </div>
      <div class="hint">เพื่อนสมัครด้วยรหัสนี้และเติมเงินครั้งแรก รับโบนัส ${money(s.referral_reward || 10)} ฿ • ชวนแล้ว ${S.user.referral_count || 0} คน</div>
    </div>

    <div class="section-card">
      <h3>🎨 โหมดแสดงผล</h3>
      <div style="display:flex;align-items:center;justify-content:space-between;gap:12px">
        <div class="hint" style="margin:0">สลับระหว่างโหมดสว่างและโหมดมืด (จำค่าไว้ในเครื่องนี้)</div>
        ${themeSwitchHtml()}
      </div>
    </div>

    <div class="section-card">
      <h3>🔐 ความปลอดภัย</h3>
      <div style="display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between">
        <div class="hint" style="margin:0">
          ${S.user.has_recovery ? '✅ มีรหัสกู้คืนแล้ว (ใช้ตั้งรหัสผ่านใหม่เมื่อลืม)' : '⚠️ ยังไม่มีรหัสกู้คืน — ถ้าลืมรหัสผ่านจะต้องให้แอดมินรีเซ็ต แนะนำให้สร้างไว้'}
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <button class="btn ghost sm" onclick="openChangePassword()">🔒 เปลี่ยนรหัสผ่าน</button>
          <button class="btn ghost sm" onclick="openRegenRecovery()">🔑 ${S.user.has_recovery ? 'สร้างรหัสกู้คืนใหม่' : 'สร้างรหัสกู้คืน'}</button>
          ${S.user.role === 'admin' ? (S.user.totp_enabled
            ? `<button class="btn ghost sm" onclick="open2faDisable()">🛡️ ปิด 2FA</button>`
            : `<button class="btn sm" onclick="open2faSetup()">🛡️ เปิด 2FA (แอดมิน)</button>`) : ''}
        </div>
      </div>
    </div>

    <div class="section-card">
      <h3>📦 บัญชีของฉัน <small class="cnt-s">${S.orders.length} รายการ</small></h3>
      ${S.orders.length
        ? `<div class="ord-list">${S.orders.map(orderCardHtml).join('')}</div>`
        : `<div class="empty">ยังไม่มีประวัติการสั่งซื้อ <br><br><button class="btn sm" onclick="go('shop')">เลือกดูแพ็กเกจ</button></div>`}
    </div>
  `;
}

// ---------- การ์ดออเดอร์แบบย่อ (หน้า "ประวัติ & ไฟล์") ----------
const ORD_ST = { active: ['ใช้งาน', 'ok'], expired: ['หมดอายุ', 'bad'], refunded: ['คืนเงินแล้ว', 'promo'], cancelled: ['ยกเลิก', 'bad'] };
const orderById = id => S.orders.find(x => Number(x.id) === Number(id));
const copyOrder = (btn, id) => { const o = orderById(id); if (o) copyIn(btn, o.a); };
const downloadOrder = id => { const o = orderById(id); if (o) downloadConfig('wselx-order-' + o.id + '.txt', o.a); };
const RQ = { id: 0, e: null, busy: false };
async function requestRefund(id) {
  try {
    const e = await api(`/orders/${id}/refund-estimate`);
    Object.assign(RQ, { id, e, busy: false });
    renderRefundRequest();
    if (!$('dlg').open) $('dlg').showModal();
  } catch (e) { toast('bad', e.message); }
}

function renderRefundRequest(err) {
  const e = RQ.e;
  $('dlgBody').innerHTML = `
    <button class="x" onclick="closeDlg()" aria-label="ปิด">×</button>
    <h3>💸 ขอคืนเงิน ออเดอร์ #${RQ.id}</h3>
    <div class="hint" style="margin:-4px 0 14px">${esc(e.title || '')} – ${esc(e.planName || '')}</div>
    <div class="rf-hero">
      <small>ยอดคืนโดยประมาณ (เป็นเครดิตในร้าน)</small>
      <b>${money(e.estimate)} ฿</b>
      <span>${e.remainingDays} วัน × ${money(e.ratePerDay)} ฿/วัน${e.capped ? ' (จำกัดไม่เกินยอดที่จ่าย)' : ''}</span>
    </div>
    <div class="sum">
      <div class="sum-row"><span>แพ็กเกจ</span><b>${esc(e.planName || '-')}</b></div>
      <div class="sum-row"><span>หมดอายุ</span><b>${e.expiresAt ? fdt(e.expiresAt) : '-'}</b></div>
      <div class="sum-row"><span>วันที่เหลือ</span><b>${e.remainingDays} วัน</b></div>
      <div class="sum-row"><span>ยอดที่คุณจ่ายไป</span><b>${money(e.paidTotal)} ฿</b></div>
    </div>
    <label for="rqReason">เหตุผลที่ขอคืนเงิน (ไม่บังคับ)</label>
    <textarea id="rqReason" rows="3" maxlength="500" placeholder="เช่น เชื่อมต่อไม่ได้ / ความเร็วช้า / ซื้อผิดแพ็กเกจ"></textarea>
    <ul class="rf-notes">
      <li>แอดมินจะตรวจสอบก่อนอนุมัติ ยอดจริงอาจต่างจากที่ประมาณไว้</li>
      <li>เมื่ออนุมัติ บัญชีนี้จะถูกปิดทันทีและต่ออายุไม่ได้อีก</li>
      <li>เงินคืนเป็นเครดิตในร้าน ดูสถานะได้ที่เมนู “แจ้งปัญหา”</li>
    </ul>
    <div id="rqErr">${err ? `<div class="msg bad">${esc(err)}</div>` : ''}</div>
    <div class="co-bar">
      <div class="co-total"><small>ยอดคืนโดยประมาณ</small><b>${money(e.estimate)} ฿</b></div>
      <div class="co-actions">
        <button class="btn ghost" onclick="closeDlg()">ยกเลิก</button>
        <button class="btn danger" id="btnRq" onclick="submitRefundRequest()">ส่งคำขอคืนเงิน</button>
      </div>
    </div>`;
}

async function submitRefundRequest() {
  if (RQ.busy) return;
  RQ.busy = true;
  const reason = ($('rqReason') || {}).value || '';
  const b = $('btnRq');
  b.disabled = true; b.textContent = 'กำลังส่ง...';
  try {
    await api(`/orders/${RQ.id}/refund-request`, { method: 'POST', body: { reason } });
    RQ.busy = false;
    $('dlgBody').innerHTML = `
      <div class="rf-done">
        <div class="rf-ok">✓</div>
        <h3>ส่งคำขอคืนเงินแล้ว</h3>
        <p class="hint">แอดมินจะตรวจสอบและแจ้งผลให้ทราบ ติดตามได้ที่เมนู “แจ้งปัญหา”</p>
        <button class="btn" onclick="closeDlg()">ตกลง</button>
      </div>`;
  } catch (e) {
    RQ.busy = false;
    renderRefundRequest(e.message);
  }
}
const reviewOrder = id => { const o = orderById(id); if (o) openReview(o.productId, o.n); };

function leftLabel(exp) {
  const ms = new Date(exp) - Date.now();
  if (!(ms > 0)) return { t: 'หมดอายุแล้ว', c: 'bad' };
  const d = Math.floor(ms / 864e5), h = Math.floor(ms % 864e5 / 36e5);
  if (d >= 1) return { t: `เหลือ ${d} วัน`, c: d < 3 ? 'warn' : 'ok' };
  return { t: h >= 1 ? `เหลือ ${h} ชม.` : 'เหลือไม่ถึง 1 ชม.', c: 'warn' };
}

// สรุปบัญชีบรรทัดเดียวสำหรับแสดงข้างปุ่มคัดลอก
function acctBrief(a) {
  const p = parseAccount(a);
  if (p.f.user && p.f.host) return `${p.f.user}@${p.f.host}${p.f.port ? ':' + p.f.port : ''}`;
  const link = p.v2 || p.npv || p.netmod;
  if (link) return link;
  return String(a || '').split('\n').map(x => x.trim()).find(Boolean) || '-';
}

// แถวข้อมูลสรุปบนการ์ดออเดอร์: แพ็กเกจ / User / การใช้ข้อมูล / วันหมดอายุ
function ordRow(label, valueHtml, extraHtml) {
  return `<div class="ord-row"><span class="k">${label}</span><span class="v">${valueHtml}</span>${extraHtml || ''}</div>`;
}
function ordUsageInner(o) {
  const u = (S.usage || {})[o.id];
  if (!u) return `<span class="k">การใช้ข้อมูล</span><span class="v">${S.usage ? '—' : 'กำลังโหลด…'}</span>`;
  const pct = u.total > 0 ? Math.min(100, Math.round(u.used / u.total * 100)) : 0;
  const val = u.total > 0
    ? `${fmtBytes(u.used)} <small>/ ${fmtBytes(u.total)} (${pct}%)</small>`
    : `${fmtBytes(u.used)} <small>(ไม่จำกัด)</small>`;
  const bar = u.total > 0
    ? `<i class="ord-bar"><b class="${pct >= 90 ? 'hot' : ''}" style="width:${pct}%"></b></i>` : '';
  return `<span class="k">การใช้ข้อมูล</span><span class="v">${val}</span>${bar}`;
}
function ordUsageRow(o) {
  return `<div class="ord-row" data-usage="${o.id}">${ordUsageInner(o)}</div>`;
}

// อัปเดตตัวเลขการใช้ข้อมูลแบบเรียลไทม์ (แก้เฉพาะแถวนั้น ไม่ render ทั้งหน้า → ไม่กระตุก/ไม่เสีย scroll)
let _usageBusy = false;
async function liveUsage() {
  if (_usageBusy || !S.user || S.view !== 'history' || document.hidden) return;
  _usageBusy = true;
  try {
    S.usage = await api('/orders/usage');
    document.querySelectorAll('[data-usage]').forEach(el => {
      const o = (S.orders || []).find(x => String(x.id) === el.dataset.usage);
      if (o) el.innerHTML = ordUsageInner(o);
    });
  } catch { /* ข้ามรอบนี้ */ } finally { _usageBusy = false; }
}
setInterval(liveUsage, 4000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) liveUsage(); });

function orderCardHtml(o) {
  const st = ORD_ST[o.status] || [String(o.status || '').toUpperCase(), 'bad'];
  const dead = o.status === 'refunded' || o.status === 'cancelled';
  const lf = dead ? null : leftLabel(o.exp);
  const canRenew = !dead && o.planPrice > 0;
  const pf = parseAccount(o.a);
  const user = pf.f.user || '-';
  return `
    <div class="ord ${dead ? 'dead' : ''}">
      <div class="ord-h">
        <div class="ord-t"><b>#${o.id}</b><span class="tag ${esc(o.net)}">${esc(o.net)}</span><span class="tag">${esc(o.proto)}</span></div>
        <span class="tag ${st[1]}">${st[0]}</span>
      </div>
      <div class="ord-info">
        ${ordRow('แพ็กเกจ', esc(o.n))}
        ${ordRow('User', `<code title="${esc(user)}">${esc(user)}</code>`)}
        ${dead ? '' : ordUsageRow(o)}
        ${ordRow(dead ? 'สั่งซื้อเมื่อ' : 'วันหมดอายุ', fdt(dead ? o.t : o.exp) + (lf ? ` <small class="lf ${lf.c}">${lf.t}</small>` : ''))}
      </div>
      ${dead ? '' : `
      <div class="ord-act">
        ${canRenew ? `<button class="btn ghost sm" onclick="renewOrder(${o.id})">🔄 ต่ออายุ ${money(o.planPrice)}฿</button>` : ''}
        ${canRenew ? `<button class="btn ghost sm ${o.autoRenew ? 'on' : ''}" onclick="toggleAutoRenew(${o.id}, ${!o.autoRenew})">🔁 ต่ออัตโนมัติ: ${o.autoRenew ? 'เปิด' : 'ปิด'}</button>` : ''}
        ${o.planPrice > 0 ? `<button class="btn ghost sm" onclick="requestRefund(${o.id})">💸 ขอคืนเงิน</button>` : ''}
        <button class="btn ghost sm" onclick="reviewOrder(${o.id})">⭐ รีวิว</button>
      </div>
      ${exportPanel('ord' + o.id, o.a, o.id)}`}
    </div>`;
}

function renewOrder(orderId) {
  const o = S.orders.find(x => x.id === orderId);
  if (!o) return;
  const price = Number(o.planPrice);
  const enough = S.credit >= price;
  const base = new Date(o.exp) > new Date() ? new Date(o.exp) : new Date();
  const newExp = new Date(base.getTime() + Number(o.hours || 0) * 3600e3);
  C.busy = false;
  $('dlgBody').innerHTML = `
    <button class="x" onclick="closeDlg()" aria-label="ปิด">×</button>
    <h3>🔄 ต่ออายุคำสั่งซื้อ #${o.id}</h3>
    <div class="tags"><span class="tag ${esc(o.net)}">${esc(o.net)}</span><span class="tag">${esc(o.proto)}</span></div>
    <div class="sum" style="margin-top:12px">
      <div class="sum-row"><span>แพ็กเกจ</span><b>${esc(o.n)}</b></div>
      <div class="sum-row"><span>หมดอายุปัจจุบัน</span><b>${fdt(o.exp)}</b></div>
      <div class="sum-row ok"><span>หมดอายุใหม่หลังต่ออายุ</span><b>${fdt(newExp.toISOString())}</b></div>
      <div class="sum-row total"><span>ยอดชำระ</span><b>${money(price)} ฿</b></div>
    </div>
    <div class="wallet ${enough ? '' : 'low'}">
      <div><small>เครดิตของคุณ</small><b>${money(S.credit)} ฿</b></div>
      <div class="arrow">→</div>
      <div><small>คงเหลือหลังชำระ</small><b>${enough ? money(S.credit - price) : '—'} ฿</b></div>
    </div>
    ${enough ? '' : `<div class="msg bad">เครดิตไม่พอ ขาดอีก <b>${money(price - S.credit)} ฿</b></div>`}
    <div id="rnErr"></div>
    <div class="co-bar">
      <button class="btn ghost" onclick="closeDlg()">ยกเลิก</button>
      ${enough
        ? `<button class="btn pay" id="btnRenew" onclick="confirmRenew(${o.id})">🔒 ยืนยันต่ออายุ ${money(price)} ฿</button>`
        : `<button class="btn ok" onclick="goTopupFromCheckout()">💳 เติมเครดิต</button>`}
    </div>`;
  if (!$('dlg').open) $('dlg').showModal();
}

async function confirmRenew(orderId) {
  const btn = $('btnRenew');
  btn.disabled = true;
  btn.textContent = 'กำลังต่ออายุ...';
  C.busy = true;
  try {
    const res = await api(`/orders/${orderId}/renew`, { method: 'POST' });
    C.busy = false;
    $('dlg').close();
    await refreshAll();
    showMsg('ok', `ต่ออายุคำสั่งซื้อ #${orderId} สำเร็จ! หมดอายุใหม่ ${fdt(res.newExpiresAt)}`);
  } catch (e) {
    C.busy = false;
    $('rnErr').innerHTML = `<div class="msg bad">${esc(e.message)}</div>`;
    btn.disabled = false;
    btn.textContent = 'ลองอีกครั้ง';
  }
}

function openReview(productId, title) {
  $('dlgBody').innerHTML = `
    <h3>รีวิวแพ็กเกจ: ${esc(title)}</h3>
    <label>คะแนนความพึงพอใจ</label>
    <select id="rvRating">
      <option value="5">★★★★★ (5 - ดีเยี่ยม)</option>
      <option value="4">★★★★☆ (4 - ดี)</option>
      <option value="3">★★★☆☆ (3 - ปานกลาง)</option>
      <option value="2">★★☆☆☆ (2 - พอใช้)</option>
      <option value="1">★☆☆☆☆ (1 - ควรปรับปรุง)</option>
    </select>
    <label>ความคิดเห็น</label>
    <textarea id="rvComment" rows="3" placeholder="ความเร็วเน็ตเป็นอย่างไรบ้าง แชร์ประสบการณ์ให้เพื่อนสมาชิก..."></textarea>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">
      <button class="btn ghost" onclick="$('dlg').close()">ปิด</button>
      <button class="btn" onclick="submitReview(${productId})">บันทึกรีวิว</button>
    </div>
  `;
  $('dlg').showModal();
}

async function submitReview(productId) {
  try {
    await api('/reviews', {
      method: 'POST',
      body: { productId, rating: Number($('rvRating').value), comment: $('rvComment').value }
    });
    $('dlg').close();
    await refreshAll();
    showMsg('ok', 'ขอบคุณสำหรับรีวิวของคุณ!');
  } catch (e) {
    alert(e.message);
  }
}

function viewSupport() {
  if (!S.user) return viewAuth();
  return `
    <div class="panel" style="max-width:720px">
      <h2>🛠️ แจ้งปัญหาการใช้งาน / ติดต่อแอดมิน</h2>
      ${msgHtml()}
      <label>อ้างอิงคำสั่งซื้อ (ถ้ามี)</label>
      <select id="tkOrder">
        <option value="">-- ไม่ระบุคำสั่งซื้อ --</option>
        ${S.orders.map(o => `<option value="${o.id}">#${o.id} - ${esc(o.n)}</option>`).join('')}
      </select>
      <label>หัวข้อปัญหา</label>
      <input id="tkSubject" placeholder="เช่น เชื่อมต่อไม่ได้ / ขอเปลี่ยนเซิร์ฟเวอร์">
      <label>รายละเอียด</label>
      <textarea id="tkMsg" rows="3" placeholder="อธิบายปัญหาที่พบ เครือข่ายที่ใช้ หรือข้อความ Error..."></textarea>
      <button class="btn" style="margin-top:14px" onclick="submitTicket()">ส่งแจ้งปัญหา</button>

      <h3 style="margin-top:28px;font-size:16px">รายการแจ้งปัญหาของคุณ (${S.tickets.length})</h3>
      ${S.tickets.length ? S.tickets.map(t => {
        const st = tkStatus(t.status);
        const thread = tkThread(t);
        return `
        <div style="border:1px solid ${t.unread ? 'var(--brand)' : 'var(--line)'};border-radius:12px;padding:14px;margin-top:10px">
          <div style="display:flex;justify-content:space-between;align-items:center;gap:8px">
            <b>#${t.id} • ${esc(t.subject)} ${t.unread ? '<span class="nbadge inline">ใหม่</span>' : ''}</b>
            <span class="tag ${st.cls}" style="white-space:nowrap">${st.label}</span>
          </div>
          <div class="hint">${fdt(t.created_at)}</div>
          <div style="margin-top:10px;display:flex;flex-direction:column;gap:8px">
            ${thread.map(m => `
              <div style="align-self:${m.sender === 'admin' ? 'flex-start' : 'flex-end'};max-width:88%">
                <div class="${m.sender === 'admin' ? 'msg ok' : ''}" style="${m.sender === 'admin' ? 'margin:0' : 'background:var(--line);border-radius:12px;padding:10px 12px'};font-size:14px;white-space:pre-wrap;word-break:break-word">${m.sender === 'admin' ? '<b>แอดมิน:</b> ' : ''}${esc(m.body)}</div>
                <div class="hint" style="font-size:11px;text-align:${m.sender === 'admin' ? 'left' : 'right'}">${m.sender === 'admin' ? 'แอดมิน' : 'คุณ'} • ${fdt(m.created_at)}</div>
              </div>`).join('')}
          </div>
          ${t.status === 'closed'
            ? `<div class="hint" style="margin-top:12px">🔒 แอดมินปิดเรื่องนี้แล้ว หากยังมีปัญหา กรุณาแจ้งเรื่องใหม่ด้านบน</div>`
            : `<div style="margin-top:12px">
                <textarea id="tkr_${t.id}" rows="2" maxlength="2000" placeholder="พิมพ์ข้อความตอบกลับแอดมิน..." oninput="S.tkDraft[${t.id}]=this.value">${esc(S.tkDraft[t.id] || '')}</textarea>
                <button class="btn sm" style="margin-top:8px" onclick="userReplyTicket(${t.id})">ส่งข้อความ</button>
              </div>`}
        </div>`;
      }).join('') : `<div class="empty">ยังไม่มีประวัติการแจ้งปัญหา</div>`}
    </div>
  `;
}

// สถานะเรื่องแจ้งปัญหา (ภาษาไทย)
function tkStatus(st) {
  if (st === 'closed') return { label: 'ปิดเรื่องแล้ว', cls: '' };
  if (st === 'answered') return { label: 'แอดมินตอบแล้ว', cls: 'ok' };
  return { label: 'รอแอดมินตอบ', cls: 'promo' };
}
// ลำดับข้อความ: ข้อความแรกของลูกค้า + ข้อความโต้ตอบ (ตั๋วเก่าที่ยังไม่มีข้อความ ใช้ reply เดิมแทน)
function tkThread(t) {
  const first = { sender: 'user', body: t.message, created_at: t.created_at };
  const rest = (t.messages && t.messages.length) ? t.messages
    : (t.reply ? [{ sender: 'admin', body: t.reply, created_at: t.updated_at }] : []);
  return [first, ...rest];
}
async function userReplyTicket(id) {
  const box = $('tkr_' + id);
  const text = box ? box.value.trim() : '';
  if (!text) return showMsg('bad', 'กรุณาพิมพ์ข้อความ');
  try {
    await api(`/tickets/${id}/reply`, { method: 'POST', body: { message: text } });
    delete S.tkDraft[id];
    await refreshAll();
    showMsg('ok', 'ส่งข้อความถึงแอดมินแล้ว');
  } catch (e) {
    S.tkDraft[id] = text;
    showMsg('bad', e.message);
  }
}

async function submitTicket() {
  try {
    await api('/tickets', {
      method: 'POST',
      body: {
        orderId: $('tkOrder').value ? Number($('tkOrder').value) : null,
        subject: $('tkSubject').value,
        message: $('tkMsg').value
      }
    });
    await refreshAll();
    showMsg('ok', 'ส่งเรื่องแจ้งปัญหาเรียบร้อยแล้ว แอดมินจะรีบตรวจสอบให้ครับ');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

function viewAuth() {
  const reg = S.authMode === 'register';
  const d = S.authDraft;
  const hasTs = !!S.site.turnstile_site_key;
  return `
    <div class="panel" style="max-width:440px">
      <h2>${reg ? 'สมัครสมาชิก' : 'เข้าสู่ระบบ'}</h2>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:4px 0 6px">
        <button class="btn ${reg ? 'ghost' : ''}" onclick="setAuthMode('login')">เข้าสู่ระบบ</button>
        <button class="btn ${reg ? '' : 'ghost'}" onclick="setAuthMode('register')">สมัครสมาชิก</button>
      </div>
      ${S.authNote ? `<div class="msg ok">${esc(S.authNote)}</div>` : ''}
      ${msgHtml()}
      <label>1. ชื่อผู้ใช้ (ภาษาอังกฤษหรือตัวเลข 3-30 ตัว)</label>
      <input id="auUser" autocomplete="username" autocapitalize="none" placeholder="username" value="${esc(d.u)}">
      <label>${reg ? '2. ' : ''}รหัสผ่าน (อย่างน้อย 6 ตัวอักษร)</label>
      <input id="auPass" type="password" autocomplete="${reg ? 'new-password' : 'current-password'}" placeholder="••••••" value="${esc(d.p)}">
      ${reg ? `
      <label>3. ยืนยันรหัสผ่าน</label>
      <input id="auPass2" type="password" autocomplete="new-password" placeholder="กรอกรหัสผ่านอีกครั้ง" value="${esc(d.p2)}">
      <label>รหัสแนะนำเพื่อน (ไม่บังคับ)</label>
      <input id="auRef" placeholder="เช่น NPXXXXXX" value="${esc(d.r)}">
      ${hasTs ? `<label>4. ยืนยันว่าไม่ใช่บอท</label><div id="tsBox" style="min-height:70px;margin-top:6px"></div>` : ''}
      <button class="btn" style="margin-top:18px;width:100%" onclick="doAuth('register')">สมัครสมาชิก</button>
      <div style="text-align:center;margin-top:14px;font-size:14px">มีบัญชีอยู่แล้ว? <a href="#" onclick="setAuthMode('login');return false">เข้าสู่ระบบ</a></div>
      ` : `
      ${S.need2fa ? `<label>รหัส 2FA 6 หลัก (จากแอป Authenticator)</label>
      <input id="auTotp" inputmode="numeric" maxlength="6" autocomplete="one-time-code" placeholder="123456">` : ''}
      <button class="btn" style="margin-top:18px;width:100%" onclick="doAuth('login')">เข้าสู่ระบบ</button>
      <div style="text-align:center;margin-top:14px;font-size:14px">
        <a href="#" onclick="openForgot();return false">ลืมรหัสผ่าน?</a> •
        ยังไม่มีบัญชี? <a href="#" onclick="setAuthMode('register');return false">สมัครสมาชิก</a>
      </div>
      `}
    </div>
  `;
}

function readAuthDraft() {
  const v = id => ($(id) ? $(id).value : undefined);
  const d = S.authDraft;
  if (v('auUser') !== undefined) d.u = v('auUser');
  if (v('auPass') !== undefined) d.p = v('auPass');
  if (v('auPass2') !== undefined) d.p2 = v('auPass2');
  if (v('auRef') !== undefined) d.r = v('auRef');
}

function setAuthMode(m) {
  readAuthDraft();
  S.authMode = m;
  S.msg = null;
  S.tsToken = '';
  render();
}

// ---------- Cloudflare Turnstile ----------
function mountTurnstile() {
  const key = S.site.turnstile_site_key;
  const box = $('tsBox');
  if (!key || !box || box.dataset.mounted) return;
  if (!window.turnstile) {
    if (!document.getElementById('cfTsScript')) {
      const sc = document.createElement('script');
      sc.id = 'cfTsScript';
      sc.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      sc.async = true;
      sc.onload = () => mountTurnstile();
      sc.onerror = () => { box.innerHTML = '<div class="msg bad">โหลด Cloudflare ไม่สำเร็จ (ตรวจสอบอินเทอร์เน็ต/ตัวบล็อกโฆษณา แล้วรีเฟรชหน้า)</div>'; };
      document.head.appendChild(sc);
    } else {
      setTimeout(mountTurnstile, 300);
    }
    return;
  }
  box.dataset.mounted = '1';
  S.tsToken = '';
  window.turnstile.render(box, {
    sitekey: key,
    theme: currentTheme() === 'dark' ? 'dark' : 'light',
    language: 'th',
    callback: t => { S.tsToken = t; },
    'expired-callback': () => { S.tsToken = ''; },
    'error-callback': () => { S.tsToken = ''; }
  });
}

async function doAuth(mode) {
  readAuthDraft();
  const d = S.authDraft;
  try {
    if (mode === 'register') {
      if (!/^[A-Za-z0-9_.-]{3,30}$/.test(d.u.trim())) throw new Error('ชื่อผู้ใช้ 3-30 ตัว ใช้ได้เฉพาะ a-z 0-9 _ . -');
      if (d.p.length < 6) throw new Error('รหัสผ่านต้องยาวอย่างน้อย 6 ตัวอักษร');
      if (d.p !== d.p2) throw new Error('ยืนยันรหัสผ่านไม่ตรงกัน');
      if (S.site.turnstile_site_key && !S.tsToken) throw new Error('กรุณายืนยันว่าไม่ใช่บอท (Cloudflare) ก่อนสมัครสมาชิก');
    }
    const res = await api('/' + mode, {
      method: 'POST',
      body: mode === 'register'
        ? { username: d.u, password: d.p, password2: d.p2, referralCode: d.r, cfToken: S.tsToken }
        : { username: d.u, password: d.p, totp: $('auTotp') ? $('auTotp').value : undefined }
    });
    S.need2fa = false;
    S.authDraft = { u: '', p: '', p2: '', r: '' };
    S.tsToken = '';
    S.authMode = 'login';
    await refreshAll();
    S.view = 'shop';
    S.authNote = '';
    const pb = S.pendingBuy;
    S.pendingBuy = null;
    showMsg('ok', mode === 'login' ? 'เข้าสู่ระบบสำเร็จ' : 'สมัครสมาชิกเรียบร้อยแล้ว');
    const resume = () => { if (pb) { openBuy(pb.prodId, pb.planId); C.coupon = pb.coupon || ''; renderCheckout(); } };
    if (mode === 'register' && res && res.recoveryCode) openRecovery(res.recoveryCode, resume);
    else resume();
  } catch (e) {
    if (e.data && e.data.need2fa) S.need2fa = true;
    S.tsToken = '';   // โทเค็น Turnstile ใช้ได้ครั้งเดียว — วิดเจ็ตจะถูกสร้างใหม่ตอน render
    showMsg('bad', e.message);
  }
}

// ---------- ความปลอดภัยบัญชี: รหัสกู้คืน / ลืมรหัสผ่าน / เปลี่ยนรหัสผ่าน ----------
let recoveryResume = null;
function openRecovery(code, resume) {
  recoveryResume = resume || null;
  $('dlgBody').innerHTML = `
    <h3>🔑 รหัสกู้คืนบัญชีของคุณ</h3>
    <p class="hint" style="margin-top:0">ใช้ตั้งรหัสผ่านใหม่เองเมื่อลืมรหัสผ่าน <b>แสดงครั้งนี้ครั้งเดียว</b> กรุณาจดหรือบันทึกไว้ในที่ปลอดภัย</p>
    <div class="acct" style="font-size:20px;letter-spacing:1px;text-align:center;font-weight:800">${esc(code)}</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
      <button class="btn ghost sm" onclick="copyText('${esc(code)}')">📋 คัดลอก</button>
      <button class="btn ghost sm" onclick="downloadConfig('recovery-code.txt', 'รหัสกู้คืนบัญชี: ${esc(code)}')">⬇️ ดาวน์โหลด (.txt)</button>
    </div>
    <div class="hint">ใช้ได้ครั้งเดียว หลังใช้แล้วให้สร้างรหัสใหม่ในหน้า "ประวัติ & ไฟล์" • อย่าส่งรหัสนี้ให้ใคร รวมถึงแอดมิน</div>
    <div style="display:flex;justify-content:flex-end;margin-top:16px">
      <button class="btn" onclick="closeRecovery()">ฉันบันทึกไว้แล้ว</button>
    </div>`;
  $('dlg').showModal();
}
function closeRecovery() {
  $('dlg').close();
  const f = recoveryResume;
  recoveryResume = null;
  if (f) f();
}

function openForgot() {
  const u = $('auUser') ? $('auUser').value : '';
  $('dlgBody').innerHTML = `
    <h3>ลืมรหัสผ่าน</h3>
    <p class="hint" style="margin-top:0">กรอกชื่อผู้ใช้ + รหัสกู้คืน (ได้ตอนสมัครสมาชิก) เพื่อตั้งรหัสผ่านใหม่ ถ้าไม่มีรหัสกู้คืนให้ติดต่อแอดมินเพื่อรีเซ็ต</p>
    <label>ชื่อผู้ใช้</label>
    <input id="fgUser" autocomplete="username" value="${esc(u)}">
    <label>รหัสกู้คืน (XXXX-XXXX-XXXX-XXXX)</label>
    <input id="fgCode" autocomplete="off" placeholder="XXXX-XXXX-XXXX-XXXX" style="text-transform:uppercase">
    <label>รหัสผ่านใหม่ (อย่างน้อย 6 ตัวอักษร)</label>
    <input id="fgPass" type="password" autocomplete="new-password">
    <div id="fgErr" class="msg bad slim" style="display:none"></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">
      <button class="btn ghost" onclick="$('dlg').close()">ปิด</button>
      <button class="btn" id="fgBtn" onclick="submitForgot()">ตั้งรหัสผ่านใหม่</button>
    </div>`;
  $('dlg').showModal();
}
async function submitForgot() {
  const err = $('fgErr');
  err.style.display = 'none';
  const btn = $('fgBtn');
  btn.disabled = true;
  try {
    await api('/forgot', { method: 'POST', body: { username: $('fgUser').value, recoveryCode: $('fgCode').value, newPassword: $('fgPass').value } });
    $('dlg').close();
    S.view = 'auth';
    render();
    showMsg('ok', 'ตั้งรหัสผ่านใหม่เรียบร้อย เข้าสู่ระบบด้วยรหัสใหม่ได้เลย (รหัสกู้คืนเดิมถูกใช้แล้ว อย่าลืมสร้างรหัสใหม่หลังเข้าสู่ระบบ)');
  } catch (e) {
    err.textContent = e.message;
    err.style.display = '';
    btn.disabled = false;
  }
}

function openChangePassword() {
  $('dlgBody').innerHTML = `
    <h3>🔒 เปลี่ยนรหัสผ่าน</h3>
    <label>รหัสผ่านปัจจุบัน</label>
    <input id="cpOld" type="password" autocomplete="current-password">
    <label>รหัสผ่านใหม่ (อย่างน้อย 6 ตัวอักษร)</label>
    <input id="cpNew" type="password" autocomplete="new-password">
    <label>ยืนยันรหัสผ่านใหม่</label>
    <input id="cpNew2" type="password" autocomplete="new-password">
    <div class="hint">เมื่อเปลี่ยนแล้ว อุปกรณ์อื่นที่ล็อกอินอยู่จะถูกออกจากระบบ</div>
    <div id="cpErr" class="msg bad slim" style="display:none"></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">
      <button class="btn ghost" onclick="$('dlg').close()">ปิด</button>
      <button class="btn" id="cpBtn" onclick="submitChangePassword()">บันทึกรหัสผ่านใหม่</button>
    </div>`;
  $('dlg').showModal();
}
async function submitChangePassword() {
  const err = $('cpErr');
  err.style.display = 'none';
  if ($('cpNew').value !== $('cpNew2').value) { err.textContent = 'รหัสผ่านใหม่และช่องยืนยันไม่ตรงกัน'; err.style.display = ''; return; }
  const btn = $('cpBtn');
  btn.disabled = true;
  try {
    await api('/me/password', { method: 'POST', body: { current: $('cpOld').value, next: $('cpNew').value } });
    $('dlg').close();
    showMsg('ok', 'เปลี่ยนรหัสผ่านเรียบร้อยแล้ว');
  } catch (e) {
    err.textContent = e.message;
    err.style.display = '';
    btn.disabled = false;
  }
}

function openRegenRecovery() {
  $('dlgBody').innerHTML = `
    <h3>🔑 สร้างรหัสกู้คืนใหม่</h3>
    <p class="hint" style="margin-top:0">รหัสกู้คืนเดิม (ถ้ามี) จะใช้ไม่ได้ทันที ยืนยันด้วยรหัสผ่านของคุณ</p>
    <label>รหัสผ่านปัจจุบัน</label>
    <input id="rcPass" type="password" autocomplete="current-password">
    <div id="rcErr" class="msg bad slim" style="display:none"></div>
    <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">
      <button class="btn ghost" onclick="$('dlg').close()">ปิด</button>
      <button class="btn" id="rcBtn" onclick="submitRegenRecovery()">สร้างรหัสใหม่</button>
    </div>`;
  $('dlg').showModal();
}
async function submitRegenRecovery() {
  const err = $('rcErr');
  err.style.display = 'none';
  const btn = $('rcBtn');
  btn.disabled = true;
  try {
    const r = await api('/me/recovery', { method: 'POST', body: { password: $('rcPass').value } });
    if (S.user) S.user.has_recovery = true;
    $('dlg').close();
    openRecovery(r.recoveryCode);
  } catch (e) {
    err.textContent = e.message;
    err.style.display = '';
    btn.disabled = false;
  }
}

async function logout() {
  await api('/logout', { method: 'POST' });
  await refreshAll();
  go('shop');
}

// =====================================================
// ADMIN DASHBOARD (ORGANIZED SIDEBAR + FULL CONTROLS)
// =====================================================

// ---------- ไอคอนแบบเวกเตอร์ (สไตล์ Lucide) สำหรับหลังบ้าน ----------
const ADM_IC = {
  dash:'<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
  users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  server:'<rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><path d="M6 6h.01M6 18h.01"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  package:'<path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5M12 22V12"/>',
  ticket:'<path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/><path d="M13 5v2M13 17v2M13 11v2"/>',
  wallet:'<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
  receipt:'<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8M12 17.5v-11"/>',
  message:'<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  plug:'<path d="M12 22v-5M9 8V2M15 8V2M18 8v5a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V8Z"/>',
  palette:'<circle cx="13.5" cy="6.5" r=".5"/><circle cx="17.5" cy="10.5" r=".5"/><circle cx="8.5" cy="7.5" r=".5"/><circle cx="6.5" cy="12.5" r=".5"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.93 0 1.5-.75 1.5-1.5 0-.4-.15-.74-.39-1.04-.23-.29-.38-.63-.38-1.04 0-.83.67-1.5 1.5-1.5H16c3.31 0 6-2.69 6-6 0-4.96-4.5-9-10-9Z"/>',
  settings:'<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  card:'<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>',
  shield:'<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>',
  trend:'<path d="m22 7-8.5 8.5-5-5L2 17"/><path d="M16 7h6v6"/>',
  trophy:'<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6M18 9h1.5a2.5 2.5 0 0 0 0-5H18M4 22h16M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22M18 2H6v7a6 6 0 0 0 12 0Z"/>',
  key:'<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/>',
  save:'<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
  refresh:'<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
  zap:'<path d="M13 2 3 14h9l-1 8 10-12h-9z"/>',
  edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  lock:'<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  check:'<path d="M20 6 9 17l-5-5"/>',
  alert:'<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4M12 17h.01"/>',
  clipboard:'<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>',
  bank:'<path d="M3 21h18M3 10h18M5 6l7-3 7 3M4 10v11M20 10v11M8 14v3M12 14v3M16 14v3"/>',
  search:'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  globe:'<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  store:'<path d="m2 7 1.5-4h17L22 7"/><path d="M2 7a3 3 0 0 0 5.5 1.6A3 3 0 0 0 12 9.3a3 3 0 0 0 4.5-.7A3 3 0 0 0 22 7"/><path d="M4 11v10h16V11"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  x:'<path d="M18 6 6 18M6 6l12 12"/>'
};
function admIcon(n) {
  return `<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ADM_IC[n] || ''}</svg>`;
}
// อีโมจิ → ไอคอน (แทนเฉพาะ "ข้อความ" ระหว่างแท็ก ไม่แตะ attribute/onclick)
const ADM_EMOJI = {
  '📊':'dash','👥':'users','🖥':'server','➕':'plus','📦':'package','🎟':'ticket','💰':'wallet','🧾':'receipt',
  '💬':'message','🔌':'plug','⚙':'settings','🛠':'settings','💳':'card','🛡':'shield','📈':'trend','🏆':'trophy',
  '🔑':'key','💾':'save','🔄':'refresh','🔁':'refresh','⚡':'zap','✏':'edit','✎':'edit','📝':'edit','🔒':'lock','🔐':'lock',
  '✅':'check','⚠':'alert','📋':'clipboard','🗂':'clipboard','🏦':'bank','💸':'wallet','🔍':'search','🔎':'search','🌐':'globe','❌':'x'
};
const ADM_EMOJI_RE = new RegExp('(' + Object.keys(ADM_EMOJI).join('|') + ')\\uFE0F?', 'g');
function admIconize(html) {
  return html.replace(/>([^<>]*)</g, (m, t) => {
    const r = t.replace(ADM_EMOJI_RE, (_, e) => admIcon(ADM_EMOJI[e]));
    return r === t ? m : '>' + r + '<';
  });
}

function viewAdmin() {
  if (!S.user || S.user.role !== 'admin') {
    return `<div class="section-card empty">เฉพาะผู้ดูแลระบบ (Admin) เท่านั้น</div>`;
  }

  const pendingTopups = S.adminTopups.length;
  const openTickets = S.adminTickets.filter(t => t.status === 'open').length;

  const TABS = {
    dash:    ['dash',    'แดชบอร์ดสรุป',            'ภาพรวมยอดขาย สมาชิก และสถานะระบบแบบเรียลไทม์'],
    users:   ['users',   'จัดการผู้ใช้งาน',          'ค้นหา ปรับเครดิต กำหนดสิทธิ์ และระงับบัญชีสมาชิก'],
    servers: ['server',  'เซิร์ฟเวอร์ 3x-ui / SSH',  'เชื่อมต่อและทดสอบเซิร์ฟเวอร์ที่ใช้สร้างบัญชีลูกค้า'],
    add:     ['plus',    'เพิ่มแพ็กเกจใหม่',         'สร้างสินค้าและตั้งราคา พร้อมผูกกับเซิร์ฟเวอร์'],
    edit:    ['package', 'จัดการแพ็กเกจ',            'แก้ไข เปิด/ปิดขาย และจัดลำดับแพ็กเกจทั้งหมด'],
    coupons: ['ticket',  'คูปองส่วนลด',              'สร้างโค้ดส่วนลดและติดตามการใช้งาน'],
    topups:  ['wallet',  'ตรวจสลิปเติมเงิน',         'อนุมัติหรือปฏิเสธรายการเติมเครดิตที่รอตรวจสอบ'],
    orders:  ['receipt', 'ออเดอร์ / คืนเงิน',        'ดูประวัติคำสั่งซื้อและดำเนินการคืนเงิน'],
    tickets: ['message', 'แจ้งปัญหาลูกค้า',          'ตอบและปิดงานทิกเก็ตจากลูกค้า'],
    slip:    ['plug',    'API ตรวจสลิป',             'ตั้งค่าผู้ให้บริการตรวจสลิปและบัญชีผู้รับเงิน'],
    site:    ['settings','ตั้งค่าเว็บ & รูปภาพ',      'ปรับชื่อร้าน โลโก้ แบนเนอร์ และข้อความหน้าเว็บ'],
    look:    ['palette', 'รูปแบบเว็บไซต์',            'เลือกสีธีม ฟอนต์ ปุ่ม ฮีโร่ พื้นหลัง แถบประกาศ และเอฟเฟกต์ของหน้าร้าน']
  };
  const cur = TABS[S.atab] || TABS.dash;
  const uname = esc(S.user.username || 'admin');

  const GROUPS = [
    ['ภาพรวม', ['dash']],
    ['ผู้ใช้งาน & เซิร์ฟเวอร์', ['users', 'servers']],
    ['สินค้า & โปรโมชั่น', ['add', 'edit', 'coupons']],
    ['การเงิน & บริการ', ['topups', 'orders', 'tickets']],
    ['ตั้งค่าระบบ', ['slip', 'site', 'look']]
  ];
  const BADGE = { topups: pendingTopups, tickets: openTickets };

  // ===== หน้าเมนูหลังบ้าน (หน้าแรกที่เจอเมื่อกดเข้า) =====
  if (S.atab === 'menu') {
    const kpiTop = (icon, tone, label, val) =>
      `<div class="kpi ${tone}"><div class="kic">${admIcon(icon)}</div><span>${label}</span><b>${val}</b></div>`;
    return admIconize(`
      <div class="adm-hub" data-style="${admMenuStyle()}">
        <div class="adm-hub-head">
          <div class="adm-avatar">${uname.charAt(0)}</div>
          <div class="adm-hub-who"><b>หลังบ้าน · ${uname}</b><small><i></i>ผู้ดูแลระบบ เลือกเมนูที่ต้องการจัดการ</small></div>
          <button class="btn ghost sm" onclick="go('shop')">${admIcon('store')}หน้าร้านค้า</button>
        </div>
        ${msgHtml()}
        <div class="kpi-grid">
          ${kpiTop('users', '', 'สมาชิกทั้งหมด', S.members.toLocaleString() + ' คน')}
          ${kpiTop('server', 't-cyan', 'เซิร์ฟเวอร์เชื่อมต่อ', S.activeServers + ' เครื่อง')}
          ${kpiTop('package', 't-violet', 'แพ็กเกจเปิดขาย', S.products.length + ' รายการ')}
          ${kpiTop('wallet', pendingTopups ? 't-bad' : 't-ok', 'สลิปรอตรวจสอบ', pendingTopups + ' รายการ')}
        </div>
        ${GROUPS.map(([g, ids]) => `
          <div class="adm-hub-g">${g}</div>
          <div class="adm-hub-grid">
            ${ids.map(id => `
              <button class="adm-tile" onclick="setAdminTab('${id}')">
                <span class="ti">${admIcon(TABS[id][0])}</span>
                <span class="tx"><b>${TABS[id][1]}</b><small>${TABS[id][2]}</small></span>
                ${BADGE[id] > 0 ? `<span class="tc">${BADGE[id]}</span>` : ''}
                <svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>
              </button>`).join('')}
          </div>`).join('')}

        <div class="adm-style-box">
          <div class="adm-style-t"><b>รูปแบบปุ่มเมนูหลังบ้าน</b><small>เลือกหน้าตาปุ่มที่ชอบ จะจำไว้ในเครื่องนี้</small></div>
          <div class="adm-style-row" role="group" aria-label="รูปแบบปุ่มเมนู">
            ${MENU_STYLES.map(([id, nm, ds]) => `
              <button class="adm-style-opt" data-v="${id}" aria-pressed="${admMenuStyle() === id}" onclick="setAdmMenuStyle('${id}')">
                <span class="pv pv-${id}"><i></i><i></i><i></i><i></i></span>
                <b>${nm}</b><small>${ds}</small>
              </button>`).join('')}
          </div>
        </div>
      </div>`);
  }

  let content = '';
  if (S.atab === 'dash') content = adminDashTab();
  else if (S.atab === 'users') content = adminUsersTab();
  else if (S.atab === 'servers') content = adminServersTab();
  else if (S.atab === 'add' || S.atab === 'edit') content = adminProductsTab();
  else if (S.atab === 'topups') content = adminTopupsTab();
  else if (S.atab === 'coupons') content = adminCouponsTab();
  else if (S.atab === 'orders') content = adminOrdersTab();
  else if (S.atab === 'tickets') content = adminTicketsTab();
  else if (S.atab === 'slip') content = adminSlipApiTab();
  else if (S.atab === 'site') content = adminSiteTab();
  else if (S.atab === 'look') content = adminLookTab();

  // ===== หน้าย่อย: มีปุ่มย้อนกลับเมนูเสมอ =====
  return admIconize(`
    <div class="adm-sub">
      <div class="adm-backbar">
        <button class="adm-backbtn" onclick="setAdminTab('menu')" aria-label="ย้อนกลับไปเมนูหลังบ้าน">
          <svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>ย้อนกลับ
        </button>
        <span class="adm-crumb">เมนูหลังบ้าน <i>›</i> <b>${cur[1]}</b></span>
      </div>
      <div class="admin-main">
        <div class="adm-head">
          <div>
            <h2><span class="hi">${admIcon(cur[0])}</span>${cur[1]}</h2>
            <p>${cur[2]}</p>
          </div>
          <div class="adm-actions">
            ${S.atab === 'edit' ? `<button class="btn sm" onclick="setAdminTab('add')">${admIcon('plus')}เพิ่มแพ็กเกจ</button>` : ''}
            <button class="btn ghost sm" onclick="setAdminTab('${S.atab}')">${admIcon('refresh')}รีเฟรชข้อมูล</button>
          </div>
        </div>
        ${msgHtml()}
        ${content}
        <div class="adm-foot"><button class="btn ghost" onclick="setAdminTab('menu')">
          <svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>กลับเมนูหลังบ้าน</button></div>
      </div>
    </div>`);
}

// --- 1. Admin: จัดการผู้ใช้งาน ---
function adminUsersTab() {
  const detail = S.selectedUserDetail;
  return `
    <div class="section-card">
      <h3>
        <span>👥 จัดการผู้ใช้งานที่สมัครสมาชิก (${S.adminUsers.length})</span>
        <div style="display:flex;gap:8px;max-width:300px;width:100%">
          <input id="uSearchInput" value="${esc(S.userSearch)}" placeholder="ค้นหาชื่อผู้ใช้ / รหัสแนะนำ..." onkeydown="if(event.key==='Enter')searchUsers()">
          <button class="btn sm" onclick="searchUsers()">ค้นหา</button>
        </div>
      </h3>

      ${detail ? `
        <div style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:14px;padding:18px;margin-bottom:18px">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
            <div>
              <b style="font-size:17px">@${esc(detail.user.username)}</b>
              <span class="tag ${detail.user.role === 'admin' ? 'srv' : ''}">${detail.user.role}</span>
              ${detail.user.is_banned ? `<span class="tag bad">ถูกระงับบัญชี</span>` : `<span class="tag ok">ปกติ</span>`}
              <div class="hint">สมัครเมื่อ ${fdt(detail.user.created_at)} • รหัสแนะนำ: ${esc(detail.user.referral_code || '-')} • เครดิตคงเหลือ: <b>${money(detail.user.credit_balance)} ฿</b></div>
            </div>
            <button class="btn ghost sm" onclick="S.selectedUserDetail=null;render()">ปิดรายละเอียด</button>
          </div>

          <div class="row2">
            <div style="background:#fff;padding:14px;border-radius:12px;border:1px solid var(--line)">
              <b style="font-size:14px">💳 ปรับยอดเครดิต (เพิ่ม / หัก)</b>
              <label>จำนวนเงิน (+ เพิ่มเครดิต, - หักเครดิต)</label>
              <input id="adjAmt" type="number" step="0.01" placeholder="เช่น 50 หรือ -20">
              <label>หมายเหตุ (บันทึกลงบัญชีแยกประเภท)</label>
              <input id="adjNote" placeholder="เช่น เติมเครดิตชดเชย / ปรับยอด">
              <button class="btn sm" style="margin-top:10px" onclick="adjustUserCredit(${detail.user.id})">บันทึกปรับยอดเครดิต</button>
            </div>

            <div style="background:#fff;padding:14px;border-radius:12px;border:1px solid var(--line)">
              <b style="font-size:14px">🛡️ สิทธิ์การใช้งาน & รหัสผ่าน</b>
              <div class="row2">
                <div>
                  <label>บทบาท</label>
                  <select id="editURole">
                    <option value="user" ${detail.user.role === 'user' ? 'selected' : ''}>สมาชิกทั่วไป (user)</option>
                    <option value="admin" ${detail.user.role === 'admin' ? 'selected' : ''}>แอดมิน (admin)</option>
                  </select>
                </div>
                <div>
                  <label>สถานะบัญชี</label>
                  <select id="editUBan">
                    <option value="false" ${!detail.user.is_banned ? 'selected' : ''}>เปิดใช้งานปกติ</option>
                    <option value="true" ${detail.user.is_banned ? 'selected' : ''}>ระงับการใช้งาน (แบน)</option>
                  </select>
                </div>
              </div>
              <label>ตั้งรหัสผ่านใหม่ (เว้นว่างถ้าไม่เปลี่ยน)</label>
              <input id="editUPass" type="password" placeholder="อย่างน้อย 6 ตัวอักษร">
              <label>บันทึกโน้ตแอดมิน</label>
              <input id="editUNote" value="${esc(detail.user.note || '')}" placeholder="บันทึกเพิ่มเติมเกี่ยวกับลูกค้ารายนี้">
              <button class="btn sm ok" style="margin-top:10px" onclick="saveUserEdit(${detail.user.id})">บันทึกข้อมูลผู้ใช้</button>
            </div>
          </div>

          <div class="row2" style="margin-top:14px">
            <div>
              <b style="font-size:13.5px">ประวัติออเดอร์ล่าสุด (${detail.orders.length})</b>
              <div class="table-wrap" style="margin-top:6px">
                <table>
                  <thead><tr><th>#</th><th>แพ็กเกจ</th><th>จ่าย</th><th>สถานะ</th></tr></thead>
                  <tbody>
                    ${detail.orders.length ? detail.orders.map(o => `
                      <tr>
                        <td>#${o.id}</td>
                        <td>${esc(o.title)} - ${esc(o.plan_name)}</td>
                        <td>${money(o.price_paid)} ฿</td>
                        <td><span class="tag ${o.status === 'active' ? 'ok' : 'bad'}">${o.status}</span></td>
                      </tr>
                    `).join('') : `<tr><td colspan="4" class="empty">ไม่มีออเดอร์</td></tr>`}
                  </tbody>
                </table>
              </div>
            </div>
            <div>
              <b style="font-size:13.5px">ความเคลื่อนไหวเครดิต (${detail.ledger.length})</b>
              <div class="table-wrap" style="margin-top:6px">
                <table>
                  <thead><tr><th>รายการ</th><th>จำนวน</th><th>คงเหลือ</th></tr></thead>
                  <tbody>
                    ${detail.ledger.length ? detail.ledger.map(l => `
                      <tr>
                        <td>${esc(l.note || l.type)}<br><small style="color:var(--sub)">${fdt(l.created_at)}</small></td>
                        <td style="color:${l.amount >= 0 ? 'var(--ok)' : 'var(--bad)'};font-weight:700">${l.amount >= 0 ? '+' : ''}${money(l.amount)}</td>
                        <td>${money(l.balance_after)} ฿</td>
                      </tr>
                    `).join('') : `<tr><td colspan="3" class="empty">ไม่มีประวัติเครดิต</td></tr>`}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      ` : ''}

      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>ชื่อผู้ใช้</th>
              <th>สิทธิ์ / สถานะ</th>
              <th>เครดิตคงเหลือ</th>
              <th>เติมสะสม / ซื้อสะสม</th>
              <th>ออเดอร์</th>
              <th>วันที่สมัคร</th>
              <th>จัดการ</th>
            </tr>
          </thead>
          <tbody>
            ${S.adminUsers.length ? S.adminUsers.map(u => `
              <tr>
                <td>#${u.id}</td>
                <td><b>${esc(u.username)}</b>${u.note ? `<br><small style="color:var(--sub)">📝 ${esc(u.note)}</small>` : ''}</td>
                <td>
                  <span class="tag ${u.role === 'admin' ? 'srv' : ''}">${u.role}</span>
                  ${u.is_banned ? `<span class="tag bad">แบน</span>` : `<span class="tag ok">ปกติ</span>`}
                </td>
                <td><b style="color:var(--brand)">${money(u.credit_balance)} ฿</b></td>
                <td>${money(u.total_topup)} / ${money(u.total_spent)} ฿</td>
                <td>${u.order_count}</td>
                <td>${fdate(u.created_at)}</td>
                <td><button class="btn sm ghost" onclick="inspectUser(${u.id})">ดูข้อมูล / แก้ไข</button></td>
              </tr>
            `).join('') : `<tr><td colspan="8" class="empty">ไม่พบข้อมูลผู้ใช้งาน</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

async function searchUsers() {
  S.userSearch = $('uSearchInput').value;
  S.adminUsers = await api('/admin/users?q=' + encodeURIComponent(S.userSearch));
  render();
}

async function inspectUser(uid) {
  try {
    S.selectedUserDetail = await api('/admin/users/' + uid);
    render();
  } catch (e) {
    showMsg('bad', e.message);
  }
}

async function adjustUserCredit(uid) {
  try {
    const amount = parseFloat($('adjAmt').value);
    const note = $('adjNote').value;
    await api(`/admin/users/${uid}/adjust-credit`, { method: 'POST', body: { amount, note } });
    await inspectUser(uid);
    S.adminUsers = await api('/admin/users?q=' + encodeURIComponent(S.userSearch || ''));
    await refreshAll();
    showMsg('ok', 'ปรับยอดเครดิตเรียบร้อยแล้ว');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

async function saveUserEdit(uid) {
  try {
    await api(`/admin/users/${uid}`, {
      method: 'PUT',
      body: {
        role: $('editURole').value,
        is_banned: $('editUBan').value === 'true',
        new_password: $('editUPass').value,
        note: $('editUNote').value
      }
    });
    await inspectUser(uid);
    S.adminUsers = await api('/admin/users?q=' + encodeURIComponent(S.userSearch || ''));
    showMsg('ok', 'บันทึกข้อมูลผู้ใช้งานเรียบร้อยแล้ว');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

// --- 2. Admin: จัดการเซิร์ฟเวอร์ 3x-ui / SSH ---
function adminServersTab() {
  const ed = S.editingServerId ? S.adminServers.find(x => x.id === S.editingServerId) : null;
  const srvType = ed ? ed.type : '3xui';
  const xl = S.xxtLink;
  const xx = xl && xl.xui;
  const xxtLinkCard = xl && (xl.available || xl.panel_web || (xx && (xx.available || xx.panel_web))) ? `
    <div class="section-card">
      <h3>🔗 เชื่อมร้านค้ากับแดชบอร์ดบนเครื่องนี้</h3>
      <div class="hint" style="margin-bottom:10px">
        กดปุ่มเดียวเพื่อเพิ่มเซิร์ฟเวอร์ที่ติดตั้งไว้บนเครื่องนี้เข้าร้านค้า — ไม่ต้องสร้างคีย์/กรอกรหัสเอง (กดซ้ำ = ทดสอบเชื่อมต่อใหม่)
        ${xl.linked ? `<br>✅ XXTLONLINE เชื่อมแล้ว (${esc(xl.linked.last_status || '-')})` : ''}
        ${xx && xx.linked ? `<br>✅ 3x-ui เชื่อมแล้ว (${esc(xx.linked.last_status || '-')}) — แพ็กเกจ VLESS/VMess เลือก Inbound ตอนเพิ่มแพ็กเกจ` : ''}
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${xl.available ? `<button class="btn ok" onclick="linkXxt()">🔗 ${xl.linked ? 'ทดสอบ XXTLONLINE' : 'เชื่อมแดชบอร์ด XXTLONLINE'}</button>` : ''}
        ${xl.panel_web ? `<a class="btn ghost" href="${xl.panel_web}" target="_blank" rel="noopener">↗ เปิดแดชบอร์ด XXTLONLINE</a>` : ''}
        ${xx && xx.available ? `<button class="btn ok" onclick="linkXui()">🔗 ${xx.linked ? 'ทดสอบ 3x-ui' : 'เชื่อม 3x-ui'}</button>` : ''}
        ${xx && xx.panel_web ? `<a class="btn ghost" href="${xx.panel_web}" target="_blank" rel="noopener">↗ เปิดแผง 3x-ui</a>` : ''}
      </div>
    </div>` : '';

  return `
    ${xxtLinkCard}
    <div class="section-card">
      <h3>
        <span>${ed ? `✏️ แก้ไขเซิร์ฟเวอร์: ${esc(ed.name)}` : '➕ เพิ่มเซิร์ฟเวอร์ VPS (3x-ui / SSH)'}</span>
        ${ed ? `<button class="btn ghost sm" onclick="S.editingServerId=null;render()">ยกเลิกแก้ไข</button>` : ''}
      </h3>
      <div class="hint" style="margin-bottom:10px">
        รองรับการเชื่อมต่อ <b>3x-ui / X-UI Panel API</b> (สร้าง Client และต่ออายุอัตโนมัติพร้อมส่งลิงก์ VLESS/VMess/Trojan) และเซิร์ฟเวอร์ <b>SSH / UDP</b>
      </div>

      <div class="row3">
        <div>
          <label>ชื่อเรียกเซิร์ฟเวอร์</label>
          <input id="svName" value="${esc(ed?.name || '')}" placeholder="เช่น SG-01 (3x-ui VLESS)">
        </div>
        <div>
          <label>ประเภทเซิร์ฟเวอร์</label>
          <select id="svType" onchange="toggleSrvFields()">
            <option value="3xui" ${srvType === '3xui' ? 'selected' : ''}>3x-ui / X-UI Panel API</option>
            <option value="ssh" ${srvType === 'ssh' ? 'selected' : ''}>SSH / UDP Server</option>
            <option value="xxt" ${srvType === 'xxt' ? 'selected' : ''}>แดชบอร์ด XXTLONLINE (SSH/NPV/NetMod)</option>
          </select>
        </div>
        <div>
          <label>Host / IP / Domain เชื่อมต่อ</label>
          <input id="svHost" value="${esc(ed?.host || '')}" placeholder="เช่น sg1.yourdomain.com">
        </div>
      </div>

      <div id="box3xui" style="display:${srvType === '3xui' ? 'block' : 'none'}">
        <div class="row3">
          <div>
            <label>3x-ui Panel URL (รวมพอร์ตและ Base Path)</label>
            <input id="svPanelUrl" value="${esc(ed?.panel_url || '')}" placeholder="https://sg1.domain.com:2053/secret">
          </div>
          <div>
            <label>Panel Username</label>
            <input id="svPanelUser" value="${esc(ed?.panel_user || '')}" placeholder="admin">
          </div>
          <div>
            <label>Panel Password ${ed ? '(เว้นว่างถ้าไม่เปลี่ยน)' : ''}</label>
            <input id="svPanelPass" type="password" placeholder="••••••••">
          </div>
        </div>

        <div class="hint" style="margin:8px 0">
          ✅ กรอกแค่นี้พอ — โปรโตคอล / พอร์ต / path / TLS / Reality ระบบอ่านจาก Inbound จริงอัตโนมัติ
          และเลือก Inbound ตอน <b>เพิ่มแพ็กเกจ</b> (ระบบดึงรายการที่สร้างไว้ใน 3x-ui มาให้เลือก)
        </div>
        <details ${(ed?.public_port || ed?.sni) ? 'open' : ''}>
          <summary style="cursor:pointer;font-size:13px;color:var(--sub)">ตั้งค่าขั้นสูง (ไม่จำเป็น)</summary>
          <div class="row2">
            <div>
              <label>บังคับพอร์ตภายนอก (เว้นว่าง = ใช้พอร์ตของ Inbound)</label>
              <input id="svPubPort" type="number" value="${ed?.public_port || ''}" placeholder="ใช้เมื่อมี proxy/CDN หน้า inbound">
            </div>
            <div>
              <label>บังคับ SNI / Host (เว้นว่าง = ใช้ค่าของ Inbound)</label>
              <input id="svSni" value="${esc(ed?.sni || '')}" placeholder="เช่น bug.ais.co.th">
            </div>
          </div>
        </details>
      </div>

      <div id="boxXxt" style="display:${srvType === 'xxt' ? 'block' : 'none'}">
        <div class="row2">
          <div>
            <label>Dashboard URL (เช่น https://hightx.pxtstrux.online)</label>
            <input id="svXxtUrl" value="${esc(ed?.type === 'xxt' ? (ed?.panel_url || '') : '')}" placeholder="https://โดเมนแดชบอร์ดของคุณ">
          </div>
          <div>
            <label>API Key ของแดชบอร์ด ${ed?.type === 'xxt' ? '(เว้นว่างถ้าไม่เปลี่ยน)' : ''}</label>
            <input id="svXxtPass" type="password" placeholder="xxtl_••••••••" autocomplete="new-password">
          </div>
        </div>
        <div class="row2" style="margin-top:8px">
          <div>
            <label>Profile ID รูปแบบ Config (ไม่จำเป็น — ว่าง = ค่าหลักของแดชบอร์ด)</label>
            <input id="svXxtProfile" value="${esc(ed?.type === 'xxt' && ed?.npv_type && ed.npv_type !== 'SSH-Direct' ? ed.npv_type : '')}" placeholder="เช่น 3683eb7b" autocapitalize="none">
          </div>
        </div>
        <div class="hint" style="margin:8px 0">
          ✅ ร้านจะสร้าง / ต่ออายุ / ระงับ / ลบ บัญชีผ่าน <b>REST API ของแดชบอร์ด</b> ด้วย API Key (สร้างที่แดชบอร์ด → เมนู API) — ลูกค้าจะโผล่ในแดชบอร์ดด้วย
          และส่งข้อมูลบัญชีตามรูปแบบ Config (บัคโฮส/payload/SNI) ที่ตั้งไว้ในแดชบอร์ด · กดปุ่มทดสอบเชื่อมต่อเพื่อดูรายการ Profile ID ·
          แดชบอร์ดต้องเปิดผ่าน HTTPS โดเมน และถ้าจำกัด IP ของคีย์ ให้ใส่ IP ของเซิร์ฟเวอร์ร้านนี้ · เว้นช่อง Host ด้านบนได้ ระบบใช้โดเมนจาก URL ให้
        </div>
        <label>รูปแบบข้อความส่งมอบ (ไม่จำเป็น — เว้นว่าง = ใช้รูปแบบของแดชบอร์ด; ตัวแปร {host} {port} {user} {pass} {exp})</label>
        <textarea id="svXxtTpl" rows="3">${esc(ed?.type === 'xxt' ? (ed?.template || '') : '')}</textarea>
      </div>

      <div id="boxSsh" style="display:${srvType === 'ssh' ? 'block' : 'none'}">
        <div class="row3">
          <div>
            <label>SSH Port</label>
            <input id="svSshPort" type="number" value="${ed?.ssh_port || 22}">
          </div>
          <div>
            <label>UDP Port</label>
            <input id="svUdpPort" value="${esc(ed?.udp_port || '1-65535')}">
          </div>
          <div>
            <label>SNI / Payload Host</label>
            <input id="svSshSni" value="${esc(ed?.sni || '')}" placeholder="เช่น bug.true.th">
          </div>
        </div>
        <div class="row2">
          <div>
            <label>SSH Login User (root หรือ sudo) — ใช้สร้างบัญชีลูกค้าจริงบนเซิร์ฟเวอร์</label>
            <input id="svSshUser" value="${esc(ed?.ssh_user || 'root')}" placeholder="root">
          </div>
          <div>
            <label>SSH Login Password ${ed?.has_ssh_pass ? '(เว้นว่างถ้าไม่เปลี่ยน)' : ''}</label>
            <input id="svSshPass" type="password" placeholder="••••••••" autocomplete="new-password">
          </div>
        </div>
        <div class="section-card" style="margin:14px 0;background:var(--card-2)">
          <h3 style="font-size:15px">📲 ค่าส่งออก NPV Tunnel / NetMod / Dark Tunnel</h3>
          <div class="row2">
            <div>
              <label>โหมดเชื่อมต่อ NPV (sshConfigType)</label>
              <input id="svNpvType" list="npvTypes" value="${esc(ed?.npv_type || 'SSH-Direct')}">
              <datalist id="npvTypes"><option value="SSH-Direct"><option value="SSH-Proxy-Payload"></datalist>
              <div class="hint">ตรงๆ = SSH-Direct • ใช้ payload/proxy = SSH-Proxy-Payload (โหมดอื่นพิมพ์ชื่อตามที่แอป NPV ใช้)</div>
            </div>
            <div>
              <label>UDPGW Port</label>
              <input id="svUdpgw" type="number" value="${ed?.udpgw_port || 7300}">
            </div>
          </div>
          <div class="row2">
            <div>
              <label>HTTP Proxy Host (ถ้ามี)</label>
              <input id="svProxyHost" value="${esc(ed?.proxy_host || '')}" placeholder="เช่น 203.0.113.10">
            </div>
            <div>
              <label>Proxy Port</label>
              <input id="svProxyPort" type="number" value="${ed?.proxy_port || ''}" placeholder="เช่น 8080">
            </div>
          </div>
          <label>Payload (ใช้ [crlf] ขึ้นบรรทัดใหม่ • ตัวแปร {host} {port} {user} {pass} {sni})</label>
          <textarea id="svPayload" rows="3" placeholder="GET / HTTP/1.1[crlf]Host: {sni}[crlf]Upgrade: websocket[crlf][crlf]">${esc(ed?.payload || '')}</textarea>
          <div class="hint">ระบบเข้ารหัสค่าเหล่านี้ตามรูปแบบของ NPV Tunnel ใส่ลงลิงก์ให้อัตโนมัติ ส่วน NetMod ลิงก์ ssh:// พก payload ไม่ได้ จะแสดงเป็นค่าให้ตั้งเพิ่มในแอป</div>
        </div>
        <label>รูปแบบข้อความส่งมอบบัญชี (ใช้ตัวแปร {host} {user} {pass} {ssh_port} {udp_port} {sni})</label>
        <textarea id="svTemplate" rows="3" placeholder="Host: {host}&#10;Port: {ssh_port}&#10;User: {user}&#10;Pass: {pass}">${esc(ed?.template || '')}</textarea>
      </div>

      <div style="display:flex;gap:10px;align-items:center;margin-top:16px">
        <button class="btn" onclick="saveServer(${ed ? ed.id : 'null'})">${ed ? '💾 บันทึกการแก้ไขเซิร์ฟเวอร์' : '➕ บันทึกเพิ่มเซิร์ฟเวอร์'}</button>
        <label style="margin:0;display:inline-flex;align-items:center;gap:6px;cursor:pointer">
          <input type="checkbox" id="svActive" style="width:auto" ${ed?.is_active !== false ? 'checked' : ''}> เปิดใช้งานเซิร์ฟเวอร์นี้
        </label>
      </div>
    </div>

    ${S.serverTestResult ? `
      <div class="section-card" style="border-color:var(--ok)">
        <h3>✅ ผลการทดสอบเชื่อมต่อ: ${esc(S.serverTestResult.name)}</h3>
        ${S.serverTestResult.inbounds ? `
          <div style="font-size:13.5px;margin-bottom:8px">
            ล็อกอิน 3x-ui สำเร็จ! พบทั้งหมด <b>${S.serverTestResult.inboundCount}</b> Inbounds:
            ${S.serverTestResult.matchedInbound
              ? `<span class="tag ok">ตรงกับ Inbound ID #${S.serverTestResult.matchedInbound.id} (${esc(S.serverTestResult.matchedInbound.remark)} - ${esc(S.serverTestResult.matchedInbound.network)}/${esc(S.serverTestResult.matchedInbound.security)} - พอร์ต ${S.serverTestResult.matchedInbound.port}) — ลิงก์จะสร้างตามค่านี้</span>`
              : `<span class="tag bad">⚠️ ไม่พบ Inbound ID ที่ระบุ กรุณาตรวจสอบเลข ID ด้านล่าง</span>`
            }
          </div>
          <div class="table-wrap">
            <table>
              <thead><tr><th>Inbound ID</th><th>ชื่อ (Remark)</th><th>โปรโตคอล</th><th>Network / Security</th><th>พอร์ต</th><th>สถานะ</th></tr></thead>
              <tbody>
                ${S.serverTestResult.inbounds.map(ib => `
                  <tr>
                    <td><b>#${ib.id}</b></td>
                    <td>${esc(ib.remark)}</td>
                    <td>${esc(ib.protocol)}</td>
                    <td>${esc(ib.network || '-')} / ${esc(ib.security || '-')}</td>
                    <td>${ib.port}</td>
                    <td><span class="tag ${ib.enable ? 'ok' : 'bad'}">${ib.enable ? 'เปิด' : 'ปิด'}</span></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        ` : `<div class="acct">${esc(S.serverTestResult.sample || '')}</div>`}
      </div>
    ` : ''}

    <div class="section-card">
      <h3>🖥️ รายการเซิร์ฟเวอร์ทั้งหมด (${S.adminServers.length})</h3>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>ชื่อเซิร์ฟเวอร์</th>
              <th>ประเภท</th>
              <th>Host / Inbound</th>
              <th>สถานะเชื่อมต่อ</th>
              <th>จัดการ</th>
            </tr>
          </thead>
          <tbody>
            ${S.adminServers.length ? S.adminServers.map(sv => `
              <tr>
                <td><b>${esc(sv.name)}</b><br><small style="color:var(--sub)">${esc(sv.panel_url || sv.host)}</small></td>
                <td><span class="tag srv">${sv.type.toUpperCase()}</span></td>
                <td>${esc(sv.host)}<br><small style="color:var(--sub)">${sv.type === '3xui' ? `Inbound #${sv.inbound_id} (${sv.protocol})` : sv.type === 'xxt' ? 'แดชบอร์ด XXTLONLINE' : `SSH:${sv.ssh_port} / UDP:${sv.udp_port}`}</small></td>
                <td>
                  <span class="tag ${sv.last_status === 'online' ? 'ok' : sv.last_status === 'error' ? 'bad' : ''}">${sv.last_status}</span>
                  ${!sv.is_active ? `<span class="tag bad">ปิดใช้งาน</span>` : ''}
                </td>
                <td style="white-space:nowrap">
                  <button class="btn sm ok" onclick="testServer(${sv.id}, ${JSON.stringify(sv.name)})">🔌 ทดสอบเชื่อมต่อ</button>
                  <button class="btn sm ghost" onclick="S.editingServerId=${sv.id};render()">แก้ไข</button>
                  <button class="btn sm danger" onclick="deleteServer(${sv.id})">ลบ</button>
                </td>
              </tr>
            `).join('') : `<tr><td colspan="5" class="empty">ยังไม่มีเซิร์ฟเวอร์ VPS กรุณาเพิ่มด้านบน</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function toggleSrvFields() {
  const t = $('svType').value;
  $('box3xui').style.display = t === '3xui' ? 'block' : 'none';
  $('boxSsh').style.display = t === 'ssh' ? 'block' : 'none';
  $('boxXxt').style.display = t === 'xxt' ? 'block' : 'none';
}

async function saveServer(id) {
  const type = $('svType').value;
  const body = {
    name: $('svName').value,
    type,
    host: $('svHost').value,
    panel_url: type === 'xxt' ? $('svXxtUrl').value : $('svPanelUrl').value,
    panel_user: type === 'xxt' ? '' : $('svPanelUser').value,
    panel_pass: type === 'xxt' ? $('svXxtPass').value : $('svPanelPass').value,
    ...(type === '3xui' ? { public_port: Number($('svPubPort').value) } : {}),
    sni: type === '3xui' ? $('svSni').value : $('svSshSni').value,
    ssh_port: Number($('svSshPort').value),
    ssh_user: $('svSshUser').value,
    ssh_pass: $('svSshPass').value,
    udp_port: $('svUdpPort').value,
    ...(type === 'xxt' ? { npv_type: $('svXxtProfile').value.trim() || 'SSH-Direct' } : {}),
    ...(type === 'ssh' ? {
      npv_type: $('svNpvType').value,
      udpgw_port: Number($('svUdpgw').value) || 7300,
      proxy_host: $('svProxyHost').value,
      proxy_port: Number($('svProxyPort').value) || null,
      payload: $('svPayload').value
    } : {}),
    template: type === 'xxt' ? $('svXxtTpl').value : $('svTemplate').value,
    is_active: $('svActive').checked
  };
  try {
    if (id) await api('/admin/servers/' + id, { method: 'PUT', body });
    else await api('/admin/servers', { method: 'POST', body });
    S.editingServerId = null;
    S.adminServers = await api('/admin/servers');
    await refreshAll();
    showMsg('ok', id ? 'แก้ไขเซิร์ฟเวอร์เรียบร้อยแล้ว' : 'เพิ่มเซิร์ฟเวอร์ใหม่เรียบร้อยแล้ว');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

async function testServer(id, name) {
  try {
    const res = await api(`/admin/servers/${id}/test`, { method: 'POST' });
    S.serverTestResult = { name, ...res };
    S.adminServers = await api('/admin/servers');
    showMsg('ok', `เชื่อมต่อเซิร์ฟเวอร์ "${name}" สำเร็จ!`);
  } catch (e) {
    S.serverTestResult = null;
    S.adminServers = await api('/admin/servers');
    showMsg('bad', 'ทดสอบไม่ผ่าน: ' + e.message);
  }
}

async function linkXxt() {
  try {
    const r = await api('/admin/xxt-link', { method: 'POST' });
    S.adminServers = await api('/admin/servers');
    S.xxtLink = await api('/admin/xxt-link').catch(() => null);
    await refreshAll();
    showMsg('ok', `${r.created ? 'เชื่อมแดชบอร์ดสำเร็จ' : 'ทดสอบเชื่อมต่อสำเร็จ'} — ผู้ใช้ ${r.users} / ออนไลน์ ${r.online} (WS พอร์ต ${r.ws_port})`);
  } catch (e) {
    showMsg('bad', 'เชื่อมไม่สำเร็จ: ' + e.message);
  }
}

async function linkXui() {
  try {
    const r = await api('/admin/xui-link', { method: 'POST' });
    S.adminServers = await api('/admin/servers');
    S.xxtLink = await api('/admin/xxt-link').catch(() => null);
    await refreshAll();
    showMsg('ok', `${r.created ? 'เชื่อม 3x-ui สำเร็จ' : 'ทดสอบ 3x-ui สำเร็จ'} — พบ ${r.inbounds} Inbound${r.inbounds ? '' : ' (ไปสร้าง Inbound ที่แผง 3x-ui ก่อน แล้วเลือกตอนเพิ่มแพ็กเกจ)'}`);
  } catch (e) {
    showMsg('bad', 'เชื่อม 3x-ui ไม่สำเร็จ: ' + e.message);
  }
}

async function deleteServer(id) {
  if (!confirm('ยืนยันลบเซิร์ฟเวอร์นี้?')) return;
  try {
    await api('/admin/servers/' + id, { method: 'DELETE' });
    S.adminServers = await api('/admin/servers');
    await refreshAll();
    showMsg('ok', 'ลบเซิร์ฟเวอร์เรียบร้อย');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

// --- 3. Admin: เพิ่ม / แก้ไขแพ็กเกจ ---
// กล่องเลือก Inbound (ดึงจาก 3x-ui ของเซิร์ฟเวอร์ที่เลือก)
function inboundBoxHtml(st) {
  if (!st) return '';
  if (st.loading) return `<div class="hint">⏳ กำลังดึงรายการ Inbound จาก 3x-ui...</div>`;
  if (st.error) return `<div class="hint" style="color:var(--bad)">⚠️ ${esc(st.error)}</div>`;
  if (!st.list) return '';
  if (!st.list.length) return `<div class="hint" style="color:var(--bad)">⚠️ ยังไม่มี Inbound ใน 3x-ui นี้ กรุณาสร้างก่อน</div>`;
  const sel = st.selected || (st.list.find(x => x.enable) || st.list[0]).id;
  return `
    <label>เลือก Inbound ที่ใช้สร้างบัญชีลูกค้า (ดึงจาก 3x-ui — พบ ${st.list.length} รายการ)</label>
    <select id="pdInbound">
      ${st.list.map(ib => `<option value="${ib.id}" ${Number(ib.id) === Number(sel) ? 'selected' : ''}>
        #${ib.id} ${esc(ib.remark)} — ${esc(ib.protocol)} / ${esc(ib.network)} / ${esc(ib.security)} • พอร์ต ${ib.port}${ib.enable ? '' : ' (ปิดอยู่)'}
      </option>`).join('')}
    </select>`;
}

async function loadInboundBox(serverId) {
  const box = $('pdInboundBox');
  const sv = S.adminServers.find(x => Number(x.id) === Number(serverId));
  const keep = S.pdInboundState?.selected || null;
  if (!box) return;
  if (!sv || sv.type !== '3xui') { S.pdInboundState = null; box.innerHTML = ''; return; }
  S.pdInboundState = { loading: true, selected: keep };
  box.innerHTML = inboundBoxHtml(S.pdInboundState);
  try {
    const r = await api(`/admin/servers/${sv.id}/inbounds`);
    S.pdInboundState = { list: r.inbounds, selected: keep };
  } catch (e) {
    S.pdInboundState = { error: e.message };
  }
  const b2 = $('pdInboundBox');
  if (b2) b2.innerHTML = inboundBoxHtml(S.pdInboundState);
}

// กล่องเลือกรูปแบบ Config / Profile (ดึงจากแดชบอร์ด XXTLONLINE ของเซิร์ฟเวอร์ที่เลือก)
function profileBoxHtml(st) {
  if (!st) return '';
  if (st.loading) return `<div class="hint">⏳ กำลังดึงรูปแบบ Config จากแดชบอร์ด XXTLONLINE...</div>`;
  if (st.error) return `<div class="hint" style="color:var(--bad)">⚠️ ${esc(st.error)}</div>`;
  if (!st.list) return '';
  const sel = st.selected || '';
  const fallback = st.serverProfile
    ? `Profile ที่ตั้งในเซิร์ฟเวอร์ (${esc(st.serverProfile)})`
    : 'ค่าหลักของแดชบอร์ด';
  return `
    <label>เลือกรูปแบบ Config ที่ใช้สร้างบัญชีลูกค้า (ดึงจากแดชบอร์ด — พบ ${st.list.length} รูปแบบ)</label>
    <select id="pdXxtProfile">
      <option value="" ${sel ? '' : 'selected'}>-- ใช้${fallback} --</option>
      ${st.list.map(p => `<option value="${esc(p.id)}" ${p.id === sel ? 'selected' : ''}>
        ${esc(p.name)} (ID: ${esc(p.id)})${p.id === st.defaultProfile ? ' ★ค่าหลัก' : ''}
      </option>`).join('')}
      ${sel && !st.list.some(p => p.id === sel) ? `<option value="${esc(sel)}" selected>⚠️ ${esc(sel)} (ไม่พบในแดชบอร์ดแล้ว)</option>` : ''}
    </select>`;
}

async function loadProfileBox(serverId, keep) {
  const box = $('pdProfileBox');
  const sv = S.adminServers.find(x => Number(x.id) === Number(serverId));
  if (!box) return;
  if (!sv || sv.type !== 'xxt') { S.pdProfileState = null; box.innerHTML = ''; return; }
  S.pdProfileState = { loading: true, selected: keep || null };
  box.innerHTML = profileBoxHtml(S.pdProfileState);
  try {
    const r = await api(`/admin/servers/${sv.id}/profiles`);
    S.pdProfileState = { list: r.profiles, defaultProfile: r.defaultProfile, serverProfile: r.serverProfile, selected: keep || null };
  } catch (e) {
    S.pdProfileState = { error: e.message };
  }
  const b2 = $('pdProfileBox');
  if (b2) b2.innerHTML = profileBoxHtml(S.pdProfileState);
}

function adminProductsTab() {
  const ed = S.editingProductId ? S.products.find(x => x.id === S.editingProductId) : null;
  const planLines = ed
    ? ed.plans.map(pl => {
      const ap = (S.adminPlans || []).find(x => Number(x.id) === Number(pl.id)) || {};
      const rf = ap.refund_per_day, dc = Number(ap.discount_percent || 0);
      const price = pl.op !== undefined ? pl.op : pl.p;
      const dur = pl.mins && pl.mins % 60 ? `${pl.mins} นาที` : `${pl.hours} ชม`;
      return `${pl.n}, ${dur}, ${price}${(rf !== null && rf !== undefined) || dc > 0 ? ', ' + (rf !== null && rf !== undefined ? Number(rf) : '') : ''}${dc > 0 ? ', ' + dc : ''}`;
    }).join('\n')
    : 'รายวัน, 24 ชม, 15, 15\n7 วัน, 7 วัน, 59, 8, 10\n30 วัน, 30 วัน, 159, 5';

  // เปิดฟอร์มแก้ไขแพ็กเกจของ 3x-ui → โหลดรายการ inbound มาให้เลือกทันที
  S.pdInboundState = { loading: false, list: null, selected: ed?.inboundId || null, error: '' };
  const edServer = ed ? S.adminServers.find(sv => Number(sv.id) === Number(ed.serverId)) : null;
  if (edServer && edServer.type === '3xui') setTimeout(() => loadInboundBox(edServer.id), 0);
  // แพ็กเกจของ XXTLONLINE → โหลดรายการ Profile มาให้เลือกทันที
  S.pdProfileState = null;
  if (edServer && edServer.type === 'xxt') setTimeout(() => loadProfileBox(edServer.id, ed?.xxtProfile || null), 0);

  return `
    ${S.atab === 'add' || ed ? `
      <div class="section-card">
        <h3>
          <span>${ed ? `✏️ แก้ไขแพ็กเกจ: ${esc(ed.title)}` : '➕ เพิ่มแพ็กเกจใหม่'}</span>
          ${ed ? `<button class="btn ghost sm" onclick="S.editingProductId=null;render()">ยกเลิกแก้ไข</button>` : ''}
        </h3>
        <div class="row3">
          <div>
            <label>เครือข่าย</label>
            <select id="pdNet">
              ${['AIS', 'TRUE', 'dtac'].map(n => `<option value="${n}" ${ed?.net === n ? 'selected' : ''}>${n}</option>`).join('')}
            </select>
          </div>
          <div>
            <label>โปรโตคอล</label>
            <select id="pdProto">
              ${['V2RAY', 'SSH', 'UDP'].map(pr => `<option value="${pr}" ${ed?.proto === pr ? 'selected' : ''}>${pr}</option>`).join('')}
            </select>
          </div>
          <div>
            <label>ผูกเซิร์ฟเวอร์สร้างบัญชีอัตโนมัติ</label>
            <select id="pdServer" onchange="loadInboundBox(this.value);loadProfileBox(this.value)">
              <option value="">-- สร้างบัญชีจำลองพื้นฐาน --</option>
              ${S.adminServers.map(sv => `<option value="${sv.id}" ${Number(ed?.serverId) === Number(sv.id) ? 'selected' : ''}>${esc(sv.name)} (${sv.type.toUpperCase()})</option>`).join('')}
            </select>
          </div>
        </div>
        <div id="pdInboundBox">${inboundBoxHtml(S.pdInboundState)}</div>
        <div id="pdProfileBox">${profileBoxHtml(S.pdProfileState)}</div>

        <div class="row2">
          <div>
            <label>ชื่อแพ็กเกจ</label>
            <input id="pdTitle" value="${esc(ed?.title || '')}" placeholder="เช่น AIS No-Limit 3x-ui ไฟเบอร์">
          </div>
          <div>
            <label>ป้ายโปรโมชั่น (Badge)</label>
            <input id="pdBadge" value="${esc(ed?.badge || '')}" placeholder="เช่น ขายดี / แนะนำ / ลดราคา">
          </div>
        </div>

        <label>รายละเอียดแพ็กเกจ</label>
        <textarea id="pdDesc" rows="2" placeholder="ระบุความเร็ว การรองรับเกม/สตรีมมิ่ง หรือเงื่อนไขโปรเน็ต...">${esc(ed?.desc || '')}</textarea>

        <label>ตัวเลือกราคาและระยะเวลา (บรรทัดละ 1 ราคา: ชื่อแพ็กเกจ, ระยะเวลา, ราคา, ราคาคืนเงินต่อวัน, ส่วนลด%)</label>
        <div class="hint" style="margin:-2px 0 6px">ระยะเวลาใส่เป็น <code>20 นาที</code> / <code>24 ชม</code> / <code>7 วัน</code> ได้ • <b>แพ็กเกจทดลองฟรี</b> = ตั้งราคา 0 เช่น <code>ทดลองฟรี, 20 นาที, 0</code> (ลูกค้าแต่ละคนรับได้ 1 ครั้ง นับรวมทุกแพ็กเกจราคา 0, ต่ออายุไม่ได้)<br>คอลัมน์ที่ 4 (ไม่บังคับ) = ราคาคืนเงิน/วัน ตอนคืนเงินระบบคิด <b>วันที่เหลือ × ราคาคืนต่อวัน</b> เช่น <code>30 วัน, 30 วัน, 50, 1</code> = เหลือ 20 วันคืน 20 ฿ • เว้นว่าง = ใช้ราคา ÷ จำนวนวัน<br>คอลัมน์ที่ 5 (ไม่บังคับ) = <b>ส่วนลดเฉพาะราคานี้ (%)</b> 0-90 เช่น <code>7 วัน, 7 วัน, 59, 8, 10</code> = ลด 10% เหลือ 53.10 ฿ (ถ้าไม่ใส่คืนเงิน ให้เว้นช่องที่ 4 ว่าง เช่น <code>7 วัน, 7 วัน, 59, , 10</code>) • ไม่ใส่ = ไม่ลด • ใช้ร่วมกับโค้ดส่วนลดได้</div>
        <textarea id="pdPlans" rows="4">${esc(planLines)}</textarea>

        <label>รูปแบนเนอร์แพ็กเกจ</label>
        <input id="pdImgFile" type="file" accept="image/*">
        ${ed?.img ? `<img class="img-prev" src="${esc(ed.img)}">` : ''}

        <button class="btn" style="margin-top:16px" onclick="saveProductForm(${ed ? ed.id : 'null'})">${ed ? '💾 บันทึกการแก้ไขแพ็กเกจ' : '➕ เปิดขายแพ็กเกจ'}</button>
      </div>
    ` : ''}

    <div class="section-card">
      <h3>📦 แพ็กเกจที่เปิดขายอยู่ (${S.products.length})</h3>
      <div class="table-wrap">
        <table>
          <thead><tr><th>แพ็กเกจ</th><th>เครือข่าย / โปรโตคอล</th><th>เซิร์ฟเวอร์</th><th>ตัวเลือกราคา</th><th>จัดการ</th></tr></thead>
          <tbody>
            ${S.products.length ? S.products.map(p => `
              <tr>
                <td><b>${esc(p.title)}</b> ${p.badge ? `<span class="tag promo">${esc(p.badge)}</span>` : ''}</td>
                <td><span class="tag ${esc(p.net)}">${esc(p.net)}</span> <span class="tag">${esc(p.proto)}</span></td>
                <td>${p.serverName ? `<span class="tag srv">${esc(p.serverName)}</span>${p.inboundId ? ` <span class="tag">Inbound #${p.inboundId}</span>` : ''}${p.xxtProfile ? ` <span class="tag">Profile ${esc(p.xxtProfile)}</span>` : ''}` : '-'}</td>
                <td>${p.plans.map(pl => `${esc(pl.n)} (${money(pl.p)}฿)`).join(', ')}</td>
                <td style="white-space:nowrap">
                  <button class="btn sm ghost" onclick="S.editingProductId=${p.id};render()">แก้ไข</button>
                  <button class="btn sm danger" onclick="hideProduct(${p.id})">ซ่อน/ลบ</button>
                </td>
              </tr>
            `).join('') : `<tr><td colspan="5" class="empty">ยังไม่มีแพ็กเกจ</td></tr>`}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

async function saveProductForm(id) {
  try {
    const lines = $('pdPlans').value.split('\n').map(l => l.trim()).filter(Boolean);
    const plans = lines.map(l => {
      const [n, d, p, rf, dc] = l.split(',').map(x => x.trim());
      return { n, d, p, rf: rf === undefined ? '' : rf, dc: dc === undefined ? '' : dc };
    });
    const sv = S.adminServers.find(x => Number(x.id) === Number($('pdServer').value));
    if (sv && sv.type === '3xui' && !($('pdInbound') && $('pdInbound').value)) {
      throw new Error('กรุณาเลือก Inbound ที่จะใช้สร้างบัญชีสำหรับแพ็กเกจนี้');
    }
    const f = $('pdImgFile').files[0];
    const img = f ? await readImg(f, 900) : undefined;
    const body = {
      serverId: $('pdServer').value ? Number($('pdServer').value) : null,
      inboundId: $('pdInbound') && $('pdInbound').value ? Number($('pdInbound').value) : null,
      xxtProfile: sv && sv.type === 'xxt' && $('pdXxtProfile') ? $('pdXxtProfile').value : '',
      net: $('pdNet').value,
      proto: $('pdProto').value,
      title: $('pdTitle').value,
      badge: $('pdBadge').value,
      desc: $('pdDesc').value,
      plans,
      ...(img !== undefined ? { img } : {})
    };
    if (id) await api('/admin/products/' + id, { method: 'PUT', body });
    else await api('/admin/products', { method: 'POST', body });
    S.editingProductId = null;
    await refreshAll();
    showMsg('ok', id ? 'บันทึกแก้ไขแพ็กเกจเรียบร้อย' : 'เพิ่มแพ็กเกจใหม่เรียบร้อย');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

async function hideProduct(id) {
  if (!confirm('ยืนยันซ่อน/ลบแพ็กเกจนี้จากหน้าร้าน?')) return;
  try {
    await api('/admin/products/' + id, { method: 'DELETE' });
    await refreshAll();
    showMsg('ok', 'ซ่อนแพ็กเกจเรียบร้อย');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

// --- 4. Admin: เติมเงิน / คูปอง / คืนเงิน / แจ้งปัญหา ---
function adminTopupsTab() {
  return `
    <div class="section-card">
      <h3>💰 รายการแจ้งเติมเงินรอตรวจสอบ (${S.adminTopups.length})</h3>
      ${S.adminTopups.length ? S.adminTopups.map(t => `
        <div style="border:1px solid var(--line);border-radius:12px;padding:14px;margin-bottom:12px;display:flex;gap:14px;flex-wrap:wrap;justify-content:space-between;align-items:center">
          <div>
            <b>#${t.id} • @${esc(t.username)}</b> • <span class="tag">${TOPUP_METHOD[t.method] || t.method}</span>
            <div style="font-size:16px;font-weight:800;color:var(--brand);margin:4px 0">
              ${money(t.amount)} ฿ ${Number(t.bonus_amount) > 0 ? `<small style="color:var(--ok)">(+โบนัส ${money(t.bonus_amount)} ฿)</small>` : ''}
            </div>
            <div class="hint">${fdt(t.created_at)} ${t.verify_note ? `• หมายเหตุ: ${esc(t.verify_note)}` : ''}</div>
            ${t.method === 'truemoney' ? `<div class="acct">${esc(t.proof)}</div>` : ''}
          </div>
          ${t.method === 'bank' && t.proof ? `<img src="${esc(t.proof)}" style="width:120px;height:150px;object-fit:cover;border-radius:10px;border:1px solid var(--line);cursor:pointer" onclick="window.open(this.src)">` : ''}
          <div style="display:flex;gap:8px">
            <button class="btn ok sm" onclick="actTopup(${t.id}, 'approve')">✅ อนุมัติ</button>
            <button class="btn danger sm" onclick="actTopup(${t.id}, 'reject')">❌ ปฏิเสธ</button>
          </div>
        </div>
      `).join('') : `<div class="empty">ไม่มีรายการเติมเงินค้างตรวจสอบ</div>`}
    </div>
  `;
}

async function actTopup(id, act) {
  try {
    await api(`/admin/topups/${id}/${act}`, { method: 'POST' });
    S.adminTopups = await api('/admin/topups');
    await refreshAll();
    showMsg('ok', act === 'approve' ? 'อนุมัติเติมเงินเรียบร้อย' : 'ปฏิเสธรายการเรียบร้อย');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

function adminDashTab() {
  const d = S.adminDash;
  if (!d) return `<div class="section-card empty">กำลังโหลด...</div>`;
  const max = Math.max(1, ...d.daily.map(x => x.sales));
  const kpi = (icon, tone, label, val, sub) => `<div class="kpi ${tone}"><div class="kic">${admIcon(icon)}</div><span>${label}</span><b>${val}</b>${sub ? `<small class="hint">${sub}</small>` : ''}</div>`;
  return `
    <div class="kpis" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px;margin-bottom:18px">
      ${kpi('trend', 't-ok', 'ยอดขายวันนี้', money(d.sales.today) + ' ฿', d.sales.ordersToday + ' ออเดอร์')}
      ${kpi('receipt', '', 'ยอดขายเดือนนี้', money(d.sales.month) + ' ฿', d.sales.ordersMonth + ' ออเดอร์')}
      ${kpi('wallet', 't-cyan', 'เติมเงินวันนี้', money(d.topup.today) + ' ฿')}
      ${kpi('bank', 't-cyan', 'เติมเงินเดือนนี้', money(d.topup.month) + ' ฿')}
      ${kpi('users', 't-violet', 'สมาชิกทั้งหมด', Number(d.misc.users).toLocaleString(), '+' + d.misc.new_users_7d + ' ใน 7 วัน')}
      ${kpi('zap', 't-ok', 'บัญชีที่ใช้งานอยู่', d.misc.active_orders, d.misc.expiring_3d + ' ใกล้หมดใน 3 วัน')}
      ${kpi('clipboard', d.misc.pending_topups ? 't-warn' : 't-ok', 'สลิปรอตรวจ', d.misc.pending_topups)}
      ${kpi('message', d.misc.open_tickets ? 't-bad' : 't-ok', 'ทิกเก็ตค้าง', d.misc.open_tickets)}
      ${kpi('shield', 't-warn', 'เครดิตคงค้างในระบบ', money(d.misc.credit_outstanding) + ' ฿', 'ภาระที่ลูกค้ายังใช้ได้')}
    </div>
    <div class="section-card">
      <h3>📈 ยอดขาย 14 วันล่าสุด</h3>
      <div style="display:flex;align-items:flex-end;gap:5px;height:140px;margin-top:10px">
        ${d.daily.map(x => `<div title="${x.day}: ${money(x.sales)} ฿" style="flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%">
          <div style="width:100%;background:var(--brand);border-radius:4px 4px 0 0;height:${Math.max(2, Math.round(x.sales / max * 100))}%"></div>
          <small style="font-size:10px;margin-top:3px">${x.day.slice(0, 2)}</small></div>`).join('')}
      </div>
    </div>
    <div class="section-card">
      <h3>🏆 แพ็กเกจขายดี (30 วัน)</h3>
      ${d.best.length ? `<div class="table-wrap"><table><thead><tr><th>แพ็กเกจ</th><th>ขายได้</th><th>รายได้</th></tr></thead><tbody>
        ${d.best.map(b => `<tr><td>${esc(b.name)}</td><td>${b.n}</td><td>${money(b.revenue)} ฿</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty">ยังไม่มีข้อมูลการขาย</div>'}
    </div>`;
}

function adminCouponsTab() {
  return `
    <div class="section-card">
      <h3>🎟️ สร้างคูปองส่วนลดใหม่</h3>
      <div class="row3">
        <div>
          <label>โค้ดส่วนลด</label>
          <input id="cpCode" placeholder="เช่น VIP20">
        </div>
        <div>
          <label>ส่วนลด (%)</label>
          <input id="cpPct" type="number" min="1" max="100" value="10">
        </div>
        <div>
          <label>จำนวนสิทธิ์รวม (ทุกคน)</label>
          <input id="cpUses" type="number" min="1" value="50">
        </div>
      </div>
      <label>สิทธิ์ต่อคน (0 = ไม่จำกัด)</label>
      <input id="cpPer" type="number" min="0" max="1000" value="1">
      <button class="btn" style="margin-top:14px" onclick="createCoupon()">สร้างคูปอง</button>
    </div>

    <div class="section-card">
      <h3>รายการคูปองทั้งหมด (${S.adminCoupons.length})</h3>
      <div class="table-wrap">
        <table>
          <thead><tr><th>โค้ด</th><th>ส่วนลด</th><th>คงเหลือ (รวม)</th><th>ต่อคน</th><th>ใช้ไปแล้ว</th><th>จัดการ</th></tr></thead>
          <tbody>
            ${S.adminCoupons.map(c => `
              <tr>
                <td><b>${esc(c.code)}</b></td>
                <td>${c.percent}%</td>
                <td>${c.remaining_uses} สิทธิ์</td>
                <td>${c.per_user_limit > 0 ? c.per_user_limit + ' ครั้ง/คน' : 'ไม่จำกัด'}</td>
                <td>${c.used || 0}</td>
                <td>${c.remaining_uses > 0 ? `<button class="btn danger sm" onclick="disableCoupon(${c.id})">ปิดใช้งาน</button>` : `<span class="tag">หมดสิทธิ์</span>`}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

async function createCoupon() {
  try {
    await api('/admin/coupons', {
      method: 'POST',
      body: {
        code: $('cpCode').value,
        percent: Number($('cpPct').value),
        remaining_uses: Number($('cpUses').value),
        per_user_limit: Number($('cpPer').value)
      }
    });
    S.adminCoupons = await api('/admin/coupons');
    showMsg('ok', 'สร้างคูปองส่วนลดเรียบร้อย');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

async function disableCoupon(id) {
  await api('/admin/coupons/' + id, { method: 'DELETE' });
  S.adminCoupons = await api('/admin/coupons');
  render();
}

const OST = { active: ['ok', 'ใช้งานอยู่'], expired: ['bad', 'หมดอายุ'], refunded: ['promo', 'คืนเงินแล้ว'], cancelled: ['bad', 'ยกเลิก'] };
const OQ = { q: '', status: '', total: 0 };

async function loadAdminOrders() {
  const qs = new URLSearchParams();
  if (OQ.q) qs.set('q', OQ.q);
  if (OQ.status) qs.set('status', OQ.status);
  const r = await fetch('/api/admin/orders?' + qs, { credentials: 'same-origin' });
  const d = await r.json().catch(() => []);
  if (!r.ok) throw new Error(d.error || 'โหลดออเดอร์ไม่สำเร็จ');
  OQ.total = Number(r.headers.get('X-Total-Orders')) || d.length;
  S.adminOrders = d;
}
// รีเฟรชสถานะเชื่อมต่อทุก 5 วินาทีเมื่อเปิดแท็บออเดอร์อยู่ (ข้ามถ้ากำลังพิมพ์/เปิดหน้าต่างรายละเอียด)
let _ordLiveBusy = false;
setInterval(async () => {
  if (_ordLiveBusy || document.hidden || !S.user || S.view !== 'admin' || S.atab !== 'orders') return;
  const ae = document.activeElement;
  if (($('dlg') && $('dlg').open) || (ae && /^(INPUT|SELECT|TEXTAREA)$/.test(ae.tagName))) return;
  _ordLiveBusy = true;
  try {
    await loadAdminOrders();
    // อัปเดตเฉพาะช่อง "เชื่อมต่อตอนนี้" — ไม่ render ทั้งหน้า (ไม่เด้ง scroll)
    S.adminOrders.forEach(o => { const el = document.querySelector(`[data-live="${o.id}"]`); if (el) el.innerHTML = liveBadge(o); });
  } catch { /* ข้ามรอบนี้ */ } finally { _ordLiveBusy = false; }
}, 5000);

async function searchOrders() {
  OQ.q = ($('ordQ') || {}).value || '';
  OQ.status = ($('ordSt') || {}).value || '';
  try { await loadAdminOrders(); render(); } catch (e) { showMsg('bad', e.message); }
}

// สถานะการเชื่อมต่อสด: 🟢 เชื่อมต่อ N IP (M การเชื่อมต่อ) / ⚪ ออฟไลน์ / — ไม่ทราบ (เซิร์ฟเวอร์ที่ไม่รองรับ)
function liveBadge(o) {
  const lv = o.live;
  if (!lv) return '<span style="color:var(--sub)">—</span>';
  if (!lv.conns) return '<span style="color:var(--sub)">⚪ ออฟไลน์</span>';
  const many = lv.ips !== null && lv.ips >= 3;
  const ipTxt = lv.ips === null ? '' : `<b>${lv.ips} IP</b> • `;
  return `<span title="${esc((lv.ipList || []).join('\n'))}" style="color:${many ? 'var(--bad,#d33)' : 'var(--ok,#2a9d5c)'}">🟢 ${ipTxt}${lv.conns} การเชื่อมต่อ</span>`
    + (lv.ipList && lv.ipList.length ? `<br><small style="color:var(--sub);word-break:break-all">${lv.ipList.map(esc).join(', ')}</small>` : '');
}

function adminOrdersTab() {
  const daysLeft = o => Math.ceil((new Date(o.expires_at) - Date.now()) / 86400e3);
  return `
    <div class="section-card">
      <h3>🧾 ไฟล์/ออเดอร์ที่ขายทั้งหมด (แสดง ${S.adminOrders.length} จาก ${OQ.total})</h3>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0 12px">
        <input id="ordQ" placeholder="ค้นหา: ชื่อผู้ซื้อ / #เลขออเดอร์ / ชื่อบัญชี / สินค้า" value="${esc(OQ.q)}" style="flex:1;min-width:200px" onkeydown="if(event.key==='Enter')searchOrders()">
        <select id="ordSt" onchange="searchOrders()">
          <option value="">ทุกสถานะ</option>
          ${Object.entries(OST).map(([k, v]) => `<option value="${k}" ${OQ.status === k ? 'selected' : ''}>${v[1]}</option>`).join('')}
        </select>
        <button class="btn sm" onclick="searchOrders()">🔍 ค้นหา</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>#</th><th>ผู้ซื้อ</th><th>สินค้า / แพ็กเกจ</th><th>บัญชี / เซิร์ฟเวอร์</th><th>ยอดจ่าย</th><th>สถานะ</th><th>เชื่อมต่อตอนนี้</th><th>จัดการ</th></tr></thead>
          <tbody>
            ${S.adminOrders.map(o => `
              <tr>
                <td>#${o.id}</td>
                <td>@${esc(o.username)}</td>
                <td>${esc(o.title)} - ${esc(o.plan_name)}<br><small style="color:var(--sub)">ซื้อ ${fdt(o.created_at)}<br>หมดอายุ ${fdt(o.expires_at)}${o.status === 'active' ? ` (เหลือ ${Math.max(0, daysLeft(o))} วัน)` : ''}</small></td>
                <td><small>${o.client_email ? '<b>' + esc(o.client_email) + '</b><br>' : ''}${esc(o.server_name || '—')}${o.auto_renew ? '<br>🔁 ต่ออายุอัตโนมัติ' : ''}</small></td>
                <td><b>${money(o.price_paid)} ฿</b></td>
                <td><span class="tag ${(OST[o.status] || [''])[0]}">${(OST[o.status] || [0, o.status])[1]}</span></td>
                <td data-live="${o.id}">${liveBadge(o)}</td>
                <td style="white-space:nowrap">
                  <button class="btn sm" onclick="openOrderEdit(${o.id})">📄 รายละเอียด / แก้ไข</button>
                  ${o.status !== 'refunded' ? `<button class="btn danger sm" onclick="refundOrder(${o.id})">คืนเครดิต</button>` : ''}
                </td>
              </tr>
            `).join('') || '<tr><td colspan="8" style="text-align:center;color:var(--sub)">ไม่พบออเดอร์</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

// ---------- รายละเอียด / แก้ไขออเดอร์ ----------
const OE = { o: null, busy: false };
const toLocalInput = iso => {
  const d = new Date(iso);
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};

async function openOrderEdit(id) {
  try {
    OE.o = await api(`/admin/orders/${id}`);
    renderOrderEdit();
    if (!$('dlg').open) $('dlg').showModal();
  } catch (e) { showMsg('bad', e.message); }
}

function oeAddDays(n) {
  const el = $('oeExp');
  const base = new Date(el.value || Date.now());
  const from = base > new Date() ? base : new Date();
  from.setDate(from.getDate() + n);
  el.value = toLocalInput(from);
}

function renderOrderEdit() {
  const o = OE.o;
  const refunded = o.status === 'refunded';
  const st = OST[o.status] || ['', o.status];
  const row = (k, v) => `<div class="sum-row"><span>${k}</span><b style="text-align:right;word-break:break-all">${v}</b></div>`;
  const led = (o.ledger || []).map(l => `<div class="sum-row"><span>${l.type === 'refund' ? 'คืนเครดิต' : 'ตัดเครดิต'} • ${fdt(l.created_at)}${l.note ? ' • ' + esc(l.note) : ''}</span><b style="color:${l.amount > 0 ? 'var(--ok,#2a9d5c)' : 'inherit'}">${l.amount > 0 ? '+' : ''}${money(l.amount)} ฿</b></div>`).join('');
  const tk = (o.tickets || []).map(t => `<div class="sum-row"><span>#${t.id} ${esc(t.subject)}</span><b>${esc(t.status)}</b></div>`).join('');
  $('dlgBody').innerHTML = `
    <button class="x" onclick="closeDlg()" aria-label="ปิด">×</button>
    <h3>📄 ออเดอร์ #${o.id} <span class="tag ${st[0]}" style="font-size:12px">${st[1] || o.status}</span></h3>
    <div class="hint" style="margin:-4px 0 12px">@${esc(o.username)}${o.is_banned ? ' (ถูกแบน)' : ''} • ${esc(o.title)} - ${esc(o.plan_name)}</div>
    ${o.deprovisioned_at ? `<div class="msg bad slim" style="margin-bottom:10px">บัญชีนี้ถูกลบออกจากเซิร์ฟเวอร์แล้วเมื่อ ${fdt(o.deprovisioned_at)} — การแก้วันหมดอายุในร้านจะไม่ทำให้บัญชีกลับมาใช้งานได้</div>` : ''}
    <div class="sum">
      ${row('ผู้ซื้อ', '@' + esc(o.username) + ' (เครดิตคงเหลือ ' + money(o.credit_balance) + ' ฿)')}
      ${row('วันที่ซื้อ', fdt(o.created_at))}
      ${row('ราคาแพ็กเกจ / ยอดที่จ่าย', money(o.plan_price) + ' / ' + money(o.price_paid) + ' ฿')}
      ${o.coupon_code ? row('คูปอง', esc(o.coupon_code) + ' (' + o.coupon_percent + '%)') : ''}
      ${row('ระยะเวลาแพ็กเกจ', Math.round(o.duration_hours / 24 * 100) / 100 + ' วัน')}
      ${row('เซิร์ฟเวอร์', o.server_name ? esc(o.server_name) + ' (' + esc(o.server_type) + ' • ' + esc(o.server_host) + ')' : '—')}
      ${o.client_uuid ? row('Client UUID', esc(o.client_uuid)) : ''}
      ${o.live ? row('เชื่อมต่อตอนนี้', o.live.conns ? (o.live.ips !== null ? o.live.ips + ' IP' : '') + ' (' + o.live.conns + ' การเชื่อมต่อ)' + (o.live.ipList.length ? '<br><small>' + o.live.ipList.map(esc).join(', ') + '</small>' : '') : 'ออฟไลน์') : ''}
      ${o.usage ? row('การใช้ข้อมูล', fmtBytes(o.usage.used) + (o.usage.total > 0 ? ' / ' + fmtBytes(o.usage.total) : ' (ไม่จำกัด)')) : ''}
    </div>
    ${led ? `<div class="hint" style="margin:12px 0 4px">ประวัติเครดิตของออเดอร์นี้</div><div class="sum">${led}</div>` : ''}
    ${tk ? `<div class="hint" style="margin:12px 0 4px">เรื่องแจ้งปัญหา</div><div class="sum">${tk}</div>` : ''}

    <div class="hint" style="margin:16px 0 6px"><b>✏️ แก้ไข</b> ${refunded ? '(ออเดอร์ที่คืนเงินแล้วแก้สถานะไม่ได้)' : ''}</div>
    <label class="hint">สถานะ</label>
    <select id="oeStatus" ${refunded ? 'disabled' : ''}>
      ${refunded ? '<option>คืนเงินแล้ว</option>' : ['active', 'expired', 'cancelled'].map(k => `<option value="${k}" ${o.status === k ? 'selected' : ''}>${OST[k][1]} (${k})</option>`).join('')}
    </select>
    <label class="hint" style="margin-top:8px;display:block">วันหมดอายุ</label>
    <input id="oeExp" type="datetime-local" value="${toLocalInput(o.expires_at)}">
    <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">
      ${[1, 7, 30].map(n => `<button class="btn ghost sm" type="button" onclick="oeAddDays(${n})">+${n} วัน</button>`).join('')}
      <button class="btn ghost sm" type="button" onclick="oeAddDays(-1)">−1 วัน</button>
    </div>
    <label class="hint" style="margin-top:8px;display:block">ชื่อบัญชี/อีเมลบนเซิร์ฟเวอร์ (client_email)</label>
    <input id="oeEmail" value="${esc(o.client_email || '')}" maxlength="150">
    <label style="display:flex;gap:8px;align-items:center;margin-top:10px"><input id="oeAuto" type="checkbox" ${o.auto_renew ? 'checked' : ''}> ต่ออายุอัตโนมัติ</label>
    <label class="hint" style="margin-top:8px;display:block">ข้อมูลบัญชีที่ลูกค้าเห็น (ลิงก์/ไฟล์ส่งออกสร้างจากข้อความนี้)</label>
    <textarea id="oeAcc" rows="8" style="font-family:monospace;font-size:12px;width:100%">${esc(o.account_data)}</textarea>
    <div style="display:flex;gap:6px;margin-top:6px"><button class="btn ghost sm" type="button" onclick="copyIn(this, $('oeAcc').value)">📋 คัดลอกข้อมูลบัญชี</button></div>
    <div class="msg slim" style="margin-top:12px">การแก้ไขนี้เปลี่ยนเฉพาะข้อมูลในร้าน ไม่ได้สั่งแก้บัญชีบนเซิร์ฟเวอร์ VPS (ถ้าต้องการให้บัญชีหมดอายุ/ใช้งานได้ตามจริง ต้องแก้บนแดชบอร์ดเซิร์ฟเวอร์ด้วย) และทุกการแก้ไขถูกบันทึกใน audit log</div>
    <div id="oeErr"></div>
    <div class="co-bar">
      <div class="co-actions" style="width:100%;justify-content:flex-end">
        <button class="btn ghost" onclick="closeDlg()">ปิด</button>
        <button class="btn" id="btnOe" onclick="saveOrderEdit()">💾 บันทึก</button>
      </div>
    </div>`;
}

async function saveOrderEdit() {
  const o = OE.o;
  if (!o || OE.busy) return;
  const body = {
    expires_at: new Date($('oeExp').value).toISOString(),
    client_email: $('oeEmail').value,
    auto_renew: $('oeAuto').checked,
    account_data: $('oeAcc').value
  };
  if (o.status !== 'refunded') body.status = $('oeStatus').value;
  const btn = $('btnOe');
  OE.busy = true; btn.disabled = true; btn.textContent = 'กำลังบันทึก...';
  try {
    const r = await api(`/admin/orders/${o.id}`, { method: 'PUT', body });
    $('dlg').close();
    await loadAdminOrders();
    render();
    showMsg('ok', r.changed ? `บันทึกออเดอร์ #${o.id} แล้ว` : 'ไม่มีการเปลี่ยนแปลง');
  } catch (e) {
    $('oeErr').innerHTML = `<div class="msg bad">${esc(e.message)}</div>`;
    btn.disabled = false; btn.textContent = '💾 บันทึก';
  } finally { OE.busy = false; }
}

const R = { id: 0, pv: null, mode: 'prorata', custom: '', busy: false };

async function refundOrder(id) {
  try {
    const pv = await api(`/admin/orders/${id}/refund-preview`);
    Object.assign(R, { id, pv, mode: 'prorata', custom: '', busy: false });
    renderRefund();
    if (!$('dlg').open) $('dlg').showModal();
  } catch (e) {
    showMsg('bad', e.message);
  }
}

function refundAmount() {
  const pv = R.pv;
  if (R.mode === 'prorata') return pv.prorata;
  if (R.mode === 'full') return pv.paidFirst;
  if (R.mode === 'fullall') return pv.paidTotal;
  const v = parseFloat(R.custom);
  return v >= 0 && v <= pv.paidTotal ? Math.round(v * 100) / 100 : NaN;
}

function setRefundMode(m) { R.mode = m; renderRefund(); }

function onRefundCustom(v) {
  R.custom = v;
  const a = refundAmount();
  const el = $('rfAmt');
  if (el) el.textContent = Number.isNaN(a) ? '—' : money(a) + ' ฿';
  const b = $('btnRefund');
  if (b) b.disabled = Number.isNaN(a);
}

function renderRefund() {
  const pv = R.pv;
  const amt = refundAmount();
  const opt = (m, title, sub, price) => `
    <label class="${R.mode === m ? 'on' : ''}">
      <input type="radio" name="rfMode" ${R.mode === m ? 'checked' : ''} onchange="setRefundMode('${m}')">
      <span class="pl-main"><b>${title}</b><small>${sub}</small></span>
      <b class="pl-price">${price}</b>
    </label>`;
  $('dlgBody').innerHTML = `
    <button class="x" onclick="closeDlg()" aria-label="ปิด">×</button>
    <h3>💸 คืนเครดิต ออเดอร์ #${pv.orderId}</h3>
    <div class="hint" style="margin:-4px 0 12px">@${esc(pv.username)} • ${esc(pv.title)} - ${esc(pv.planName)}</div>
    <div class="sum">
      <div class="sum-row"><span>หมดอายุ</span><b>${fdt(pv.expiresAt)}</b></div>
      <div class="sum-row"><span>จำนวนวันที่เหลือ</span><b>${pv.remainingDays} วัน</b></div>
      <div class="sum-row"><span>ราคาคืนเงินต่อวัน ${pv.rateSource === 'plan' ? '(ที่ตั้งไว้ในแพ็กเกจ)' : '(อัตโนมัติ = ราคา ÷ วัน)'}</span><b>${money(pv.ratePerDay)} ฿</b></div>
      <div class="sum-row"><span>ยอดที่ลูกค้าจ่ายทั้งหมด</span><b>${money(pv.paidTotal)} ฿</b></div>
    </div>
    <div class="plans">
      ${opt('prorata', 'ตามวันที่เหลือ', `${pv.remainingDays} วัน × ${money(pv.ratePerDay)} ฿${pv.capped ? ' (จำกัดไม่เกินยอดที่จ่าย)' : ''}`, money(pv.prorata) + ' ฿')}
      ${opt('full', 'คืนเต็มราคาซื้อครั้งแรก', 'ไม่คิดตามวันที่ใช้ไป', money(pv.paidFirst) + ' ฿')}
      ${pv.paidTotal > pv.paidFirst ? opt('fullall', 'คืนเต็มรวมค่าต่ออายุ', 'ซื้อครั้งแรก + ต่ออายุทั้งหมด', money(pv.paidTotal) + ' ฿') : ''}
      ${opt('custom', 'กำหนดยอดเอง', `ไม่เกิน ${money(pv.paidTotal)} ฿`, '✎')}
    </div>
    ${R.mode === 'custom' ? `<input id="rfCustom" type="number" min="0" max="${pv.paidTotal}" step="0.01" placeholder="ระบุยอดที่จะคืน (บาท)" value="${esc(R.custom)}" oninput="onRefundCustom(this.value)" autofocus>` : ''}
    <div class="msg bad slim" style="margin-top:12px">ระบบจะลบ/ปิดบัญชีนี้บนเซิร์ฟเวอร์ก่อน แล้วจึงคืนเครดิต ออเดอร์จะเป็นสถานะ refunded และต่ออายุไม่ได้อีก</div>
    <div id="rfErr"></div>
    <div class="co-bar">
      <div class="co-total"><small>ยอดที่จะคืน</small><b id="rfAmt">${Number.isNaN(amt) ? '—' : money(amt) + ' ฿'}</b></div>
      <div class="co-actions">
        <button class="btn ghost" onclick="closeDlg()">ยกเลิก</button>
        <button class="btn danger" id="btnRefund" onclick="confirmRefund()" ${Number.isNaN(amt) ? 'disabled' : ''}>ยืนยันคืนเครดิต</button>
      </div>
    </div>`;
}

async function confirmRefund() {
  const amt = refundAmount();
  if (Number.isNaN(amt)) return;
  const mode = R.mode === 'prorata' ? 'prorata' : R.mode === 'custom' ? 'custom' : 'full';
  const call = force => api(`/admin/orders/${R.id}/refund`, {
    method: 'POST',
    body: { mode, includeRenewals: R.mode === 'fullall', customAmount: mode === 'custom' ? amt : undefined, force }
  });
  const btn = $('btnRefund');
  btn.disabled = true;
  btn.textContent = 'กำลังดำเนินการ...';
  C.busy = true;
  try {
    let r;
    try {
      r = await call(false);
    } catch (e) {
      if (!/ปิดบัญชีบนเซิร์ฟเวอร์ไม่สำเร็จ/.test(e.message)) throw e;
      if (!confirm(`${e.message}\n\nคืนเงินต่อเลยโดยไม่ปิดบัญชีบนเซิร์ฟเวอร์? (ต้องไปลบ client/user เองภายหลัง)`)) throw e;
      r = await call(true);
    }
    C.busy = false;
    $('dlg').close();
    await loadAdminOrders();
    await refreshAll();
    showMsg('ok', `คืนเครดิตคำสั่งซื้อ #${R.id} จำนวน ${money(r.amount)} ฿ แล้ว` + (r.account === 'failed_forced' ? ' (แต่ยังปิดบัญชีบนเซิร์ฟเวอร์ไม่สำเร็จ ต้องลบเอง)' : ''));
  } catch (e) {
    C.busy = false;
    $('rfErr').innerHTML = `<div class="msg bad">${esc(e.message)}</div>`;
    btn.disabled = false;
    btn.textContent = 'ลองอีกครั้ง';
  }
}

function adminTicketsTab() {
  return `
    <div class="section-card">
      <h3>💬 รายการแจ้งปัญหาจากลูกค้า (${S.adminTickets.length})</h3>
      ${S.adminTickets.length ? S.adminTickets.map(t => {
        const st = tkStatus(t.status);
        const thread = tkThread(t);
        return `
        <div style="border:1px solid var(--line);border-radius:12px;padding:14px;margin-bottom:12px">
          <div style="display:flex;justify-content:space-between;gap:8px">
            <b>#${t.id} • @${esc(t.username)} — ${esc(t.subject)}</b>
            <span class="tag ${t.status === 'open' ? 'bad' : t.status === 'answered' ? 'ok' : ''}" style="white-space:nowrap">${st.label}</span>
          </div>
          <div class="hint">${fdt(t.created_at)} ${t.order_id ? `• ออเดอร์ #${t.order_id}` : ''}</div>
          <div style="margin:10px 0;display:flex;flex-direction:column;gap:6px">
            ${thread.map(m => `<div style="font-size:14px;white-space:pre-wrap;word-break:break-word"><b>${m.sender === 'admin' ? 'แอดมิน' : '@' + esc(t.username)}</b> <span class="hint">${fdt(m.created_at)}</span><br>${esc(m.body)}</div>`).join('')}
          </div>
          ${t.status === 'closed' ? `<div class="hint">🔒 ปิดเรื่องแล้ว (ลูกค้าตอบเพิ่มไม่ได้)</div>` : ''}
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <input id="tkReply_${t.id}" style="flex:1;min-width:160px" placeholder="พิมพ์ข้อความตอบกลับลูกค้า...">
            <button class="btn sm" onclick="replyTicket(${t.id}, 'answered')">ส่งคำตอบ</button>
            ${t.status === 'closed'
              ? `<button class="btn sm" onclick="replyTicket(${t.id}, 'open')">เปิดเรื่องอีกครั้ง</button>`
              : `<button class="btn sm" onclick="replyTicket(${t.id}, 'closed')">ตอบและปิดเรื่อง</button>`}
          </div>
        </div>`;
      }).join('') : `<div class="empty">ไม่มีรายการแจ้งปัญหา</div>`}
    </div>
  `;
}

async function replyTicket(id, status = 'answered') {
  try {
    await api(`/admin/tickets/${id}/reply`, {
      method: 'POST',
      body: { reply: $('tkReply_' + id).value, status }
    });
    S.adminTickets = await api('/admin/tickets');
    showMsg('ok', status === 'closed' ? 'ปิดเรื่องเรียบร้อย' : status === 'open' ? 'เปิดเรื่องอีกครั้งแล้ว' : 'บันทึกการตอบกลับเรียบร้อย');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

// --- 5. Admin: ตั้งค่า API ตรวจสลิป & ตั้งค่าเว็บ ---
function adminSlipApiTab() {
  const st = S.adminSettings || S.site;
  return slipStatusHtml(st) + `
    <div class="section-card">
      <h3>🔌 ตั้งค่า API ตรวจสลิปอัตโนมัติ (External Slip Verify API)</h3>
      <label>โหมดการตรวจสอบสลิป</label>
      <select id="stSlipMode">
        <option value="manual" ${(st.slip_mode || 'manual') === 'manual' ? 'selected' : ''}>ตรวจมือโดยแอดมิน (Manual)</option>
        <option value="external" ${st.slip_mode === 'external' ? 'selected' : ''}>เชื่อมต่อ External API ตรวจสลิปอัตโนมัติ</option>
      </select>

      <label>ผู้ให้บริการตรวจสลิป</label>
      <select id="stSlipProvider">
        <option value="generic" ${(st.slip_provider || 'generic') === 'generic' ? 'selected' : ''}>กำหนดเอง (ส่ง JSON {proof, amount})</option>
        <option value="easyslip" ${st.slip_provider === 'easyslip' ? 'selected' : ''}>EasySlip (ปล่อย URL ว่างได้)</option>
        <option value="slipok" ${st.slip_provider === 'slipok' ? 'selected' : ''}>SlipOK (URL: https://api.slipok.com/api/line/apikey/รหัสสาขา)</option>
      </select>

      <label>Slip Verify API Endpoint URL</label>
      <input id="stSlipUrl" value="${esc(st.slip_verify_url || '')}" placeholder="EasySlip เว้นว่างได้ / SlipOK ใส่ URL ที่มีรหัสสาขา">

      <label>API Key / Bearer Token ${st.has_slip_api_key ? '(บันทึกคีย์ไว้แล้ว กรอกใหม่หากต้องการเปลี่ยน)' : ''}</label>
      <input id="stSlipKey" type="password" placeholder="ใส่ API Key ของผู้ให้บริการตรวจสลิป">

      <label>การอนุมัติยอดเงินอัตโนมัติ</label>
      <select id="stSlipAuto">
        <option value="true" ${String(st.slip_auto_approve) === 'true' ? 'selected' : ''}>อนุมัติเครดิตทันทีเมื่อ API ตรวจผ่าน (Auto-Approve)</option>
        <option value="false" ${String(st.slip_auto_approve) !== 'true' ? 'selected' : ''}>ตรวจผ่าน API แต่รอแอดมินกดอนุมัติ</option>
      </select>

      <h3 style="margin-top:22px">🏦 ตรวจบัญชีผู้รับในสลิป</h3>
      <div class="hint" style="margin-top:0">กันสลิปที่โอนเข้าบัญชีอื่นแต่ยอดตรง ถ้าไม่ตรง ระบบจะไม่อนุมัติอัตโนมัติ (รอแอดมินดู พร้อมหมายเหตุสีเตือน)</div>
      <label>การตรวจบัญชีผู้รับ</label>
      <select id="stSlipRcv">
        <option value="true" ${String(st.slip_check_receiver ?? 'true') !== 'false' ? 'selected' : ''}>เปิด — ต้องโอนเข้าบัญชีร้านเท่านั้น (แนะนำ)</option>
        <option value="false" ${String(st.slip_check_receiver) === 'false' ? 'selected' : ''}>ปิด — เช็กแค่ยอดเงิน</option>
      </select>
      <label>เลขบัญชี / พร้อมเพย์ของร้าน (หลายบัญชีให้ขึ้นบรรทัดใหม่; เว้นว่าง = ใช้เลขบัญชีจากหน้าตั้งค่าเว็บ)</label>
      <textarea id="stSlipRcvAcc" rows="2" placeholder="เช่น 123-4-56789-0">${esc(st.slip_receiver_acc || '')}</textarea>
      <label>ชื่อผู้รับ (ไม่บังคับ แต่แนะนำ — ใส่ชื่อหรือนามสกุลบางส่วน เช่น สมชาย; หลายชื่อคั่นด้วย , )</label>
      <input id="stSlipRcvName" value="${esc(st.slip_receiver_name || '')}" placeholder="สลิปปิดเลขบัญชีบางหลัก การใส่ชื่อช่วยให้แม่นขึ้น">

      <button class="btn" style="margin-top:16px;width:100%" id="btnSlipSave" onclick="saveSlipApiSettings()">💾 บันทึกการตั้งค่า API</button>
      ${S.slipSavedAt ? `<div class="msg ok" style="margin-top:10px">✅ บันทึกแล้ว เมื่อ ${esc(S.slipSavedAt)}</div>` : ''}
    </div>
    ${slipRecentHtml()}
  `;
}

// สรุปว่าตอนนี้ระบบจะตรวจสลิปและอนุมัติอัตโนมัติได้หรือไม่
function slipStatusHtml(st) {
  const mode = st.slip_mode || 'manual';
  const prov = String(st.slip_provider || 'generic').toLowerCase();
  const url = String(st.slip_verify_url || '').trim();
  const urlOk = prov === 'easyslip' ? true : !!url;
  const keyOk = !!st.has_slip_api_key;
  const autoOn = String(st.slip_auto_approve).toLowerCase() === 'true';
  const rcvOn = String(st.slip_check_receiver ?? 'true').toLowerCase() !== 'false';
  const rcvOk = !rcvOn || !!String(st.slip_receiver_acc || '').trim() || !!String(st.slip_receiver_name || '').trim() || !!String(st.bankNo || '').replace(/\D/g, '');
  const rows = [
    [mode === 'external', 'โหมดตรวจสลิป', mode === 'external' ? 'เชื่อมต่อ API อัตโนมัติ' : 'ตรวจมือ (ยังไม่เปิดตรวจอัตโนมัติ)'],
    [urlOk, 'Endpoint URL', prov === 'easyslip' ? 'EasySlip (ใช้ URL มาตรฐาน)' : (url ? 'ตั้งแล้ว' : 'ยังไม่ได้ใส่ URL')],
    [keyOk, 'API Key', keyOk ? 'บันทึกแล้ว' : 'ยังไม่ได้บันทึกคีย์'],
    [autoOn, 'อนุมัติเครดิตอัตโนมัติ', autoOn ? 'เปิด' : 'ปิด (ตรวจผ่านแล้วต้องรอแอดมินกดอนุมัติ)'],
    [rcvOk, 'บัญชีผู้รับ', !rcvOn ? 'ปิดการตรวจ (เช็กแค่ยอดเงิน)' : (rcvOk ? 'ตั้งแล้ว' : 'ยังไม่ได้ตั้งเลขบัญชี/ชื่อผู้รับ — สลิปจะไม่ผ่านอัตโนมัติ')]
  ];
  const ready = rows.every(r => r[0]);
  return `
    <div class="section-card">
      <h3>${ready ? '✅' : '⚠️'} สถานะระบบตรวจสลิป</h3>
      <div class="msg ${ready ? 'ok' : 'bad'}" style="margin:8px 0">${ready
        ? 'พร้อมใช้งาน — สลิปที่ API ตรวจผ่านและตรงเงื่อนไข จะเติมเครดิตให้ลูกค้าอัตโนมัติทันที'
        : 'ยังอนุมัติอัตโนมัติไม่ได้ — สลิปจะเข้าสถานะ “รอตรวจสอบ” ให้แอดมินกดอนุมัติเอง (ดูข้อที่ ❌ ด้านล่าง)'}</div>
      ${rows.map(r => `<div style="display:flex;gap:8px;padding:5px 0;border-bottom:1px dashed var(--line);font-size:13.5px"><span>${r[0] ? '✅' : '❌'}</span><b style="min-width:128px">${r[1]}</b><span style="color:var(--sub)">${esc(r[2])}</span></div>`).join('')}
    </div>`;
}

// รายการเติมเงินล่าสุด ไว้ดูว่าสลิปถูกอนุมัติอัตโนมัติหรือไม่
function slipRecentHtml() {
  const rows = S.slipRecent || [];
  return `
    <div class="section-card">
      <h3>🧾 รายการเติมเงินล่าสุด 10 รายการ</h3>
      <div class="hint" style="margin-top:0">ใช้เช็กว่าสลิปที่ลูกค้าส่งมา ระบบตรวจและอนุมัติอัตโนมัติหรือไม่</div>
      ${rows.length ? rows.map(t => `
        <div style="border:1px solid var(--line);border-radius:12px;padding:10px 12px;margin-top:8px">
          <div style="display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;align-items:center">
            <span><b>#${t.id}</b> @${esc(t.username)} • ${TOPUP_METHOD[t.method] || esc(t.method)} • <b>${money(t.amount)} ฿</b></span>
            <span><span class="tag ${topupStClass(t.status)}">${topupStTh(t.status)}</span>${t.status === 'approved' ? ` <span class="tag">${t.verified_by === 'auto' ? '🤖 อัตโนมัติ' : '👤 แอดมิน'}</span>` : ''}</span>
          </div>
          <div class="hint">${fdt(t.created_at)}${t.verify_note ? ` • ${esc(t.verify_note)}` : ''}</div>
        </div>`).join('') : '<div class="empty">ยังไม่มีรายการเติมเงิน</div>'}
    </div>`;
}

async function saveSlipApiSettings() {
  const btn = $('btnSlipSave');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ กำลังบันทึก...'; }
  try {
    await api('/admin/site', {
      method: 'PUT',
      body: {
        slip_mode: $('stSlipMode').value,
        slip_provider: $('stSlipProvider').value,
        slip_verify_url: $('stSlipUrl').value,
        slip_api_key: $('stSlipKey').value,
        slip_auto_approve: $('stSlipAuto').value,
        slip_check_receiver: $('stSlipRcv').value,
        slip_receiver_acc: $('stSlipRcvAcc').value,
        slip_receiver_name: $('stSlipRcvName').value
      }
    });
    S.adminSettings = await api('/admin/settings');
    S.slipRecent = await api('/admin/topups-recent').catch(() => S.slipRecent || []);
    await refreshAll();
    S.slipSavedAt = new Date().toLocaleString('th-TH', { dateStyle: 'short', timeStyle: 'medium' });
    showMsg('ok', '✅ บันทึกการตั้งค่า API ตรวจสลิปแล้ว');
    setTimeout(() => { const el = document.querySelector('#btnSlipSave + .msg'); if (el) el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, 50);
  } catch (e) {
    S.slipSavedAt = '';
    if (btn) { btn.disabled = false; btn.textContent = '💾 บันทึกการตั้งค่า API'; }
    showMsg('bad', 'บันทึกไม่สำเร็จ: ' + e.message);
  }
}

function adminSiteTab() {
  const s = S.adminSettings || S.site;
  return `
    <div class="section-card">
      <h3>⚙️ ตั้งค่าเว็บไซต์ รูปภาพ และเงื่อนไขการเติมเงิน</h3>
      <div class="row2">
        <div>
          <label>ชื่อเว็บไซต์ / ร้านค้า</label>
          <input id="stName" value="${esc(s.name || '')}">
        </div>
        <div>
          <label>ลิงก์ / ไอดีติดต่อแอดมิน (LINE / Telegram)</label>
          <input id="stLine" value="${esc(s.line || '')}" placeholder="@wselx">
        </div>
      </div>

      <label>หัวข้อหลักหน้าแรก (Hero Title)</label>
      <textarea id="stTitle" rows="2">${esc(s.title || '')}</textarea>

      <label>คำอธิบายรองหน้าแรก</label>
      <input id="stSub" value="${esc(s.sub || '')}">

      <div class="row3">
        <div>
          <label>เติมเงินขั้นต่ำ (บาท)</label>
          <input id="stMinTopup" type="number" min="1" value="${esc(s.min_topup_amount || '20')}">
        </div>
        <div>
          <label>ยอดขั้นต่ำรับโบนัส (บาท)</label>
          <input id="stBonusMin" type="number" min="0" value="${esc(s.bonus_min_amount || '100')}">
        </div>
        <div>
          <label>โบนัสเติมเงิน (%)</label>
          <input id="stBonusPct" type="number" min="0" max="100" value="${esc(s.bonus_percent || '5')}">
        </div>
      </div>

      <div class="row3">
        <div>
          <label>ชื่อธนาคาร / พร้อมเพย์</label>
          <input id="stBankName" value="${esc(s.bankName || '')}" placeholder="กสิกรไทย / PromptPay">
        </div>
        <div>
          <label>เลขที่บัญชี / เบอร์พร้อมเพย์</label>
          <input id="stBankNo" value="${esc(s.bankNo || '')}">
        </div>
        <div>
          <label>ชื่อบัญชีผู้รับโอน</label>
          <input id="stBankHolder" value="${esc(s.bankHolder || '')}">
        </div>
      </div>

      <label>เงื่อนไขการใช้บริการและนโยบายคืนเงิน (แสดงก่อนกดชำระเงิน — เว้นว่าง = ใช้ข้อความตั้งต้น)</label>
      <textarea id="stTerms" rows="5" placeholder="เช่น ไม่คืนเงินหากใช้งานเกิน 24 ชม. / คืนตามวันที่เหลือเมื่อเซิร์ฟเวอร์มีปัญหา">${esc(s.terms_text || '')}</textarea>
      <label>NetMod — ก้อนตั้งค่าเข้ารหัส (payload / SNI / proxy)</label>
      <textarea id="stNetmod" rows="4" spellcheck="false" placeholder="วางลิงก์ที่ Export จาก NetMod ทั้งบรรทัด หรือวางเฉพาะส่วนหลังเครื่องหมาย ? — ระบบจะสลับ user/pass/host ของลูกค้าแต่ละคนให้เอง เว้นว่าง = ใช้ลิงก์ ssh:// แบบพื้นฐาน">${esc(s.netmod_blob || '')}</textarea>
      <div class="row2">
        <div>
          <label>โบนัสแนะนำเพื่อน (บาท)</label>
          <input id="stRefReward" type="number" min="0" value="${esc(s.referral_reward || '10')}">
        </div>
        <div>
          <label>วันที่เปิดให้บริการ (แสดงหน้าแรก)</label>
          <input id="stOpen" value="${esc(s.open || '2026-07-01')}">
        </div>
      </div>

      <div class="row3">
        <div>
          <label>โลโก้เว็บไซต์</label>
          <input id="stLogoFile" type="file" accept="image/*">
          ${s.logo ? `<img class="img-prev" src="${esc(s.logo)}">` : ''}
        </div>
        <div>
          <label>แบนเนอร์หลักหน้าแรก</label>
          <input id="stHeroFile" type="file" accept="image/*">
          ${s.hero ? `<img class="img-prev" src="${esc(s.hero)}">` : ''}
        </div>
        <div>
          <label>แบนเนอร์โปรโมชั่นหน้าแรก</label>
          <input id="stPromoFile" type="file" accept="image/*">
          ${s.promo ? `<img class="img-prev" src="${esc(s.promo)}">` : ''}
        </div>
      </div>

      <h3 style="margin-top:22px">🛡️ Cloudflare Turnstile (กันบอทตอนสมัครสมาชิก)</h3>
      <div class="hint" style="margin-top:0">สร้างที่ dash.cloudflare.com → Turnstile → Add widget (ใส่โดเมนร้าน) แล้วนำ Site Key / Secret Key มาใส่ • เว้นว่างทั้งคู่ = ปิดใช้งาน</div>
      <div class="row2">
        <div>
          <label>Site Key (สาธารณะ)</label>
          <input id="stTsSite" value="${esc(s.turnstile_site_key || '')}" placeholder="0x4AAAAAAA...">
        </div>
        <div>
          <label>Secret Key ${s.has_turnstile_secret ? '(บันทึกไว้แล้ว กรอกใหม่หากต้องการเปลี่ยน)' : ''}</label>
          <input id="stTsSecret" type="password" placeholder="0x4AAAAAAA...">
        </div>
      </div>
      ${s.has_turnstile_secret ? `<label style="display:flex;gap:8px;align-items:center;margin-top:8px"><input type="checkbox" id="stTsClear" style="width:auto"> ปิดใช้งาน Turnstile (ลบคีย์ทั้งสอง)</label>` : ''}

      <h3 style="margin-top:22px">🤖 แจ้งเตือน Telegram</h3>
      <div class="hint" style="margin-top:0">สร้างบอทที่ @BotFather เพื่อรับ Bot Token → ทักบอทหนึ่งครั้ง (หรือเพิ่มบอทเข้ากลุ่ม) แล้วกด "ค้นหา Chat ID" • แนะนำให้ใช้บอทแยกจากบอทของ 3x-ui • ปุ่มในส่วนนี้บันทึกแยกจากปุ่มบันทึกด้านล่าง และมีผลทันทีไม่ต้องรีสตาร์ต${(s.telegram || {}).source === 'env' ? ' • ตอนนี้ใช้ค่าจากไฟล์ .env — ถ้าบันทึกที่นี่ ค่าที่นี่จะถูกใช้แทน' : ''}</div>
      <div class="row2">
        <div>
          <label>Bot Token ${(s.telegram || {}).has_token ? `(ตั้งไว้แล้ว: ${esc(s.telegram.token_hint)} — กรอกใหม่หากต้องการเปลี่ยน)` : ''}</label>
          <input id="tgToken" type="password" autocomplete="off" placeholder="123456789:AAxxxxxxxx...">
        </div>
        <div>
          <label>Chat ID (ผู้รับ / กลุ่ม / ช่อง)</label>
          <input id="tgChat" value="${esc((s.telegram || {}).chat_id || '')}" placeholder="เช่น 123456789 หรือ -1001234567890">
        </div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px">
        <button class="btn ghost sm" type="button" onclick="tgDetect()">🔎 ค้นหา Chat ID</button>
        <button class="btn ghost sm" type="button" onclick="tgTest()">📨 ส่งข้อความทดสอบ</button>
      </div>
      <div id="tgDetectOut" class="hint"></div>
      <label style="display:flex;gap:8px;align-items:center;margin-top:12px"><input type="checkbox" id="tgAll" style="width:auto" ${(s.telegram || {}).notify_all !== false ? 'checked' : ''}> แจ้งเตือนทุกเหตุการณ์ (สมัคร / ซื้อ / ต่ออายุ / เติมเงิน / แอดมินแก้ไข ฯลฯ)</label>
      <div class="hint" style="margin-top:4px">ปิดช่องนี้ = ไม่ส่งแจ้งเตือนเหตุการณ์ทั่วไป แต่ยังส่งแจ้งเตือนสำคัญเสมอ (คำขอเติมเงิน / ขอคืนเงิน / แจ้งปัญหา / เซิร์ฟเวอร์ล่ม / แพ็กเกจใกล้หมดอายุ)</div>
      <details style="margin-top:8px">
        <summary style="cursor:pointer">เลือกเหตุการณ์ที่ต้องการรับ (ติ๊กออก = ไม่ส่ง)</summary>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:6px 14px;margin-top:8px">
          ${((s.telegram || {}).events || []).map(e => `<label style="display:flex;gap:8px;align-items:center;font-weight:400"><input type="checkbox" class="tgEv" data-ev="${esc(e.key)}" style="width:auto" ${((s.telegram || {}).muted || []).includes(e.key) ? '' : 'checked'}> ${esc(e.label)}</label>`).join('')}
        </div>
      </details>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
        <button class="btn" type="button" onclick="saveTelegram()">💾 บันทึกการตั้งค่า Telegram</button>
        ${(s.telegram || {}).source === 'db' ? `<button class="btn danger" type="button" onclick="clearTelegram()">ล้างค่าที่ตั้งในหลังบ้าน</button>` : ''}
      </div>

      <button class="btn" style="margin-top:18px" onclick="saveSiteSettings()">💾 บันทึกการตั้งค่าทั้งหมด</button>
    </div>
  `;
}

async function saveSiteSettings() {
  try {
    const body = {
      name: $('stName').value,
      line: $('stLine').value,
      title: $('stTitle').value,
      sub: $('stSub').value,
      min_topup_amount: $('stMinTopup').value,
      bonus_min_amount: $('stBonusMin').value,
      bonus_percent: $('stBonusPct').value,
      bankName: $('stBankName').value,
      bankNo: $('stBankNo').value,
      bankHolder: $('stBankHolder').value,
      referral_reward: $('stRefReward').value,
      terms_text: $('stTerms').value,
      netmod_blob: $('stNetmod').value.trim(),
      open: $('stOpen').value,
      turnstile_site_key: $('stTsSite').value.trim(),
      turnstile_secret: $('stTsSecret').value,
      turnstile_clear: !!($('stTsClear') && $('stTsClear').checked)
    };
    const fLogo = $('stLogoFile').files[0];
    const fHero = $('stHeroFile').files[0];
    const fPromo = $('stPromoFile').files[0];
    if (fLogo) body.logo = await readImg(fLogo, 300);
    if (fHero) body.hero = await readImg(fHero, 1200);
    if (fPromo) body.promo = await readImg(fPromo, 1200);

    await api('/admin/site', { method: 'PUT', body });
    S.adminSettings = await api('/admin/settings');
    await refreshAll();
    showMsg('ok', 'บันทึกการตั้งค่าเว็บไซต์เรียบร้อยแล้ว');
  } catch (e) {
    showMsg('bad', e.message);
  }
}


// ---------- ADMIN: ตั้งค่า Telegram ----------
async function saveTelegram() {
  try {
    const muted = [...document.querySelectorAll('.tgEv')].filter(x => !x.checked).map(x => x.dataset.ev);
    const body = { chat_id: $('tgChat').value.trim(), notify_all: !!$('tgAll').checked, muted };
    const tok = $('tgToken').value.trim();
    if (tok) body.token = tok;
    await api('/admin/telegram', { method: 'PUT', body });
    S.adminSettings = await api('/admin/settings');
    showMsg('ok', 'บันทึกการตั้งค่า Telegram แล้ว — มีผลทันที');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

async function clearTelegram() {
  if (!confirm('ล้างค่า Telegram ที่ตั้งในหลังบ้านทั้งหมด? (ถ้ามีค่าใน .env ระบบจะกลับไปใช้ค่านั้น)')) return;
  try {
    await api('/admin/telegram', { method: 'PUT', body: { clear: true } });
    S.adminSettings = await api('/admin/settings');
    showMsg('ok', 'ล้างค่า Telegram ที่ตั้งในหลังบ้านแล้ว');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

async function tgTest() {
  try {
    const body = { chat_id: $('tgChat').value.trim() };
    const tok = $('tgToken').value.trim();
    if (tok) body.token = tok;
    const r = await api('/admin/telegram/test', { method: 'POST', body });
    toast('ok', 'ส่งข้อความทดสอบแล้ว' + (r.bot ? ' (บอท ' + r.bot + ')' : '') + ' — ตรวจใน Telegram');
  } catch (e) {
    toast('bad', e.message);
  }
}

async function tgDetect() {
  const out = $('tgDetectOut');
  try {
    const body = {};
    const tok = $('tgToken').value.trim();
    if (tok) body.token = tok;
    out.textContent = 'กำลังค้นหา...';
    const r = await api('/admin/telegram/detect', { method: 'POST', body });
    if (!r.chats.length) {
      out.textContent = 'ยังไม่พบแชท — ทักบอทหนึ่งข้อความ (หรือเพิ่มบอทเข้ากลุ่มแล้วพิมพ์ข้อความ) แล้วกดค้นหาอีกครั้ง';
      return;
    }
    out.innerHTML = 'พบแชท (กดเพื่อใช้): ' + r.chats.map(c =>
      `<button class="btn ghost sm" type="button" style="margin:2px 4px 2px 0" data-id="${esc(c.id)}" onclick="$('tgChat').value=this.dataset.id">${esc(c.name || c.type)} · ${esc(c.id)}</button>`).join('');
  } catch (e) {
    out.textContent = '';
    toast('bad', e.message);
  }
}


// =====================================================
// ADMIN: รูปแบบเว็บไซต์ (ธีม / ฟอนต์ / เลย์เอาต์ / เอฟเฟกต์)
// =====================================================
const LOOK_DEFAULT = {
  ui_preset: 'gold', ui_mode: 'auto', ui_font: 'plex', ui_disp: 'serif', ui_radius: 'classic',
  ui_width: 'normal', ui_btn: 'solid', ui_hero: 'split', ui_density: 'comfort', ui_cols: 'm',
  ui_hover: 'lift', ui_bg: 'glow', ui_motion: 'on', ui_stats: '1', ui_perks: '1',
  ann_on: '0', ann_text: '', ann_tone: 'gold', footer_text: '', ui_nav: 'underline', ui_dock: 'float', ui_icon: 'line', ui_shape: 'default', ui_fall: 'm', ff_body: 'inherit', fs_body: 'm', fw_body: '', ff_head: 'inherit', fs_head: 'm', fw_head: '', ff_btn: 'inherit', fs_btn: 'm', fw_btn: '', ff_nav: 'inherit', fs_nav: 'm', fw_nav: '', ff_tag: 'inherit', fs_tag: 'm', fw_tag: '', ff_input: 'inherit', fs_input: 'm', fw_input: '', ff_num: 'inherit', fs_num: 'm', fw_num: '', ff_table: 'inherit', fs_table: 'm', fw_table: '', ff_code: 'inherit', fs_code: 'm', fw_code: '', ff_ord: 'inherit', fs_ord: 'm', fw_ord: ''
};
const LOOK_FONTS = {
  plex:   ["'IBM Plex Sans Thai'", 'IBM+Plex+Sans+Thai:wght@400;500;600;700'],
  prompt: ["'Prompt'", 'Prompt:wght@400;500;600;700'],
  kanit:  ["'Kanit'", 'Kanit:wght@400;500;600;700'],
  sarabun:["'Sarabun'", 'Sarabun:wght@400;500;600;700'],
  noto:   ["'Noto Sans Thai'", 'Noto+Sans+Thai:wght@400;500;600;700']
};
const LOOK_LIB = {
  plex: ["'IBM Plex Sans Thai'", "IBM+Plex+Sans+Thai:wght@400;500;600;700;800"],
  prompt: ["'Prompt'", "Prompt:wght@400;500;600;700;800"],
  kanit: ["'Kanit'", "Kanit:wght@400;500;600;700;800"],
  sarabun: ["'Sarabun'", "Sarabun:wght@400;500;600;700;800"],
  noto: ["'Noto Sans Thai'", "Noto+Sans+Thai:wght@400;500;600;700;800"],
  mitr: ["'Mitr'", "Mitr:wght@400;500;600;700"],
  athiti: ["'Athiti'", "Athiti:wght@400;500;600;700"],
  niramit: ["'Niramit'", "Niramit:wght@400;500;600;700"],
  krub: ["'Krub'", "Krub:wght@400;500;600;700"],
  bai: ["'Bai Jamjuree'", "Bai+Jamjuree:wght@400;500;600;700"],
  chakra: ["'Chakra Petch'", "Chakra+Petch:wght@400;500;600;700"],
  k2d: ["'K2D'", "K2D:wght@400;500;600;700;800"],
  mali: ["'Mali'", "Mali:wght@400;500;600;700"],
  pridi: ["'Pridi'", "Pridi:wght@400;500;600;700"],
  trirong: ["'Trirong'", "Trirong:wght@400;500;600;700"],
  serif: ["'Noto Serif Thai'", "Noto+Serif+Thai:wght@400;600;700;800"],
  mono: ["'JetBrains Mono'", "JetBrains+Mono:wght@400;500;700"],
  system: ["system-ui", null]
};
const LOOK_LIB_NAMES = {plex:"IBM Plex Sans Thai", prompt:"Prompt", kanit:"Kanit", sarabun:"Sarabun", noto:"Noto Sans Thai", mitr:"Mitr", athiti:"Athiti", niramit:"Niramit", krub:"Krub", bai:"Bai Jamjuree", chakra:"Chakra Petch", k2d:"K2D", mali:"Mali", pridi:"Pridi", trirong:"Trirong", serif:"Noto Serif Thai", mono:"JetBrains Mono", system:"system-ui"};
const LOOK_ELS = [["body", "เนื้อหาทั่วไป", "ข้อความทั้งเว็บ"], ["head", "หัวข้อ", "หัวข้อใหญ่ ชื่อร้าน"], ["btn", "ปุ่ม", "ปุ่มทุกปุ่ม"], ["nav", "เมนู / แท็บล่าง", "เมนูบนและแถบล่างมือถือ"], ["tag", "ป้าย / แท็ก", "AIS, SSH, สถานะ"], ["input", "ช่องกรอก", "ช่องพิมพ์ ตัวเลือก"], ["num", "ตัวเลข / ราคา", "ราคา เครดิต สถิติ"], ["table", "ตาราง", "หัวและเนื้อตาราง"], ["code", "ข้อมูลบัญชี / โค้ด", "ลิงก์ บัญชี SSH"], ["ord", "การ์ดประวัติ", "รายการซื้อ & ไฟล์"]];
const LOOK_SIZES = [["xs", "เล็กมาก", 0.85], ["s", "เล็ก", 0.92], ["m", "ปกติ", 1], ["l", "ใหญ่", 1.1], ["xl", "ใหญ่มาก", 1.22]];
const LOOK_WEIGHTS = [["", "ตามเดิม"], ["400", "บาง"], ["500", "กลาง"], ["600", "กึ่งหนา"], ["700", "หนา"], ["800", "หนามาก"]];
const LOOK_MONO = "ui-monospace,SFMono-Regular,Menlo,monospace";
const LOOK_DISP = {
  serif: ["'Noto Serif Thai'", 'Noto+Serif+Thai:wght@600;700;800'],
  sans:  [null, null],
  round: ["'Mitr'", 'Mitr:wght@500;600'],
  bold:  ["'Kanit'", 'Kanit:wght@600;700']
};
const LOOK_PRESETS = [
  ['gold',     'ทองหรู',        '#d9b45a', '#16140f'],
  ['platinum', 'แพลตินัม',      '#c9ced8', '#14161b'],
  ['emerald',  'มรกต',          '#3ecf8e', '#0c1512'],
  ['sapphire', 'ไพลิน',         '#5b9dff', '#0b1220'],
  ['rose',     'โรสโกลด์',      '#e8a0a8', '#1a1214'],
  ['amethyst', 'อเมทิสต์',      '#b794f6', '#140f1c']
];
const LOOK_OPTS = {
  ui_mode:    [['auto', 'ตามอุปกรณ์'], ['dark', 'มืด'], ['light', 'สว่าง']],
  ui_font:    [['plex', 'IBM Plex'], ['prompt', 'Prompt'], ['kanit', 'Kanit'], ['sarabun', 'Sarabun'], ['noto', 'Noto Sans']],
  ui_disp:    [['serif', 'เซอริฟหรู'], ['sans', 'เหมือนเนื้อหา'], ['round', 'โค้งมน'], ['bold', 'หนาเท่']],
  ui_radius:  [['sharp', 'เหลี่ยม'], ['classic', 'มาตรฐาน'], ['soft', 'โค้งนุ่ม']],
  ui_width:   [['narrow', 'แคบ'], ['normal', 'ปกติ'], ['wide', 'กว้าง']],
  ui_btn:     [['solid', 'ไล่สีทึบ'], ['outline', 'ขอบบาง'], ['pill', 'แคปซูล'], ['xxtl', 'แบบ XXTL']],
  ui_nav:     [['underline', 'ขีดเส้นใต้'], ['xxtl', 'แบบ XXTL (แถบทอง)']],
  ui_dock:    [['float', 'ลอยกระจก'], ['bar', 'แถบเต็มขอบ'], ['icons', 'ไอคอนล้วน']],
  ui_icon:    [['line', 'เส้นปกติ'], ['thin', 'เส้นบาง'], ['bold', 'เส้นหนา'], ['duo', 'สองโทน'], ['emoji', 'อีโมจิสี']],
  ui_shape:   [['default', 'มาตรฐาน'], ['pill', 'แคปซูล'], ['soft', 'โค้งมาก'], ['square', 'เหลี่ยม']],
  ui_fall:    [['xs', 'เล็กมาก'], ['s', 'เล็ก'], ['m', 'ปกติ'], ['l', 'ใหญ่'], ['xl', 'ใหญ่มาก']],
  ui_hero:    [['split', 'ข้อความ + รูป'], ['center', 'กึ่งกลาง'], ['compact', 'กะทัดรัด']],
  ui_density: [['compact', 'แน่น'], ['comfort', 'พอดี'], ['spacious', 'โปร่ง']],
  ui_cols:    [['s', 'การ์ดเล็ก'], ['m', 'ปานกลาง'], ['l', 'การ์ดใหญ่']],
  ui_hover:   [['lift', 'ลอยขึ้น'], ['glow', 'เรืองแสง'], ['none', 'ไม่มี']],
  ui_bg:      [['glow', 'แสงเรือง'], ['dots', 'จุดตาราง'], ['plain', 'พื้นเรียบ']],
  ui_motion:  [['on', 'เปิด'], ['off', 'ปิด (ลดการเคลื่อนไหว)']],
  ui_stats:   [['1', 'แสดง'], ['0', 'ซ่อน']],
  ui_perks:   [['1', 'แสดง'], ['0', 'ซ่อน']],
  ann_on:     [['0', 'ปิด'], ['1', 'เปิด']],
  ann_tone:   [['gold', 'ทอง'], ['ok', 'เขียว'], ['bad', 'แดง'], ['info', 'ฟ้า']]
};

function lookSrc() {
  const base = { ...LOOK_DEFAULT, ...(S.site || {}) };
  if (S.view === 'admin' && S.atab === 'look' && S.lookDraft) return { ...base, ...S.lookDraft };
  return base;
}

function applyLook(v) {
  const r = document.documentElement;
  const map = {
    preset: v.ui_preset, font: v.ui_font, disp: v.ui_disp, radius: v.ui_radius, width: v.ui_width,
    btn: v.ui_btn, hero: v.ui_hero, density: v.ui_density, cols: v.ui_cols, hover: v.ui_hover,
    bg: v.ui_bg, motion: v.ui_motion, stats: v.ui_stats, perks: v.ui_perks, nav: v.ui_nav, dock: v.ui_dock, icon: v.ui_icon, shape: v.ui_shape
  };
  for (const k in map) r.dataset[k] = map[k] || LOOK_DEFAULT['ui_' + k];
  const f = LOOK_FONTS[v.ui_font] || LOOK_FONTS.plex;
  const d = LOOK_DISP[v.ui_disp] || LOOK_DISP.serif;
  r.style.setProperty('--font-th', f[0] + ",'Noto Sans Thai',system-ui,sans-serif");
  r.style.setProperty('--font-disp', d[0] ? d[0] + ',' + f[0] + ',serif' : f[0] + ",'Noto Sans Thai',sans-serif");
  const sz = k => (LOOK_SIZES.find(x => x[0] === k) || LOOK_SIZES[2])[2];
  r.style.setProperty('--fs-all', sz(v.ui_fall));
  const used = [];
  for (const [e] of LOOK_ELS) {
    const fam = v['ff_' + e] || 'inherit', lib = LOOK_LIB[fam];
    if (lib) { r.style.setProperty('--ff-' + e, fam === 'system' ? 'system-ui,sans-serif' : lib[0] + ',' + (fam === 'mono' ? LOOK_MONO : "'Noto Sans Thai',sans-serif")); if (lib[1]) used.push(lib[1]); }
    else r.style.removeProperty('--ff-' + e);
    r.style.setProperty('--fs-' + e, sz(v['fs_' + e]));
    const w = v['fw_' + e];
    if (w) r.style.setProperty('--fw-' + e, w); else r.style.removeProperty('--fw-' + e);
  }
  if (LOOK_LIB[v.ff_head]) r.style.setProperty('--font-disp', r.style.getPropertyValue('--ff-head'));
  const need = [f[1], d[1], ...used].filter(Boolean);
  let l = document.getElementById('lookFonts');
  if (!l) { l = document.createElement('link'); l.id = 'lookFonts'; l.rel = 'stylesheet'; document.head.appendChild(l); }
  const href = 'https://fonts.googleapis.com/css2?' + need.map(x => 'family=' + x).join('&') + '&display=swap';
  if (l.getAttribute('href') !== href) l.setAttribute('href', href);
  if (!(S.view === 'admin' && S.atab === 'look')) {
    const stored = (() => { try { return localStorage.getItem(THEME_KEY); } catch { return null; } })();
    if (!stored && (v.ui_mode === 'dark' || v.ui_mode === 'light')) applyTheme(v.ui_mode);
  } else if (v.ui_mode === 'dark' || v.ui_mode === 'light') {
    applyTheme(v.ui_mode);
  }
}

function annBar() {
  const v = lookSrc();
  const sale = '';
  if (v.ann_on !== '1' || !String(v.ann_text || '').trim()) return sale;
  return sale + `<div class="ann ann-${esc(v.ann_tone || 'gold')}" role="status">${esc(v.ann_text)}</div>`;
}

function lookSet(k, val) {
  S.lookDraft = { ...(S.lookDraft || {}), [k]: val };
  render();
}

async function saveLook() {
  try {
    const body = {};
    const v = lookSrc();
    for (const k in LOOK_DEFAULT) body[k] = String(v[k] ?? LOOK_DEFAULT[k]);
    await api('/admin/site', { method: 'PUT', body });
    S.lookDraft = null;
    S.adminSettings = await api('/admin/settings');
    await refreshAll();
    showMsg('ok', 'บันทึกรูปแบบเว็บไซต์เรียบร้อยแล้ว');
  } catch (e) {
    showMsg('bad', e.message);
  }
}

function resetLook() {
  S.lookDraft = { ...LOOK_DEFAULT };
  render();
}

function discardLook() {
  S.lookDraft = null;
  render();
}

function adminLookTab() {
  const v = lookSrc();
  const dirty = !!S.lookDraft && Object.keys(S.lookDraft).some(k => String(S.lookDraft[k]) !== String((S.site || {})[k] ?? LOOK_DEFAULT[k]));
  const seg = (k, extra = '') => `
    <div class="look-seg ${extra}" role="group">
      ${LOOK_OPTS[k].map(([val, label]) => `
        <button type="button" aria-pressed="${String(v[k]) === val}" onclick="lookSet('${k}','${val}')">${label}</button>`).join('')}
    </div>`;
  const row = (title, hint, inner) => `
    <div class="look-row"><div class="look-lbl"><b>${title}</b><small>${hint}</small></div>${inner}</div>`;
  // ตัวเลือกแบบการ์ดพร้อมภาพตัวอย่าง (เหมือนกล่อง "รูปแบบปุ่มเมนูหลังบ้าน")
  const pick = (k, prev, descs = {}) => `
    <div class="adm-style-row look-pick" style="grid-template-columns:repeat(auto-fit,minmax(${LOOK_OPTS[k].length > 4 ? 92 : 110}px,1fr))" role="group">
      ${LOOK_OPTS[k].map(([val, label]) => `
        <button type="button" class="adm-style-opt" aria-pressed="${String(v[k]) === val}" onclick="lookSet('${k}','${val}')">
          ${prev(val)}<b>${label}</b>${descs[val] ? `<small>${descs[val]}</small>` : ''}
        </button>`).join('')}
    </div>`;
  const pvDock = val => `<span class="pvd pvd-${val}"><i></i><i class="on"></i><i></i><i></i></span>`;
  const pvShape = val => `<span class="pvs"><span class="pvs-b pvs-${val}">ปุ่ม</span></span>`;
  const pvIcon = val => `<span class="pvi" data-set="${val}">${val === 'emoji' ? '🛍️ 💳 🗂️' : [['store'], ['wallet'], ['receipt']].map(([n]) => admIcon(n)).join('')}</span>`;

  return `
    <div class="section-card">
      <h3>${admIcon('palette')}สีธีมหลัก</h3>
      <div class="look-presets">
        ${LOOK_PRESETS.map(([id, name, c, bg]) => `
          <button type="button" class="look-sw" aria-pressed="${v.ui_preset === id}" onclick="lookSet('ui_preset','${id}')">
            <span class="look-dot" style="--c:${c};--b:${bg}"></span>
            <b>${name}</b>
          </button>`).join('')}
      </div>
      ${row('โหมดเริ่มต้น', 'ใช้กับผู้เยี่ยมชมที่ยังไม่เคยกดสลับโหมดเอง', seg('ui_mode'))}
    </div>

    <div class="section-card">
      <h3>${admIcon('settings')}ตัวอักษรและรูปทรง</h3>
      ${row('ฟอนต์เนื้อหา', 'ใช้กับข้อความ ปุ่ม และตาราง', seg('ui_font'))}
      ${row('ฟอนต์หัวข้อ', 'หัวข้อใหญ่ ราคา และตัวเลขสถิติ', seg('ui_disp'))}
      ${row('ความโค้งมุม', 'การ์ด ปุ่ม ช่องกรอก และหน้าต่างเด้ง', seg('ui_radius'))}
    </div>

    <div class="section-card">
      <h3>${admIcon('settings')}ปุ่มและเมนู</h3>
      ${row('รูปแบบปุ่ม', 'ปุ่มหลักทั่วทั้งเว็บ (แบบ XXTL = ไล่สีทองมุมโค้งเหมือนแดชบอร์ด)', seg('ui_btn'))}
      ${row('รูปแบบเมนู / แท็บล่าง', 'แบบ XXTL = แท็บที่เลือกเป็นแถบทองโปร่งมีขีดทองด้านซ้าย', seg('ui_nav'))}
    </div>

    <div class="section-card">
      <h3>${admIcon('store')}หน้าบ้าน (ฝั่งลูกค้า)</h3>
      <div class="look-lbl" style="margin:0 0 8px"><b>รูปแบบแถบเมนูล่าง</b><small>แสดงบนมือถือ — ลูกค้าทุกคนเห็นเหมือนกัน</small></div>
      ${pick('ui_dock', pvDock, { float: 'แคปซูลทองลอยเหนือเนื้อหา', bar: 'ติดขอบล่างเต็มจอ', icons: 'โชว์ชื่อเฉพาะปุ่มที่เลือก' })}
      <div class="look-lbl" style="margin:18px 0 8px"><b>ชุดไอคอนเมนู</b><small>แพ็กเกจ / เติมเงิน / ประวัติ / ซัพพอร์ต / หลังบ้าน</small></div>
      ${pick('ui_icon', pvIcon)}
      <div class="look-lbl" style="margin:18px 0 8px"><b>รูปทรงปุ่ม</b><small>ใช้กับปุ่มทั่วเว็บ แท็บ และปุ่มในแถบเมนูล่าง</small></div>
      ${pick('ui_shape', pvShape)}
    </div>

    <div class="section-card">
      <h3>${admIcon('settings')}ฟอนต์แยกรายองค์ประกอบ</h3>
      ${row('ขนาดตัวอักษรรวม', 'คูณกับขนาดของทุกองค์ประกอบด้านล่าง', seg('ui_fall'))}
      <div class="fx-list">
        ${LOOK_ELS.map(([e, t, h]) => `
        <div class="fx-row">
          <div class="look-lbl"><b>${t}</b><small>${h}</small></div>
          <div class="fx-ctl">
            <select onchange="lookSet('ff_${e}', this.value)" aria-label="ฟอนต์ ${t}">
              <option value="inherit" ${v['ff_' + e] === 'inherit' ? 'selected' : ''}>ตามค่าหลัก</option>
              ${Object.keys(LOOK_LIB).map(k => `<option value="${k}" ${v['ff_' + e] === k ? 'selected' : ''}>${LOOK_LIB_NAMES[k]}</option>`).join('')}
            </select>
            <select onchange="lookSet('fs_${e}', this.value)" aria-label="ขนาด ${t}">
              ${LOOK_SIZES.map(([k, l]) => `<option value="${k}" ${v['fs_' + e] === k ? 'selected' : ''}>ขนาด${l}</option>`).join('')}
            </select>
            <select onchange="lookSet('fw_${e}', this.value)" aria-label="ความหนา ${t}">
              ${LOOK_WEIGHTS.map(([k, l]) => `<option value="${k}" ${String(v['fw_' + e] || '') === k ? 'selected' : ''}>หนา: ${l}</option>`).join('')}
            </select>
          </div>
          <div class="fx-sample fx-${e}">ตัวอย่าง Aa กขค 1,234 ฿</div>
        </div>`).join('')}
      </div>
    </div>

    <div class="section-card">
      <h3>${admIcon('package')}เลย์เอาต์หน้าร้าน</h3>
      ${row('ความกว้างหน้าเว็บ', 'ความกว้างสูงสุดของเนื้อหา', seg('ui_width'))}
      ${row('รูปแบบฮีโร่', 'ส่วนหัวใหญ่ของหน้าแรก', seg('ui_hero'))}
      ${row('ความหนาแน่น', 'ระยะห่างระหว่างส่วนต่าง ๆ', seg('ui_density'))}
      ${row('ขนาดการ์ดสินค้า', 'ยิ่งใหญ่ ยิ่งแสดงต่อแถวน้อยลง', seg('ui_cols'))}
      ${row('แถบสถิติในฮีโร่', 'สมาชิก / แพ็กเกจ / เซิร์ฟเวอร์', seg('ui_stats'))}
      ${row('แถบจุดเด่นบริการ', 'ส่งมอบทันที ฯลฯ ใต้ฮีโร่', seg('ui_perks'))}
    </div>

    <div class="section-card">
      <h3>${admIcon('zap')}พื้นหลังและเอฟเฟกต์</h3>
      ${row('พื้นหลัง', 'ลวดลายด้านหลังเนื้อหา', seg('ui_bg'))}
      ${row('เอฟเฟกต์การ์ดเมื่อชี้', 'ตอนเมาส์ชี้การ์ดสินค้า', seg('ui_hover'))}
      ${row('การเคลื่อนไหว', 'ปิดเพื่อให้เว็บนิ่งและเบาลง', seg('ui_motion'))}
    </div>

    <div class="section-card">
      <h3>${admIcon('message')}แถบประกาศและข้อความท้ายเว็บ</h3>
      ${row('แถบประกาศด้านบน', 'แสดงเหนือเนื้อหาทุกหน้า เช่น โปรโมชั่นหรือแจ้งปิดปรับปรุง', seg('ann_on'))}
      <label>ข้อความประกาศ</label>
      <input value="${esc(v.ann_text || '')}" maxlength="160" placeholder="เช่น โปรสิ้นเดือน เติมเงินรับโบนัสเพิ่ม 10%" onchange="lookSet('ann_text', this.value)">
      ${row('โทนสีแถบประกาศ', 'เลือกให้ตรงกับความสำคัญของข้อความ', seg('ann_tone'))}
      <label>ข้อความท้ายเว็บ (ไม่บังคับ)</label>
      <input value="${esc(v.footer_text || '')}" maxlength="200" placeholder="เช่น © 2026 Wselx — เปิดให้บริการทุกวัน" onchange="lookSet('footer_text', this.value)">
    </div>

    <div class="look-save">
      <span>${dirty ? 'มีการเปลี่ยนแปลงที่ยังไม่บันทึก — หน้าเว็บกำลังแสดงตัวอย่างสด' : 'ตัวอย่างสดจะแสดงทันทีเมื่อกดเลือก'}</span>
      <div>
        <button class="btn ghost sm" onclick="resetLook()">คืนค่าเริ่มต้น</button>
        <button class="btn ghost sm" onclick="discardLook()" ${dirty ? '' : 'disabled'}>ยกเลิกที่แก้</button>
        <button class="btn" onclick="saveLook()">${admIcon('save')}บันทึกรูปแบบ</button>
      </div>
    </div>
  `;
}

function render() {
  applyLook(lookSrc());
  renderBar();
  const views = {
    shop: viewShop,
    topup: viewTopup,
    history: viewHistory,
    support: viewSupport,
    auth: viewAuth,
    admin: viewAdmin
  };
  $('app').innerHTML = annBar() + (views[S.view] || viewShop)();
  try {
    const hb = document.querySelector('.bar');
    if (hb) document.documentElement.style.setProperty('--hdr', hb.offsetHeight + 'px');
  } catch { /* ignore */ }
  postRender();
}

applyTheme(currentTheme());
addEventListener('keydown', e => { if (e.key === 'Escape' && S.admMenu) admMenu(false); });
addEventListener('resize', () => {
  const hb = document.querySelector('.bar');
  if (hb) document.documentElement.style.setProperty('--hdr', hb.offsetHeight + 'px');
  if (innerWidth > 1000 && S.admMenu) admMenu(false);
});
$('dlg').addEventListener('cancel', e => { if (C.busy) e.preventDefault(); });
$('dlg').addEventListener('click', e => { if (e.target === $('dlg') && !C.busy) $('dlg').close(); });

refreshAll().catch(e => {
  $('app').innerHTML = `<div class="section-card empty">ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้: ${esc(e.message)}</div>`;
});
