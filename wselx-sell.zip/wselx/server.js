const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { Pool, types: pgTypes } = require('pg');
pgTypes.setTypeParser(20, v => parseInt(v, 10)); // BIGINT -> number (กันปุ่มสั่งซื้อกดไม่ได้เพราะ id เป็น string)
const { Client: SshClient } = require('ssh2');

const {
  DATABASE_URL,
  JWT_SECRET,
  DATA_KEY,
  ADMIN_USERNAME,
  NOTIFY_WEBHOOK_URL,
  XXT_LINK_KEY,
  XUI_PANEL_URL,
  XUI_USER,
  XUI_PASS,
  SITE_DOMAIN
} = process.env;
const XXT_PANEL_URL = (process.env.XXT_PANEL_URL || 'http://127.0.0.1:8088').trim();
// ลิงก์ปุ่ม "เปิดแดชบอร์ด" ในหน้าแอดมิน (เช่น https://โดเมน:6787/) — ไม่ตั้งไว้จะใช้ /panel/ ใต้โดเมนเดียวกัน
const XXT_PANEL_WEB = (process.env.XXT_PANEL_WEB || '').trim();

if (!DATABASE_URL || !JWT_SECRET || !DATA_KEY || DATA_KEY.length !== 64) {
  console.error('ตั้งค่า DATABASE_URL, JWT_SECRET, DATA_KEY (hex 64 ตัว) ใน .env ก่อน');
  process.exit(1);
}

const KEY = Buffer.from(DATA_KEY, 'hex');
const pool = new Pool({ connectionString: DATABASE_URL });
const PROD = process.env.NODE_ENV === 'production';

class HttpErr extends Error {
  constructor(s, m, code) {
    super(m);
    this.status = s;
    this.code = code;
  }
}

// ---------- encryption & helpers ----------
const enc = t => {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', KEY, iv);
  const b = Buffer.concat([c.update(String(t), 'utf8'), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), b]).toString('base64');
};

const dec = s => {
  try {
    const b = Buffer.from(String(s), 'base64');
    const d = crypto.createDecipheriv('aes-256-gcm', KEY, b.subarray(0, 12));
    d.setAuthTag(b.subarray(12, 28));
    return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8');
  } catch {
    return '[ถอดรหัสไม่ได้]';
  }
};

const xfetch = (u, o = {}) => fetch(u, { ...o, signal: AbortSignal.timeout(15000) });
const rnd = n => Array.from(crypto.randomBytes(n), x => 'abcdefghjkmnpqrstuvwxyz23456789'[x % 31]).join('');
const genRefCode = () => 'NP' + rnd(6).toUpperCase();
const fmtDur = h => h === 24 ? '24 ชั่วโมง' : h % 24 === 0 ? (h / 24) + ' วัน' : h + ' ชั่วโมง';
// ระยะเวลาแพ็กเกจ: duration_hours (ชม. เต็ม) + duration_minutes (ไม่บังคับ — ใช้กับแพ็กเกจสั้นกว่า 1 ชม. เช่น ทดลอง 20 นาที)
const planMins = pl => Number(pl.duration_minutes) > 0 ? Number(pl.duration_minutes) : Number(pl.duration_hours || 24) * 60;
const fmtDurM = pl => {
  const m = planMins(pl);
  if (m < 60 || m % 60) return m + ' นาที';
  return fmtDur(m / 60);
};
// รับ "20 นาที" / "20m" / "24 ชั่วโมง" / "7 วัน" (ไม่ใส่หน่วย = ชั่วโมง) → จำนวนนาที
const parseDurMin = s => {
  const m = String(s).match(/(\d+(?:\.\d+)?)\s*(นาที|min(?:ute)?s?|m|วัน|days?|d|ชั่วโมง|ชม\.?|hours?|h)?/i);
  if (!m) return 0;
  const n = parseFloat(m[1]), u = (m[2] || '').toLowerCase();
  const mult = /^(นาที|min|m$)/.test(u) ? 1 : /^(วัน|d)/.test(u) ? 1440 : 60;
  return Math.round(n * mult);
};
const parseDur = s => {
  const m = String(s).match(/(\d+(?:\.\d+)?)\s*(ชั่วโมง|ชม|วัน|d|h)?/i);
  if (!m) return 0;
  const n = parseFloat(m[1]);
  return Math.round(/วัน|d/i.test(m[2] || '') ? n * 24 : n);
};

async function tx(fn) {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const r = await fn(c);
    await c.query('COMMIT');
    return r;
  } catch (e) {
    await c.query('ROLLBACK').catch(() => {});
    throw e;
  } finally {
    c.release();
  }
}

const audit = (actor, action, detail, ip) => {
  auditNotify(actor, action, detail, ip).catch(() => {});
  return pool.query(
    'INSERT INTO audit_log(actor_id,action,detail,ip) VALUES($1,$2,$3,$4)',
    [actor, action, detail ? JSON.stringify(detail) : null, ip || null]
  ).catch(() => {});
};

// ---------- แจ้งเตือน Telegram ทุกรายการที่เกิดจากเว็บ (ผูกกับ audit log) ----------
// ตั้งค่าได้ที่หลังบ้าน → ตั้งค่าเว็บไซต์ → "แจ้งเตือน Telegram" (เก็บเข้ารหัสในฐานข้อมูล, มีผลทันทีไม่ต้องรีสตาร์ต)
// ถ้าหลังบ้านไม่ได้ตั้ง จะใช้ค่าใน .env แทน: TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID / TELEGRAM_NOTIFY_ALL / TELEGRAM_MUTE_EVENTS
const TG_KEYS = ['tg_bot_token', 'tg_chat_id', 'tg_notify_all', 'tg_mute_events'];
let TG_CACHE = null;
const tgInvalidate = () => { TG_CACHE = null; };
const tgCsv = v => new Set(String(v || '').split(',').map(x => x.trim()).filter(Boolean));
async function tgConf() {
  if (TG_CACHE && Date.now() - TG_CACHE.at < 10e3) return TG_CACHE.v;
  const st = {};
  try {
    const rows = (await pool.query('SELECT key, value FROM settings WHERE key = ANY($1)', [TG_KEYS])).rows;
    for (const r of rows) { const v = dec(r.value); if (v !== '[ถอดรหัสไม่ได้]') st[r.key] = v; }
  } catch { /* ใช้ค่าจาก .env */ }
  const envTok = String(process.env.TELEGRAM_BOT_TOKEN || '').trim();
  const envChat = String(process.env.TELEGRAM_CHAT_ID || '').trim();
  const token = (st.tg_bot_token || envTok).trim();
  const chatId = (st.tg_chat_id || envChat).trim();
  const v = {
    token, chatId,
    source: st.tg_bot_token ? 'db' : (envTok ? 'env' : 'none'),
    notifyAll: st.tg_notify_all !== undefined ? st.tg_notify_all === '1' : String(process.env.TELEGRAM_NOTIFY_ALL || 'true').toLowerCase() !== 'false',
    mute: tgCsv(st.tg_mute_events !== undefined ? st.tg_mute_events : process.env.TELEGRAM_MUTE_EVENTS)
  };
  TG_CACHE = { at: Date.now(), v };
  return v;
}
// เรียก Telegram Bot API — ข้อความ error ที่ส่งกลับไม่มี token ติดไปด้วย
async function tgCall(token, method, body) {
  let r, j;
  try {
    r = await xfetch(`https://api.telegram.org/bot${token}/${method}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {})
    });
    j = await r.json().catch(() => null);
  } catch (e) {
    throw new HttpErr(502, 'เชื่อมต่อ Telegram ไม่ได้ (' + String((e && e.cause && e.cause.code) || (e && e.name) || 'network').slice(0, 40) + ') — ตรวจว่าเซิร์ฟเวอร์ออกอินเทอร์เน็ตได้');
  }
  if (!j || !j.ok) throw new HttpErr(400, 'Telegram: ' + String((j && j.description) || ('HTTP ' + (r && r.status))).slice(0, 200));
  return j.result;
}
// เหตุการณ์ที่มีข้อความแจ้งเตือนของตัวเองอยู่แล้ว จึงไม่ส่งซ้ำ
const TG_ALREADY = new Set(['topup_request', 'refund_request', 'ticket_create']);
const TG_THROTTLE = new Map(); // กันสแปมเหตุการณ์ที่เกิดถี่ เช่น ใส่รหัสผิด
const TG_LABEL = {
  register: '🆕 สมาชิกใหม่สมัคร',
  login_fail: '⚠️ ล็อกอินไม่สำเร็จ',
  login_2fa_fail: '⚠️ ใส่รหัส 2FA ผิด',
  password_change: '🔐 เปลี่ยนรหัสผ่าน',
  recovery_regen: '🔑 สร้างรหัสกู้คืนใหม่',
  forgot_fail: '⚠️ กู้รหัสผ่านไม่สำเร็จ',
  password_reset_recovery: '🔓 รีเซ็ตรหัสผ่านด้วยรหัสกู้คืน',
  topup_auto_approved: '🤖 เติมเงินอนุมัติอัตโนมัติ (ตรวจสลิปผ่าน)',
  topup_approve: '✅ แอดมินอนุมัติเติมเงิน',
  topup_reject: '❌ แอดมินปฏิเสธเติมเงิน',
  purchase: '🛒 มีคำสั่งซื้อใหม่',
  order_renew: '🔄 ลูกค้าต่ออายุ',
  order_auto_renew: '🔁 ต่ออายุอัตโนมัติสำเร็จ',
  order_auto_renew_fail: '⚠️ ต่ออายุอัตโนมัติไม่สำเร็จ',
  order_refund: '💸 แอดมินคืนเงินออเดอร์',
  order_deprovision: '🗑️ ระบบปิดบัญชีบนเซิร์ฟเวอร์',
  review_upsert: '⭐ มีรีวิวใหม่',
  ticket_reply: '💬 แอดมินตอบแจ้งปัญหา',
  site_update: '⚙️ แก้ตั้งค่าเว็บ/ตั้งค่า API',
  '2fa_enable': '🛡️ เปิด 2FA',
  '2fa_disable': '🛡️ ปิด 2FA',
  user_credit_adjust: '💳 แอดมินปรับเครดิตสมาชิก',
  user_update: '👤 แอดมินแก้ข้อมูลสมาชิก',
  server_add: '🖥️ เพิ่มเซิร์ฟเวอร์',
  server_edit: '🖥️ แก้เซิร์ฟเวอร์',
  server_delete: '🖥️ ลบเซิร์ฟเวอร์',
  xxt_link: '🔗 เชื่อมแดชบอร์ด XXT',
  xui_link: '🔗 เชื่อม 3x-ui',
  product_add: '📦 เพิ่มสินค้า',
  product_edit: '📦 แก้สินค้า',
  product_hide: '📦 ซ่อนสินค้า',
  coupon_create: '🎟️ สร้างคูปอง',
  coupon_disable: '🎟️ ปิดคูปอง',
  telegram_update: '🤖 แก้ตั้งค่า Telegram'
};
const TG_ADMIN_ACTIONS = new Set(['topup_approve', 'topup_reject', 'order_refund', 'ticket_reply', 'site_update', 'user_credit_adjust', 'user_update',
  'server_add', 'server_edit', 'server_delete', 'xxt_link', 'xui_link', 'product_add', 'product_edit', 'product_hide', 'coupon_create', 'coupon_disable', '2fa_enable', '2fa_disable', 'telegram_update']);

async function auditNotify(actor, action, detail, ip) {
  const tg = await tgConf();
  if (!tg.token || !tg.chatId) return;
  if (!tg.notifyAll) return;
  if (TG_ALREADY.has(action) || tg.mute.has(action)) return;

  const label = TG_LABEL[action] || ('📌 ' + action);
  // เหตุการณ์ถี่: ส่งได้ไม่เกิน 1 ครั้ง/นาที ต่อ (เหตุการณ์ + ผู้ใช้/ไอพี)
  if (['login_fail', 'login_2fa_fail', 'forgot_fail', 'order_auto_renew_fail'].includes(action)) {
    const key = action + '|' + (actor || ip || '');
    const now = Date.now();
    if (now - (TG_THROTTLE.get(key) || 0) < 60e3) return;
    TG_THROTTLE.set(key, now);
    if (TG_THROTTLE.size > 500) TG_THROTTLE.clear();
  }

  let who = '';
  if (actor) {
    const u = (await pool.query('SELECT username FROM users WHERE id=$1', [actor]).catch(() => ({ rows: [] }))).rows[0];
    who = u ? '@' + u.username : 'ผู้ใช้ #' + actor;
  }
  const d = detail || {};
  const lines = [label];
  if (who) lines.push((TG_ADMIN_ACTIONS.has(action) ? 'โดยแอดมิน: ' : 'ผู้ใช้: ') + who);

  const baht = n => Number(n).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ฿';
  const orderInfo = async id => {
    const r = (await pool.query(
      'SELECT p.title, pl.name AS plan_name FROM orders o JOIN plans pl ON pl.id=o.plan_id JOIN products p ON p.id=pl.product_id WHERE o.id=$1', [id]
    ).catch(() => ({ rows: [] }))).rows[0];
    return r ? `${r.title} – ${r.plan_name}` : '';
  };

  if (action === 'purchase') {
    lines.push(`ออเดอร์ #${d.order}`);
    const info = await orderInfo(d.order);
    if (info) lines.push('แพ็กเกจ: ' + info);
    if (d.paid != null) lines.push('ชำระ: ' + baht(d.paid));
  } else if (['order_renew', 'order_auto_renew'].includes(action)) {
    lines.push(`ออเดอร์ #${d.orderId}`);
    const info = await orderInfo(d.orderId);
    if (info) lines.push('แพ็กเกจ: ' + info);
    if (d.paid != null) lines.push('ชำระ: ' + baht(d.paid));
    if (d.newExpiresAt) lines.push('หมดอายุใหม่: ' + new Date(d.newExpiresAt).toLocaleString('th-TH', { timeZone: 'Asia/Bangkok' }));
  } else if (action === 'order_auto_renew_fail') {
    lines.push(`ออเดอร์ #${d.orderId}`, 'สาเหตุ: ' + String(d.error || '-').slice(0, 150));
  } else if (['topup_auto_approved', 'topup_approve'].includes(action)) {
    const amt = d.amount != null ? d.amount : d.amount;
    lines.push(`รายการ #${d.topupId || d.id}`);
    if (amt != null) lines.push('ยอด: ' + baht(amt));
    if (+d.bonusAmount > 0 || +d.bonus > 0) lines.push('โบนัส: ' + baht(d.bonusAmount || d.bonus));
  } else if (action === 'topup_reject') {
    lines.push(`รายการ #${d.id}`);
  } else if (action === 'order_refund') {
    lines.push(`ออเดอร์ #${d.orderId}`);
    if (d.amount != null) lines.push('คืนเครดิต: ' + baht(d.amount));
  } else if (action === 'user_credit_adjust') {
    lines.push(`สมาชิก #${d.targetUserId}`, 'จำนวน: ' + baht(d.amount));
    if (d.note) lines.push('หมายเหตุ: ' + String(d.note).slice(0, 100));
  } else if (action === 'user_update') {
    lines.push(`สมาชิก #${d.targetUserId}`, `สิทธิ์: ${d.role || '-'} • ถูกแบน: ${d.isBanned ? 'ใช่' : 'ไม่'}`);
  } else if (action === 'login_fail' || action === 'forgot_fail') {
    lines.push('ชื่อที่ใช้: ' + (d.u || '-'));
  } else if (action === 'review_upsert') {
    lines.push(`สินค้า #${d.productId} • ${'⭐'.repeat(Math.max(0, Math.min(5, +d.rating || 0)))}`);
  } else if (action === 'ticket_reply') {
    lines.push(`ตั๋ว #${d.ticketId} • สถานะ: ${d.status || '-'}`);
  } else if (d.name) {
    lines.push('ชื่อ: ' + String(d.name).slice(0, 80));
  } else if (d.id) {
    lines.push('รหัส: #' + d.id);
  }
  if (ip) lines.push('IP: ' + ip);
  lines.push('เวลา: ' + new Date().toLocaleString('th-TH', { timeZone: 'Asia/Bangkok' }));

  await notifyExternal(lines.join('\n'), { telegramOnly: true });
}

const balanceOf = async id => {
  const r = await pool.query('SELECT credit_balance FROM users WHERE id=$1', [id]);
  return r.rows[0] ? +r.rows[0].credit_balance : 0;
};

async function getSettingsMap(client = pool, includeSecret = false) {
  const sql = includeSecret
    ? 'SELECT key, value, is_secret FROM settings'
    : 'SELECT key, value FROM settings WHERE NOT is_secret';
  const rows = (await client.query(sql)).rows;
  const out = {};
  for (const r of rows) {
    out[r.key] = includeSecret && r.is_secret ? dec(r.value) : r.value;
  }
  return out;
}

// วันที่ "อัพเดทล่าสุด" ของเว็บ (แสดงหน้าแรก) — ตั้งอัตโนมัติเมื่อแอดมินบันทึกตั้งค่าเว็บ หรือเพิ่ม/แก้ไข/ซ่อนแพ็กเกจ
async function touchUpdated() {
  try {
    await pool.query(
      "INSERT INTO settings(key,value,is_secret) VALUES('last_update',$1,FALSE) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value",
      [new Date().toISOString()]
    );
  } catch (e) { console.error('touchUpdated', e.message); }
}

async function notifyExternal(text, opts = {}) {
  const jobs = [];
  if (NOTIFY_WEBHOOK_URL && !opts.telegramOnly) {
    jobs.push(
      xfetch(NOTIFY_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: text, text })
      }).catch(() => {})
    );
  }
  const tg = await tgConf();
  if (tg.token && tg.chatId) {
    jobs.push(tgCall(tg.token, 'sendMessage', { chat_id: tg.chatId, text }).catch(() => {}));
  }
  if (jobs.length) await Promise.allSettled(jobs);
}

// =====================================================
// 3x-ui / X-UI API Connector (รองรับ Base Path และ Session Cookie)
// =====================================================
function normalizePanelUrl(rawUrl) {
  return String(rawUrl || '').trim().replace(/\/+$/, '');
}

// รวม Set-Cookie ใหม่เข้ากับของเดิม (ชื่อซ้ำ = ใช้ค่าล่าสุด)
function mergeCookies(jar, res) {
  const list = typeof res.headers.getSetCookie === 'function'
    ? res.headers.getSetCookie()
    : String(res.headers.get('set-cookie') || '').split(/,(?=\s*[^;,=\s]+=)/);
  for (const c of list) {
    const pair = c.split(';')[0].trim();
    const eq = pair.indexOf('=');
    if (eq > 0) jar.set(pair.slice(0, eq), pair.slice(eq + 1));
  }
  return list.length;
}
const cookieString = jar => [...jar].map(([k, v]) => `${k}=${v}`).join('; ');

// 3x-ui รุ่นใหม่ต้องใช้ CSRF Token กับทุกคำสั่ง POST (รุ่นเก่าไม่มีเส้นทางนี้ → คืนค่าว่าง)
async function fetch3xuiCsrf(baseUrl, jar) {
  const res = await xfetch(`${baseUrl}/csrf-token`, {
    headers: { Cookie: cookieString(jar), 'X-Requested-With': 'XMLHttpRequest' }
  });
  mergeCookies(jar, res);
  if (!res.ok) return '';
  const d = await res.json().catch(() => null);
  return d && d.success === true && typeof d.obj === 'string' ? d.obj : '';
}

async function login3xui(server) {
  const baseUrl = normalizePanelUrl(server.panel_url);
  if (!baseUrl) throw new HttpErr(400, 'ยังไม่ได้ตั้งค่า Panel URL ของเซิร์ฟเวอร์');
  const password = server.panel_pass_enc ? dec(server.panel_pass_enc) : '';

  const jar = new Map();
  const preToken = await fetch3xuiCsrf(baseUrl, jar);

  const headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
  if (preToken) {
    headers['X-CSRF-Token'] = preToken;
    headers.Cookie = cookieString(jar);
  }
  const res = await xfetch(`${baseUrl}/login`, {
    method: 'POST',
    headers,
    body: new URLSearchParams({
      username: server.panel_user || '',
      password
    }).toString()
  });

  if (!res.ok) {
    throw new HttpErr(502, `เชื่อมต่อ 3x-ui ไม่สำเร็จ (HTTP ${res.status})`);
  }

  const data = await res.json().catch(() => ({}));
  if (!data || data.success !== true) {
    throw new HttpErr(401, data?.msg || 'ชื่อผู้ใช้หรือรหัสผ่าน 3x-ui ไม่ถูกต้อง');
  }

  if (!mergeCookies(jar, res) || !jar.size) {
    throw new HttpErr(502, 'ล็อกอิน 3x-ui สำเร็จแต่ไม่ได้รับ Session Cookie');
  }

  // หลังล็อกอิน 3x-ui ล้าง session เดิม ต้องขอ CSRF Token ใหม่
  const csrf = preToken ? await fetch3xuiCsrf(baseUrl, jar) : '';
  if (preToken && !csrf) throw new HttpErr(502, 'ล็อกอิน 3x-ui สำเร็จแต่ขอ CSRF Token ไม่ได้');

  const auth = { Cookie: cookieString(jar), ...(csrf ? { 'X-CSRF-Token': csrf } : {}) };
  return { baseUrl, auth };
}

// POST แบบ JSON ไปที่ 3x-ui
async function post3xui(url, auth, body) {
  const r = await xfetch(url, {
    method: 'POST',
    headers: { ...auth, ...(body ? { 'Content-Type': 'application/json' } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {})
  });
  const d = await r.json().catch(() => ({}));
  return { r, d, ok: r.ok && d.success !== false };
}

// อัปเดต client ด้วย API ใหม่: 3x-ui บางรุ่น (เช่น 3.11.0) เขียนทับทั้งชุด จึงต้องส่งข้อมูลครบเสมอ
async function update3xuiClient(baseUrl, auth, client) {
  const email = encodeURIComponent(client.email);
  const g = await xfetch(`${baseUrl}/panel/api/clients/get/${email}`, { headers: auth });
  const rec = g.ok ? (await g.json().catch(() => ({})))?.obj?.client : null;
  const body = { ...client, tgId: Number(client.tgId) || 0 };
  // ค่าที่เก็บในระเบียน client เท่านั้น (ไม่มีใน inbound settings) ต้องส่งกลับไปด้วย ไม่ให้ถูกล้าง
  for (const k of ['limitHwid', 'group', 'comment']) {
    if (body[k] === undefined && rec?.[k] !== undefined) body[k] = rec[k];
  }
  return post3xui(`${baseUrl}/panel/api/clients/update/${email}`, auth, body);
}

async function test3xuiServer(server) {
  const { baseUrl, auth } = await login3xui(server);
  const listRes = await xfetch(`${baseUrl}/panel/api/inbounds/list`, { headers: auth });
  if (!listRes.ok) {
    throw new HttpErr(502, `ดึงรายการ Inbound ไม่สำเร็จ (HTTP ${listRes.status})`);
  }
  const listData = await listRes.json().catch(() => ({}));
  const inbounds = Array.isArray(listData.obj) ? listData.obj : [];
  const targetInbound = inbounds.find(x => Number(x.id) === Number(server.inbound_id));

  return {
    ok: true,
    inboundCount: inbounds.length,
    inbounds: inbounds.map(x => ({
      id: x.id,
      remark: x.remark || `Inbound #${x.id}`,
      port: x.port,
      protocol: x.protocol,
      enable: x.enable,
      network: summarizeInbound(x).network,
      security: summarizeInbound(x).security
    })),
    matchedInbound: targetInbound
      ? (({ id, remark, port, protocol, network, security }) => ({ id, remark, port, protocol, network, security }))(summarizeInbound(targetInbound))
      : null
  };
}

const parseJsonSafe = v => {
  try { return typeof v === 'string' ? JSON.parse(v) : (v || {}); } catch { return {}; }
};

// อ่านค่าจริงของ inbound จาก 3x-ui (network / security / path / sni / reality ฯลฯ)
// เพื่อสร้างลิงก์ให้ตรงกับที่เซิร์ฟเวอร์ใช้งานจริง ไม่เดาว่าเป็น WebSocket เสมอ
function summarizeInbound(ib) {
  const ss = parseJsonSafe(ib.streamSettings);
  const st = parseJsonSafe(ib.settings);
  const network = String(ss.network || 'tcp').toLowerCase();
  const security = String(ss.security || 'none').toLowerCase();
  const tls = ss.tlsSettings || {};
  const rl = ss.realitySettings || {};
  const first = v => Array.isArray(v) ? (v[0] || '') : (v || '');
  const hdrHost = h => {
    if (!h) return '';
    const v = h.Host ?? h.host;
    return Array.isArray(v) ? (v[0] || '') : (v || '');
  };

  const info = {
    id: ib.id, remark: ib.remark, port: ib.port, enable: ib.enable,
    protocol: String(ib.protocol || '').toLowerCase(),
    network, security,
    path: '', host: '', serviceName: '', authority: '', mode: '', headerType: 'none',
    sni: '', fp: '', alpn: '', pbk: '', sid: '', spx: '',
    clients: Array.isArray(st.clients) ? st.clients : []
  };

  if (network === 'ws') {
    info.path = ss.wsSettings?.path || '/';
    info.host = ss.wsSettings?.host || hdrHost(ss.wsSettings?.headers);
  } else if (network === 'httpupgrade') {
    info.path = ss.httpupgradeSettings?.path || '/';
    info.host = ss.httpupgradeSettings?.host || hdrHost(ss.httpupgradeSettings?.headers);
  } else if (network === 'xhttp' || network === 'splithttp') {
    const x = ss.xhttpSettings || ss.splithttpSettings || {};
    info.path = x.path || '/';
    info.host = x.host || hdrHost(x.headers);
    info.mode = x.mode || '';
  } else if (network === 'grpc') {
    info.serviceName = ss.grpcSettings?.serviceName || '';
    info.authority = ss.grpcSettings?.authority || '';
  } else if (network === 'tcp') {
    const h = ss.tcpSettings?.header;
    if (h && h.type === 'http') {
      info.headerType = 'http';
      const req = h.request || {};
      info.path = first(req.path) || '/';
      info.host = hdrHost(req.headers);
    }
  }

  if (security === 'tls') {
    info.sni = tls.serverName || '';
    info.fp = tls.settings?.fingerprint || tls.fingerprint || '';
    info.alpn = Array.isArray(tls.alpn) ? tls.alpn.join(',') : (tls.alpn || '');
  } else if (security === 'reality') {
    info.sni = first(rl.serverNames);
    info.fp = rl.settings?.fingerprint || rl.fingerprint || 'chrome';
    info.pbk = rl.settings?.publicKey || rl.publicKey || '';
    info.sid = first(rl.shortIds);
    info.spx = rl.settings?.spiderX || rl.spiderX || '';
  }
  return info;
}

async function fetchInbound(baseUrl, auth, inboundId) {
  try {
    const r = await xfetch(`${baseUrl}/panel/api/inbounds/get/${Number(inboundId)}`, { headers: auth });
    const d = await r.json().catch(() => ({}));
    if (!r.ok || !d || !d.obj) return null;
    return summarizeInbound(d.obj);
  } catch {
    return null;
  }
}

// ib = ผลจาก summarizeInbound (ถ้าอ่านจาก 3x-ui ไม่ได้ จะ fallback ไปใช้ค่าที่ตั้งในหน้าแอดมิน = WebSocket)
function buildClientLink(server, meta, ib = null) {
  const proto = String(ib?.protocol || server.protocol || 'vless').toLowerCase();
  const host = server.host;
  const p = ib || {
    port: server.public_port || 443,
    network: 'ws',
    security: server.tls_enabled ? 'tls' : 'none',
    path: server.ws_path || '/',
    host: server.sni || host,
    sni: server.sni || host,
    serviceName: '', authority: '', mode: '', headerType: 'none', fp: '', alpn: '', pbk: '', sid: '', spx: ''
  };
  const port = server.public_port || p.port || 443;
  const sni = server.sni || p.sni || (p.security === 'none' ? '' : host);
  const wsHost = p.host || sni || host;
  const net = p.network === 'splithttp' ? 'xhttp' : p.network;
  const uri = encodeURIComponent;
  const remark = uri(meta.remark);

  if (proto === 'vmess') {
    const vmessObj = {
      v: '2', ps: meta.remark, add: host, port: String(port),
      id: meta.uuid, aid: '0', scy: 'auto',
      net,
      type: net === 'grpc' ? 'gun' : (p.headerType || 'none'),
      host: net === 'grpc' ? (p.authority || '') : wsHost,
      path: net === 'grpc' ? p.serviceName : (p.path || '/'),
      tls: p.security === 'tls' ? 'tls' : '',
      sni: p.security === 'tls' ? sni : '',
      alpn: p.alpn || '',
      fp: p.fp || ''
    };
    return 'vmess://' + Buffer.from(JSON.stringify(vmessObj)).toString('base64');
  }

  const q = [];
  const add = (k, v) => { if (v !== undefined && v !== null && v !== '') q.push(`${k}=${uri(v)}`); };
  add('type', net);
  if (proto === 'vless') add('encryption', 'none');
  add('security', p.security);

  if (net === 'ws' || net === 'httpupgrade' || net === 'xhttp') {
    add('path', p.path || '/');
    add('host', wsHost);
    if (net === 'xhttp') add('mode', p.mode);
  } else if (net === 'grpc') {
    add('serviceName', p.serviceName);
    add('authority', p.authority);
    add('mode', 'gun');
  } else if (net === 'tcp') {
    add('headerType', p.headerType || 'none');
    if (p.headerType === 'http') { add('path', p.path); add('host', p.host); }
  }

  if (p.security === 'tls') {
    add('sni', sni);
    add('fp', p.fp);
    add('alpn', p.alpn);
  } else if (p.security === 'reality') {
    add('sni', sni);
    add('fp', p.fp || 'chrome');
    add('pbk', p.pbk);
    add('sid', p.sid);
    add('spx', p.spx);
  }
  if (proto === 'vless' && net === 'tcp' && (p.security === 'tls' || p.security === 'reality')) {
    add('flow', 'xtls-rprx-vision');
  }

  return `${proto}://${uri(meta.uuid)}@${host}:${port}?${q.join('&')}#${remark}`;
}

// =====================================================
// SSH Connector (สร้าง/ต่ออายุ user จริงบนเซิร์ฟเวอร์ผ่าน ssh2)
// ต้องใช้ root หรือ user ที่ sudo ได้โดยไม่ถาม password
// =====================================================
function sshExec(server, cmd) {
  return new Promise((resolve, reject) => {
    if (!server.ssh_user || !server.ssh_pass_enc) {
      return reject(new HttpErr(400, 'ยังไม่ได้ตั้งค่า SSH User/Password ของเซิร์ฟเวอร์นี้'));
    }
    const c = new SshClient();
    let out = '', err = '';
    const timer = setTimeout(() => { c.end(); reject(new HttpErr(504, 'SSH หมดเวลาเชื่อมต่อ')); }, 25000);
    const fail = e => { clearTimeout(timer); c.end(); reject(e instanceof HttpErr ? e : new HttpErr(502, 'SSH: ' + e.message)); };
    c.on('ready', () => c.exec(cmd, (e, st) => {
      if (e) return fail(e);
      st.on('data', d => { out += d; });
      st.stderr.on('data', d => { err += d; });
      st.on('close', code => {
        clearTimeout(timer); c.end();
        code === 0 ? resolve(out.trim()) : reject(new HttpErr(502, 'คำสั่ง SSH ล้มเหลว: ' + (err || out).trim().slice(0, 200)));
      });
    }));
    c.on('error', fail);
    c.connect({ host: server.host, port: server.ssh_port || 22, username: server.ssh_user, password: dec(server.ssh_pass_enc), readyTimeout: 15000 });
  });
}
const sshDate = ms => new Date(ms + 864e5).toISOString().slice(0, 10); // +1 วัน กันตัดก่อนเวลา
const sshCreateUser = (server, user, pass, expMs) =>
  sshExec(server, `useradd -M -s /bin/false -e ${sshDate(expMs)} ${user} && echo '${user}:${pass}' | chpasswd`);
const SAFE_USER = /^[A-Za-z0-9_.-]{1,40}$/;
const needSafeUser = u => {
  if (!SAFE_USER.test(String(u || ''))) throw new HttpErr(400, 'ชื่อ user ไม่ปลอดภัย/ไม่ถูกต้อง');
  return u;
};
const sshExtendUser = (server, user, expMs) =>
  sshExec(server, `chage -E ${sshDate(expMs)} ${needSafeUser(user)} && (usermod -U ${user} 2>/dev/null || true)`);


// =====================================================
// XXTLONLINE Dashboard Connector (v2 — ใช้ API Key)
// เรียก REST API ของแดชบอร์ด /api/v1 ด้วย API Key (สร้างที่แดชบอร์ด → เมนู API)
// ตั้งค่าที่ฟอร์มเซิร์ฟเวอร์: panel_url = https://โดเมนแดชบอร์ด , panel_pass = API Key
// รูปแบบ Config (Profile ID) เก็บในคอลัมน์ npv_type — ว่างหรือ SSH-Direct = ใช้ "ค่าหลัก" ของแดชบอร์ด
// =====================================================
async function xxtCall(server, method, path, body) {
  const base = normalizePanelUrl(server.panel_url);
  if (!base) throw new HttpErr(400, 'ยังไม่ได้ตั้งค่า Dashboard URL ของเซิร์ฟเวอร์');
  const key = server.panel_pass_enc ? dec(server.panel_pass_enc) : '';
  if (!key) throw new HttpErr(400, 'ยังไม่ได้ตั้งค่า API Key ของแดชบอร์ด');
  const opt = { method, headers: { Authorization: 'Bearer ' + key } };
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const res = await xfetch(base + '/api/v1' + path, opt);
  const d = await res.json().catch(() => ({}));
  if (res.status === 401) throw new HttpErr(401, 'แดชบอร์ดปฏิเสธ API Key — ใช้คีย์ที่สร้างจากเมนู API ของแดชบอร์ด (ไม่ใช่รหัสผ่านแอดมิน)');
  if (res.status === 403) throw new HttpErr(403, 'แดชบอร์ดไม่อนุญาต IP ของเซิร์ฟเวอร์ร้านนี้ — เพิ่ม IP ในช่องจำกัด IP ของคีย์ หรือสร้างคีย์ใหม่แบบไม่จำกัด IP');
  if (res.status === 429) throw new HttpErr(429, 'แดชบอร์ดล็อกชั่วคราว (คีย์ผิดหลายครั้ง) รอ 5 นาทีแล้วลองใหม่');
  if (res.status === 404 && d?.error === 'not found') throw new HttpErr(502, 'แดชบอร์ดเวอร์ชันเก่า ไม่มี API v1 — อัปเดตแดชบอร์ดเป็น xxtlonline v2 ก่อน');
  return { status: res.status, d };
}
const xxtFail = (r, fallback) => new HttpErr(502, 'แดชบอร์ด: ' + String(r?.d?.error || r?.d?.message || fallback + ` (HTTP ${r?.status})`).slice(0, 200));
const xxtNotFound = r => r?.status === 404 || /ไม่พบ user/.test(String(r?.d?.error || ''));
const xxtDays = hours => Math.max(1, Math.ceil(Number(hours || 24) / 24));
// ลำดับการเลือก Profile: ของแพ็กเกจ (products.xxt_profile) → ของเซิร์ฟเวอร์ (npv_type) → ค่าหลักของแดชบอร์ด
const XXT_PROFILE_RE = /^[A-Za-z0-9_-]{1,40}$/;
const xxtProfile = (server, pl) => {
  const own = String(pl?.xxt_profile || '').trim();
  if (own) return own;
  const v = String(server.npv_type || '').trim();
  return v && v !== 'SSH-Direct' ? v : undefined;
};

const xxtFill = (t, c) => String(t)
  .replaceAll('{host}', () => c.host).replaceAll('{port}', () => String(c.port))
  .replaceAll('{ssh_port}', () => String(c.port))
  .replaceAll('{user}', () => c.user).replaceAll('{pass}', () => c.password).replaceAll('{exp}', () => c.exp);
const xxtB64 = v => Buffer.from(String(v), 'utf8').toString('base64');

async function xxtProvision(server, pl) {
  // แพ็กเกจสั้นกว่า 1 วัน (เช่น ทดลอง 20 นาที) ส่งเป็น minutes ให้แดชบอร์ดตัดบัญชีตรงเวลา
  const m = Number(pl.duration_minutes) || 0;
  const dur = m > 0 && m < 1440 ? { minutes: m } : { days: xxtDays(pl.duration_hours) };
  const profile = xxtProfile(server, pl);
  let data = null, lastErr = null;
  for (let i = 0; i < 3 && !data; i++) {        // ชื่อชน → สุ่มใหม่
    const r = await xxtCall(server, 'POST', '/users', { username: 'np' + rnd(7), ...dur, password: rnd(10), ...(profile ? { profile } : {}), ...(Number(pl.max_conns) > 0 ? { limit: Number(pl.max_conns), max_logins: Number(pl.max_conns) } : {}) });
    if (r.d?.ok && r.d.data?.username) data = r.d.data;
    else if (r.status === 409) lastErr = xxtFail(r, 'ชื่อซ้ำ');
    else throw xxtFail(r, 'สร้างบัญชีไม่สำเร็จ (ระบบไม่ได้หักเครดิต)');
  }
  if (!data) throw lastErr || new HttpErr(502, 'สร้างบัญชีบนแดชบอร์ดไม่สำเร็จ');

  const c = { user: data.username, password: data.password, exp: data.expires, host: data.host, port: data.port };
  const tpl = String(server.template || '').trim();
  const accountText = (tpl ? xxtFill(tpl, c) : data.text) +
    '\n\nลิงก์ NPV Tunnel:\n' + data.links.npv +
    '\n\nลิงก์ NetMod:\n' + data.links.netmod;
  return { accountText, clientEmail: data.username, clientUuid: null };
}

async function xxtRenew(server, user, hours) {
  const u = needSafeUser(user);
  await xxtCall(server, 'POST', `/users/${u}/resume`).catch(() => {});   // ปลดระงับถ้าถูกปิดตอนหมดอายุ
  const r = await xxtCall(server, 'POST', `/users/${u}/extend`, { days: xxtDays(hours) });
  if (!r.d?.ok) throw xxtFail(r, 'ต่ออายุบนแดชบอร์ดไม่สำเร็จ');
}

// ปิดบัญชีบนเซิร์ฟเวอร์จริง
//   mode 'disable' = ล็อก/ปิดไว้ชั่วคราว (หมดอายุ — ต่ออายุแล้วเปิดกลับได้)
//   mode 'delete'  = ลบทิ้ง (คืนเงิน)
async function deprovisionAccount(server, ord, mode) {
  if (!server || !ord.client_email) return 'skipped';

  if (server.type === '3xui') {
    if (!ord.client_uuid) return 'skipped';
    const { baseUrl, auth } = await login3xui(server);
    const inboundId = Number(ord.inbound_id || server.inbound_id || 1);
    const email = encodeURIComponent(ord.client_email);
    const gone = d => /not found/i.test(String(d?.msg || ''));

    if (mode === 'delete') {
      // API ใหม่ (อ้างอิงด้วย email) ก่อน ถ้าไม่มีเส้นทางนี้ (404) ค่อยใช้ API รุ่นเก่า
      let x = await post3xui(`${baseUrl}/panel/api/clients/del/${email}`, auth);
      if (x.r.status === 404) {
        x = await post3xui(`${baseUrl}/panel/api/inbounds/${inboundId}/delClient/${encodeURIComponent(ord.client_uuid)}`, auth);
        if (x.r.status === 404) return 'already_gone';
      }
      if (!x.ok) {
        if (gone(x.d)) return 'already_gone';
        throw new HttpErr(502, x.d?.msg || `ลบ Client บน 3x-ui ไม่สำเร็จ (HTTP ${x.r.status})`);
      }
      return 'deleted';
    }

    // disable: อ่าน client เดิมมาแก้เฉพาะ enable/expiry เพื่อไม่ทำให้ subId/flow/limit หาย
    const ib = await fetchInbound(baseUrl, auth, inboundId);
    if (!ib) throw new HttpErr(502, 'อ่านข้อมูล Inbound จาก 3x-ui ไม่ได้');
    const cur = ib.clients.find(x => x.id === ord.client_uuid || x.password === ord.client_uuid || x.email === ord.client_email);
    if (!cur) return 'already_gone';
    if (cur.enable === false) return 'already_disabled';
    let x = await update3xuiClient(baseUrl, auth, { ...cur, enable: false });
    if (x.r.status === 404) {
      x = await post3xui(`${baseUrl}/panel/api/inbounds/updateClient/${encodeURIComponent(ord.client_uuid)}`, auth, {
        id: inboundId,
        settings: JSON.stringify({ clients: [{ ...cur, enable: false }] })
      });
    }
    if (!x.ok) throw new HttpErr(502, x.d?.msg || `ปิด Client บน 3x-ui ไม่สำเร็จ (HTTP ${x.r.status})`);
    return 'disabled';
  }

  if (server.type === 'xxt') {
    const u = needSafeUser(ord.client_email);
    const r = mode === 'delete' ? await xxtCall(server, 'DELETE', `/users/${u}`) : await xxtCall(server, 'POST', `/users/${u}/suspend`);
    if (r.d?.ok) return mode === 'delete' ? 'deleted' : 'disabled';
    if (xxtNotFound(r)) return 'already_gone';
    throw xxtFail(r, mode === 'delete' ? 'ลบบัญชีไม่สำเร็จ' : 'ระงับบัญชีไม่สำเร็จ');
  }

  if (server.type === 'ssh') {
    const u = needSafeUser(ord.client_email);
    if (mode === 'delete') {
      await sshExec(server, `pkill -KILL -u ${u} 2>/dev/null; userdel -f ${u} 2>/dev/null; if id -u ${u} >/dev/null 2>&1; then exit 1; else exit 0; fi`);
      return 'deleted';
    }
    await sshExec(server, `id -u ${u} >/dev/null 2>&1 || exit 0; usermod -L ${u} && chage -E 0 ${u}; rc=$?; pkill -KILL -u ${u} 2>/dev/null; exit $rc`);
    return 'disabled';
  }
  return 'skipped';
}

// ---------- ส่งออก NPV Tunnel / NetMod สำหรับเซิร์ฟเวอร์ SSH ----------
const npvTypeOk = v => (/^[A-Za-z0-9_.+-]{3,40}$/.test(String(v || '').trim()) ? String(v).trim() : 'SSH-Direct');
function sshExportBlock(srv, u, pw, pl) {
  const port = srv.ssh_port || 22;
  const name = `${pl.network}-${u}`;
  const fill = x => String(x || '')
    .replaceAll('{host}', () => srv.host).replaceAll('{ssh_port}', () => String(port)).replaceAll('{port}', () => String(port))
    .replaceAll('{user}', () => u).replaceAll('{pass}', () => pw).replaceAll('{sni}', () => srv.sni || '');
  const payload = fill(srv.payload).trim();
  const proxy = srv.proxy_host ? `${srv.proxy_host}${srv.proxy_port ? ':' + srv.proxy_port : ''}` : '';
  const w = v => (v ? 'npvs1:' + xxtB64(v) : '');
  const o = {
    sshConfigType: w(npvTypeOk(srv.npv_type)), remarks: w(name), sshHost: w(srv.host), sshPort: port,
    sshUsername: w(u), sshPassword: w(pw), sshAuthMethod: w('PASSWORD'), sshPrivateKey: '', sshPrivateKeyPassphrase: '',
    sni: srv.sni || '', tlsVersion: w('DEFAULT'), httpProxy: w(proxy), authenticateProxy: false, proxyUsername: '', proxyPassword: '',
    payload: w(payload), dnsTTMode: w('UDP'), dnsServer: '', nameserver: '', publicKey: '',
    udpgwPort: srv.udpgw_port || 7300, udpgwTransparentDNS: true
  };
  const npv = 'npvt-ssh://' + xxtB64(JSON.stringify(o));
  const nm = `ssh://${encodeURIComponent(u)}:${encodeURIComponent(pw)}@${srv.host}:${port}#${encodeURIComponent(name)}`;
  let out = `\n\nลิงก์ NPV Tunnel:\n${npv}\n\nลิงก์ NetMod:\n${nm}`;
  const extra = [];
  if (payload) extra.push('Payload: ' + payload.replace(/\r?\n/g, '[crlf]'));
  if (proxy) extra.push('Proxy: ' + proxy);
  if (srv.sni) extra.push('SNI: ' + srv.sni);
  if (extra.length) out += '\n\nค่าที่ต้องตั้งเพิ่มใน NetMod / Dark Tunnel:\n' + extra.join('\n');
  return out;
}

async function provisionFromServer(server, pl, username, existingMeta = null) {
  const durMs = planMins(pl) * 60e3;
  const expiryTimeMs = existingMeta?.baseExpiryMs
    ? existingMeta.baseExpiryMs + durMs
    : Date.now() + durMs;

  if (!server) throw new HttpErr(503, 'แพ็กเกจนี้ยังไม่ได้ผูกเซิร์ฟเวอร์ที่เปิดใช้งาน (ระบบไม่ได้หักเครดิต)');

  // กรณี 3x-ui Panel
  if (server.type === '3xui') {
    const { baseUrl, auth } = await login3xui(server);
    const inboundId = Number(pl.inbound_id || server.inbound_id || 1);
    const ib = await fetchInbound(baseUrl, auth, inboundId);
    const realProto = String(ib?.protocol || server.protocol || 'vless').toLowerCase();
    const clientUuid = existingMeta?.clientUuid || crypto.randomUUID();
    const clientEmail = existingMeta?.clientEmail || `np_${username}_${rnd(5)}`;
    // ต่ออายุ: ใช้ค่าเดิมของ client (subId/flow/limit) ไม่สุ่มใหม่
    const prev = existingMeta?.clientUuid
      ? ib?.clients.find(x => x.id === clientUuid || x.password === clientUuid)
      : null;
    const subId = prev?.subId || rnd(12);
    const useVision = realProto === 'vless' && ib && ib.network === 'tcp' && ['tls', 'reality'].includes(ib.security);

    const clientObj = {
      ...(prev || {}),
      id: clientUuid,
      flow: useVision ? 'xtls-rprx-vision' : '',
      email: clientEmail,
      limitIp: prev?.limitIp ?? (Number(pl.max_conns) > 0 ? Number(pl.max_conns) : 2),
      totalGB: prev?.totalGB ?? 0,
      expiryTime: expiryTimeMs,
      enable: true,
      tgId: prev?.tgId ?? '',
      subId
    };
    if (realProto === 'trojan') clientObj.password = clientUuid;

    // API ใหม่ (/panel/api/clients/*): tgId ต้องเป็นตัวเลข
    let x = existingMeta?.clientUuid
      ? await update3xuiClient(baseUrl, auth, clientObj)
      : await post3xui(`${baseUrl}/panel/api/clients/add`, auth,
          { client: { ...clientObj, tgId: 0 }, inboundIds: [inboundId] });

    // 3x-ui รุ่นเก่า (ไม่มีเส้นทางใหม่ → 404)
    if (x.r.status === 404) {
      const endpoint = existingMeta?.clientUuid
        ? `${baseUrl}/panel/api/inbounds/updateClient/${clientUuid}`
        : `${baseUrl}/panel/api/inbounds/addClient`;
      x = await post3xui(endpoint, auth, {
        id: inboundId,
        settings: JSON.stringify({ clients: [clientObj] })
      });
    }

    if (!x.ok) {
      throw new HttpErr(502, x.d?.msg || `สร้าง/ต่ออายุบัญชีบน 3x-ui ไม่สำเร็จ (HTTP ${x.r.status}) (ระบบไม่ได้หักเครดิต)`);
    }

    const link = buildClientLink(server, {
      uuid: clientUuid,
      remark: `${pl.network}-${clientEmail}`
    }, ib);

    return {
      accountText: link,
      clientEmail,
      clientUuid,
      inboundId
    };
  }

  // กรณีแดชบอร์ด XXTLONLINE
  if (server.type === 'xxt') return xxtProvision(server, pl);

  // กรณี SSH / UDP Server หรือ fallback
  const u = existingMeta?.clientEmail || ('np' + rnd(6));
  const pw = rnd(8);
  if (!existingMeta) await sshCreateUser(server, u, pw, expiryTimeMs);
  const host = server.host;
  const sshPort = server.ssh_port || 22;
  const udpPort = server.udp_port || '1-65535';
  const sni = server.sni || '';

  if (server.template && server.template.trim()) {
    const txt = server.template
      .replace(/\{host\}/g, host)
      .replace(/\{user\}/g, u)
      .replace(/\{pass\}/g, pw)
      .replace(/\{ssh_port\}/g, String(sshPort))
      .replace(/\{udp_port\}/g, String(udpPort))
      .replace(/\{sni\}/g, sni)
      .replace(/\{network\}/g, pl.network)
      .replace(/\{protocol\}/g, pl.protocol);
    return { accountText: txt + sshExportBlock(server, u, pw, pl), clientEmail: u, clientUuid: null };
  }

  if (pl.protocol === 'V2RAY') {
    const uid = existingMeta?.clientUuid || crypto.randomUUID();
    return {
      accountText: `vless://${uid}@${host}:443?type=ws&security=tls#${pl.network}-${u}`,
      clientEmail: u,
      clientUuid: uid
    };
  }

  return {
    accountText: `Host: ${host}\nPort: ${pl.protocol === 'UDP' ? udpPort : sshPort}\nUser: ${u}\nPass: ${pw}${sni ? '\nSNI: ' + sni : ''}` + sshExportBlock(server, u, pw, pl),
    clientEmail: u,
    clientUuid: null
  };
}

// ตรวจสลิปอัตโนมัติ (อ่านค่าตั้งค่าจากตาราง settings)
// slip_provider: generic (ส่ง JSON กลาง {proof, amount}) | easyslip | slipok
const EASYSLIP_URL = 'https://api.easyslip.com/v1/verify';
const amountOk = (paid, want) => Number.isFinite(paid) && Math.abs(paid - want) < 0.01;

// ---------- ตรวจบัญชีผู้รับในสลิป (v3.7) ----------
const digitsOf = v => String(v || '').replace(/\D/g, '');
const splitList = v => String(v || '').split(/[\n,]+/).map(x => x.trim()).filter(Boolean);
const normName = v => String(v || '').toLowerCase()
  .replace(/นางสาว|น\.ส\.|นาย|นาง|miss|mrs\.?|mr\.?|ms\.?/g, '')
  .replace(/[\s.\-_]/g, '');

// เลขบัญชีในสลิปถูกปิดบังบางหลัก (เช่น xxx-x-x7890-x) → เทียบเฉพาะหลักที่มองเห็น
function accountMatches(masked, real) {
  const m = String(masked || '').replace(/[^0-9xX*•]/g, '');
  const r = digitsOf(real);
  const visible = m.match(/\d+/g) || [];
  if (!m || !r || !visible.length) return false;
  if (m.length === r.length) {
    return visible.join('').length >= 3 && [...m].every((ch, i) => (/\d/.test(ch) ? ch === r[i] : true));
  }
  const longest = visible.sort((a, b) => b.length - a.length)[0];
  return longest.length >= 4 && r.includes(longest);
}

function extractReceiver(provider, body) {
  const accounts = [];
  const names = [];
  const add = (arr, v) => { if (v && typeof v === 'string') arr.push(v); };
  if (provider === 'easyslip') {
    const a = body.data?.receiver?.account;
    add(accounts, a?.bank?.account); add(accounts, a?.proxy?.account);
    add(names, a?.name?.th); add(names, a?.name?.en);
  } else if (provider === 'slipok') {
    const r = body.data?.receiver;
    add(accounts, r?.account?.value); add(accounts, r?.proxy?.value);
    add(names, r?.displayName); add(names, r?.name);
  } else {
    const r = body.data?.receiver || body.receiver;
    if (typeof r === 'string') add(accounts, r);
    else if (r) {
      add(accounts, r.account); add(accounts, r.accountNo); add(accounts, r.account?.value);
      add(names, r.name); add(names, r.displayName);
    }
  }
  return { accounts, names };
}

function checkReceiver(rcv, st) {
  if (String(st.slip_check_receiver ?? 'true').toLowerCase() !== 'true') return { ok: true };
  const accs = splitList(st.slip_receiver_acc);
  if (!accs.length && digitsOf(st.bankNo)) accs.push(st.bankNo);
  const names = splitList(st.slip_receiver_name).map(normName).filter(Boolean);

  if (!accs.length && !names.length) {
    return { ok: false, note: 'ยังไม่ได้ตั้งเลขบัญชีผู้รับของร้าน (หลังบ้าน → ตั้งค่า API ตรวจสลิป)' };
  }
  if (!rcv.accounts.length && !rcv.names.length) {
    return { ok: false, note: 'API ไม่ส่งข้อมูลผู้รับกลับมา จึงตรวจบัญชีผู้รับไม่ได้ ให้แอดมินเช็กเอง' };
  }
  if (accs.length) {
    if (rcv.accounts.length) {
      if (!rcv.accounts.some(a => accs.some(r => accountMatches(a, r)))) {
        return { ok: false, note: `⚠️ บัญชีผู้รับในสลิป (${rcv.accounts[0]}) ไม่ตรงกับบัญชีร้าน` };
      }
    } else if (!names.length) {
      return { ok: false, note: 'สลิปไม่แสดงเลขบัญชีผู้รับ ตรวจไม่ได้ ให้แอดมินเช็กเอง' };
    }
  }
  if (names.length) {
    const got = rcv.names.map(normName).filter(Boolean);
    if (!got.length) return { ok: false, note: 'สลิปไม่แสดงชื่อผู้รับ ตรวจไม่ได้ ให้แอดมินเช็กเอง' };
    if (!got.some(g => names.some(n => g.includes(n)))) {
      return { ok: false, note: `⚠️ ชื่อผู้รับในสลิป (${rcv.names[0]}) ไม่ตรงกับชื่อบัญชีร้าน` };
    }
  }
  return { ok: true };
}

function judgeSlip(label, paid, amount, rcv, settings, transRef) {
  const amtOk = amountOk(paid, amount);
  const rc = rcv ? checkReceiver(rcv, settings) : { ok: true };
  const valid = amtOk && rc.ok;
  return {
    checked: true, valid, transRef: transRef || null,
    note: valid ? `ตรวจสลิปผ่านอัตโนมัติ (${label})`
      : !amtOk ? `ยอดในสลิป ${paid} ไม่ตรงกับยอดที่แจ้ง ${amount}` : rc.note
  };
}

async function verifySlipAuto(proof, amount) {
  const settings = await getSettingsMap(pool, true);
  const mode = settings.slip_mode || 'manual';
  const provider = String(settings.slip_provider || 'generic').toLowerCase();
  let verifyUrl = (settings.slip_verify_url || '').trim();
  const apiKey = (settings.slip_api_key || '').trim();

  if (provider === 'easyslip' && !verifyUrl) verifyUrl = EASYSLIP_URL;
  if (mode === 'manual' || !verifyUrl) {
    return { checked: false, valid: false, note: 'รอแอดมินตรวจสอบสลิป' };
  }

  const m = /^data:(image\/[a-z]+);base64,(.+)$/i.exec(String(proof));
  const mime = m ? m[1] : 'image/jpeg';
  const b64 = m ? m[2] : '';

  try {
    // ---- EasySlip v1: POST JSON {image: base64, checkDuplicate}, Authorization: Bearer ----
    if (provider === 'easyslip') {
      const call = async img => {
        const r = await xfetch(verifyUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + apiKey },
          body: JSON.stringify({ image: img, checkDuplicate: true })
        });
        return { r, body: await r.json().catch(() => ({})) };
      };
      // ส่งแบบมี data URI ก่อน (EasySlip ใช้เดาชนิดไฟล์) ถ้าโดน 400/invalid_image ลองอีกครั้งแบบ base64 ล้วน
      let { r, body } = await call(String(proof));
      if ((!r.ok || body.status !== 200) && b64 && (r.status === 400 || /invalid_image/i.test(String(body.message || '')))) {
        ({ r, body } = await call(b64));
      }
      if (!r.ok || body.status !== 200 || !body.data) {
        const why = body.message || body.error || (Object.keys(body).length ? JSON.stringify(body).slice(0, 160) : '') || '';
        return { checked: true, valid: false, note: `EasySlip: ${why || 'ไม่มีข้อความจาก API'} (HTTP ${r.status})` };
      }
      const paid = Number(body.data.amount?.amount);
      return judgeSlip('EasySlip', paid, amount, extractReceiver('easyslip', body), settings, body.data.transRef);
    }

    // ---- SlipOK: POST multipart (files, amount, log), header x-authorization ----
    // verifyUrl = https://api.slipok.com/api/line/apikey/<BRANCH_ID>
    if (provider === 'slipok') {
      const fd = new FormData();
      fd.append('files', new Blob([Buffer.from(b64, 'base64')], { type: mime }), 'slip.' + (mime.split('/')[1] || 'jpg'));
      fd.append('amount', String(amount));
      fd.append('log', 'true');
      const r = await xfetch(verifyUrl, { method: 'POST', headers: { 'x-authorization': apiKey }, body: fd });
      const body = await r.json().catch(() => ({}));
      if (!r.ok || body.success !== true || body.data?.success === false) {
        return { checked: true, valid: false, note: 'SlipOK: ' + (body.message || `HTTP ${r.status}`) };
      }
      const paid = body.data?.amount !== undefined ? Number(body.data.amount) : amount;
      return judgeSlip('SlipOK', paid, amount, extractReceiver('slipok', body), settings, body.data?.transRef);
    }

    // ---- generic: JSON กลาง ----
    const r = await xfetch(verifyUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(apiKey ? { Authorization: 'Bearer ' + apiKey, 'x-api-key': apiKey } : {})
      },
      body: JSON.stringify({ proof, amount })
    });
    const body = await r.json().catch(() => ({}));
    if (!r.ok) {
      return { checked: true, valid: false, note: body.message || `API ตรวจสลิปตอบกลับ ${r.status}` };
    }
    const apiValid = Boolean(body.valid === true || body.success === true || body.data?.valid === true);
    const transRef = body.data?.transRef || body.transRef || null;
    // API กำหนดเอง: ตรวจบัญชีผู้รับเฉพาะเมื่อ API ส่งข้อมูล receiver กลับมา (ถ้าไม่ส่ง ถือว่า API ตรวจให้แล้ว)
    const rcv = extractReceiver('generic', body);
    if (apiValid && (rcv.accounts.length || rcv.names.length)) {
      const rc = checkReceiver(rcv, settings);
      if (!rc.ok) return { checked: true, valid: false, transRef, note: rc.note };
    }
    return {
      checked: true,
      valid: apiValid,
      transRef,
      note: body.message || (apiValid ? 'ตรวจสอบสลิปผ่านอัตโนมัติ' : 'ยอดเงินหรือสลิปไม่ตรงเงื่อนไข')
    };
  } catch (e) {
    return { checked: true, valid: false, note: 'เชื่อมต่อ API ตรวจสลิปไม่ได้: ' + e.message };
  }
}

// ส่วนลดรายแพ็กเกจ (%) ตั้งที่หลังบ้าน → จัดการแพ็กเกจ (คอลัมน์ที่ 5 ของแต่ละราคา) ใช้กับซื้อใหม่/ต่ออายุ เฉพาะแพ็กเกจที่ตั้งไว้
const planPct = (price, pct) => (+price > 0 ? Math.max(0, Math.min(90, parseFloat(pct) || 0)) : 0);
const applyPct = (price, pct) => Math.round(price * (100 - pct)) / 100;

async function catalog() {
  const p = (await pool.query(`
    SELECT p.*, s.name AS server_name, s.type AS server_type, s.is_active AS server_active, s.last_status AS server_status
    FROM products p
    LEFT JOIN vps_servers s ON s.id = p.server_id
    WHERE NOT p.is_hidden
    ORDER BY p.id
  `)).rows;
  const pl = (await pool.query('SELECT * FROM plans ORDER BY price,id')).rows;
  const rv = (await pool.query(`
    SELECT r.id, r.product_id, r.rating, r.comment, r.created_at, u.username
    FROM reviews r JOIN users u ON u.id = r.user_id
    ORDER BY r.id DESC LIMIT 200
  `)).rows;

  return p.map(x => {
    const prodReviews = rv.filter(k => k.product_id === x.id);
    const avg = prodReviews.length
      ? +(prodReviews.reduce((acc, item) => acc + Number(item.rating), 0) / prodReviews.length).toFixed(1)
      : null;
    return {
      id: x.id,
      serverId: x.server_id,
      serverName: x.server_name || '',
      serverType: x.server_type || '',
      // เซิร์ฟเวอร์ปิด/ออฟไลน์ (ตัวเช็กเป็นระยะพบว่าเชื่อมต่อไม่ได้) → หน้าร้านซ่อน ไม่ให้ซื้อ
      offline: Boolean(x.server_id) && (x.server_active === false || x.server_status === 'error'),
      inboundId: x.inbound_id || null,
      xxtProfile: x.xxt_profile || null,
      net: x.network,
      proto: x.protocol,
      title: x.title,
      desc: x.description || '',
      img: x.image_url || '',
      badge: x.badge || '',
      ratingAvg: avg,
      ratingCount: prodReviews.length,
      reviews: prodReviews.slice(0, 10).map(k => ({
        id: k.id,
        user: k.username,
        rating: k.rating,
        comment: k.comment,
        at: k.created_at
      })),
      plans: pl
        .filter(k => k.product_id === x.id)
        .map(k => { const dp = planPct(k.price, k.discount_percent); return { id: k.id, n: k.name, d: fmtDurM(k), hours: k.duration_hours, mins: planMins(k), mc: k.max_conns || null, p: dp > 0 ? applyPct(+k.price, dp) : +k.price, op: dp > 0 ? +k.price : undefined, off: dp }; })
    };
  });
}

// ---------- app ----------
const app = express();
if (PROD) app.set('trust proxy', 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", 'https://challenges.cloudflare.com'],
      frameSrc: ['https://challenges.cloudflare.com'],
      scriptSrcAttr: ["'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ['https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'", 'https://challenges.cloudflare.com'],
      upgradeInsecureRequests: PROD ? [] : null
    }
  }
}));

app.use(express.json({ limit: '12mb' }), cookieParser());
app.use('/api', rateLimit({ windowMs: 15 * 60e3, limit: 600, skip: q => q.path === '/me/unread' }));   // /me/unread มีลิมิตแยก (หน้าเว็บเช็กทุก ~5 วินาที)
const unreadLimit = rateLimit({ windowMs: 60e3, limit: 40, message: { error: 'ลองบ่อยเกินไป รอสักครู่' } });
const authLimit = rateLimit({ windowMs: 60e3, limit: 10, message: { error: 'ลองบ่อยเกินไป รอสักครู่' } });
const w = f => (q, s, n) => f(q, s, n).catch(n);

const setCookie = (s, id) => s.cookie('tk', jwt.sign({ id }, JWT_SECRET, { expiresIn: '7d' }), {
  httpOnly: true,
  sameSite: 'strict',
  secure: PROD,
  maxAge: 7 * 864e5
});

const loadUser = w(async (q, s, n) => {
  try {
    const { id, iat } = jwt.verify(q.cookies.tk || '', JWT_SECRET);
    const u = (await pool.query(
      'SELECT id,username,role,is_banned,referral_code,(recovery_hash IS NOT NULL) AS has_recovery,totp_enabled,pw_changed_at FROM users WHERE id=$1', [id]
    )).rows[0] || null;
    // เปลี่ยน/รีเซ็ตรหัสผ่านแล้ว โทเคนเก่า (ที่ออกก่อนหน้า) ใช้ไม่ได้
    const stale = u && u.pw_changed_at && iat < Math.floor(new Date(u.pw_changed_at).getTime() / 1000);
    q.user = stale ? null : u;
  } catch {
    q.user = null;
  }
  n();
});

app.use(loadUser);
const need = (q, s, n) => {
  if (!q.user) return s.status(401).json({ error: 'กรุณาเข้าสู่ระบบ' });
  if (q.user.is_banned) return s.status(403).json({ error: 'บัญชีนี้ถูกระงับการใช้งาน กรุณาติดต่อแอดมิน' });
  n();
};
const adm = (q, s, n) => q.user.role === 'admin' ? n() : s.status(403).json({ error: 'เฉพาะแอดมิน' });

// ---------- public ----------
app.get('/api/health', w(async (q, s) => {
  await pool.query('SELECT 1');
  const srvCount = +(await pool.query('SELECT count(*) FROM vps_servers WHERE is_active')).rows[0].count;
  s.json({ status: 'ok', time: new Date(), activeServers: srvCount });
}));


// รูปโฆษณา (โปสเตอร์ + ด้านล่าง) เก็บเป็น data URL ในตาราง settings — ไม่ส่งยัดไปใน JSON ของ /api/site
// แต่ให้โหลดเป็นรูปแยกผ่าน /media/ad/:key (แคชได้ ?v= เปลี่ยนเมื่อเปลี่ยนรูป) เว็บจะได้ไม่หนักเมื่อมีรูปเยอะ
const AD_MEDIA_RE = /^(ad_m?img[1-3]|ab_img(?:10|[1-9]))$/;
function adMediaUrls(map) {
  for (const k of Object.keys(map)) {
    if (!AD_MEDIA_RE.test(k)) continue;
    const v = map[k];
    if (!v) { delete map[k]; continue; }
    if (/^data:image\//.test(v)) map[k] = `/media/ad/${k}?v=` + crypto.createHash('md5').update(v).digest('hex').slice(0, 10);
  }
  return map;
}
app.get('/media/ad/:key', w(async (q, s) => {
  if (!AD_MEDIA_RE.test(q.params.key)) return s.status(404).end();
  const r = await pool.query('SELECT value FROM settings WHERE key=$1 AND NOT is_secret', [q.params.key]);
  const m = /^data:(image\/(?:jpeg|png|webp|gif));base64,([\s\S]+)$/.exec((r.rows[0] || {}).value || '');
  if (!m) return s.status(404).end();
  s.set({ 'Content-Type': m[1], 'Cache-Control': 'public, max-age=31536000, immutable', 'X-Content-Type-Options': 'nosniff' });
  s.end(Buffer.from(m[2], 'base64'));
}));

app.get('/api/site', w(async (q, s) => {
  const site = await getSettingsMap(pool, false);
  ['slip_verify_url', 'slip_auto_approve', 'slip_mode', 'slip_provider', 'slip_check_receiver', 'slip_receiver_acc', 'slip_receiver_name'].forEach(k => delete site[k]);
  Object.keys(site).forEach(k => { if (k.startsWith('perf_')) delete site[k]; });
  adMediaUrls(site);
  if (!site.turnstile_site_key && process.env.TURNSTILE_SITE_KEY) site.turnstile_site_key = process.env.TURNSTILE_SITE_KEY.trim();
  // ส่ง site key ให้หน้าเว็บก็ต่อเมื่อมี secret คู่กัน (ไม่งั้นปิดไว้)
  if (!(await turnstileConf()).secret) delete site.turnstile_site_key;
  const members = +(await pool.query('SELECT count(*) FROM users')).rows[0].count;
  const activeServers = +(await pool.query('SELECT count(*) FROM vps_servers WHERE is_active')).rows[0].count;
  s.json({ site, products: await catalog(), members, activeServers });
}));

// ---------- auth ----------
const DUMMY = bcrypt.hashSync('x', 10);
// ---------- 2FA (TOTP, เข้ากันได้กับ Google Authenticator / Authy) สำหรับแอดมิน ----------
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
const b32enc = buf => { let bits = '', out = ''; for (const x of buf) bits += x.toString(2).padStart(8, '0');
  for (let i = 0; i < bits.length; i += 5) out += B32[parseInt(bits.slice(i, i + 5).padEnd(5, '0'), 2)]; return out; };
const b32dec = str => { let bits = ''; for (const ch of str.replace(/=+$/, '').toUpperCase()) bits += B32.indexOf(ch).toString(2).padStart(5, '0');
  const out = []; for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2)); return Buffer.from(out); };
function totpAt(secretB32, step) {
  const msg = Buffer.alloc(8); msg.writeBigUInt64BE(BigInt(step));
  const h = crypto.createHmac('sha1', b32dec(secretB32)).update(msg).digest();
  const o = h[h.length - 1] & 15;
  return String((h.readUInt32BE(o) & 0x7fffffff) % 1e6).padStart(6, '0');
}
function totpOk(secretB32, code) {
  const c = String(code || '').replace(/\s/g, '');
  if (!/^\d{6}$/.test(c)) return false;
  const now = Math.floor(Date.now() / 30000);
  return [-1, 0, 1].some(d => totpAt(secretB32, now + d) === c);
}

// รหัสกู้คืนบัญชี 16 ตัว (XXXX-XXXX-XXXX-XXXX) ใช้ตั้งรหัสผ่านใหม่เองเมื่อลืมรหัส (ใช้ได้ครั้งเดียว)
const genRecoveryCode = () => rnd(16).toUpperCase().replace(/(.{4})(?=.)/g, '$1-');
const normRecovery = v => String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const MIN_PW = 6;
const checkNewPassword = p => { if (String(p || '').length < MIN_PW) throw new HttpErr(400, `รหัสผ่านใหม่ต้องยาวอย่างน้อย ${MIN_PW} ตัวอักษร`); };

// ---------- Cloudflare Turnstile (กันบอทสมัครสมาชิก) ----------
// ตั้งค่าได้ที่หลังบ้าน → ตั้งค่าเว็บไซต์ หรือใน .env (TURNSTILE_SITE_KEY / TURNSTILE_SECRET_KEY)
// ถ้ายังไม่ตั้งทั้งสองค่า = ปิดใช้งาน (สมัครได้ตามปกติ)
async function turnstileConf() {
  const st = await getSettingsMap(pool, true);
  return {
    siteKey: (st.turnstile_site_key || process.env.TURNSTILE_SITE_KEY || '').trim(),
    secret: (st.turnstile_secret || process.env.TURNSTILE_SECRET_KEY || '').trim()
  };
}
async function verifyTurnstile(token, ip) {
  const { siteKey, secret } = await turnstileConf();
  if (!siteKey || !secret) return;               // ยังไม่เปิดใช้
  token = String(token || '').trim();
  if (!token) throw new HttpErr(400, 'กรุณายืนยันว่าไม่ใช่บอท (Cloudflare) ก่อนสมัครสมาชิก');
  let ok = false;
  try {
    const body = new URLSearchParams({ secret, response: token });
    if (ip) body.set('remoteip', ip);
    const r = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST', body, signal: AbortSignal.timeout(8000)
    });
    ok = !!(await r.json()).success;
  } catch (e) {
    console.error('turnstile', e.message);
    throw new HttpErr(503, 'ตรวจสอบ Cloudflare ไม่สำเร็จ ลองใหม่อีกครั้ง');
  }
  if (!ok) throw new HttpErr(400, 'การยืนยัน Cloudflare ไม่ผ่านหรือหมดอายุ กรุณาลองใหม่');
}

app.post('/api/register', authLimit, w(async (q, s) => {
  const u = String(q.body.username || '').trim();
  const p = String(q.body.password || '');
  const p2 = String(q.body.password2 ?? '');
  const refCode = String(q.body.referralCode || '').trim().toUpperCase();

  if (!/^[A-Za-z0-9_.-]{3,30}$/.test(u)) throw new HttpErr(400, 'ชื่อผู้ใช้ 3-30 ตัว ใช้ได้เฉพาะ a-z 0-9 _ . -');
  if (p.length < MIN_PW) throw new HttpErr(400, `รหัสผ่านต้องยาวอย่างน้อย ${MIN_PW} ตัวอักษร`);
  if (p !== p2) throw new HttpErr(400, 'ยืนยันรหัสผ่านไม่ตรงกัน');
  await verifyTurnstile(q.body.cfToken, q.ip);

  const role = ADMIN_USERNAME && u === ADMIN_USERNAME ? 'admin' : 'user';
  const myRefCode = genRefCode();
  const recoveryCode = genRecoveryCode();
  const recoveryHash = await bcrypt.hash(normRecovery(recoveryCode), 10);

  const newUser = await tx(async c => {
    let referrerId = null;
    if (refCode) {
      const refRow = (await c.query('SELECT id FROM users WHERE referral_code=$1', [refCode])).rows[0];
      if (!refRow) throw new HttpErr(400, 'ไม่พบรหัสแนะนำเพื่อนนี้');
      referrerId = refRow.id;
    }
    try {
      const r = await c.query(
        'INSERT INTO users(username,password_hash,role,referral_code,referred_by,recovery_hash) VALUES($1,$2,$3,$4,$5,$6) RETURNING id',
        [u, await bcrypt.hash(p, 12), role, myRefCode, referrerId, recoveryHash]
      );
      return r.rows[0];
    } catch (e) {
      throw e.code === '23505' ? new HttpErr(409, 'ชื่อผู้ใช้นี้ถูกใช้แล้ว') : e;
    }
  });

  setCookie(s, newUser.id);
  audit(newUser.id, 'register', { referredBy: refCode || null }, q.ip);
  s.json({ ok: true, recoveryCode });
}));

app.post('/api/login', authLimit, w(async (q, s) => {
  const r = (await pool.query('SELECT id,password_hash,is_banned,totp_enabled,totp_secret_enc FROM users WHERE username=$1', [String(q.body.username || '')])).rows[0];
  const ok = await bcrypt.compare(String(q.body.password || ''), r ? r.password_hash : DUMMY);
  if (!r || !ok) {
    audit(null, 'login_fail', { u: String(q.body.username || '').slice(0, 30) }, q.ip);
    throw new HttpErr(401, 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง');
  }
  if (r.is_banned) throw new HttpErr(403, 'บัญชีนี้ถูกระงับการใช้งาน');
  if (r.totp_enabled) {
    if (!String(q.body.totp || '').trim()) return s.status(401).json({ error: 'กรุณากรอกรหัส 2FA 6 หลัก', need2fa: true });
    if (!totpOk(dec(r.totp_secret_enc), q.body.totp)) {
      audit(r.id, 'login_2fa_fail', null, q.ip);
      return s.status(401).json({ error: 'รหัส 2FA ไม่ถูกต้อง', need2fa: true });
    }
  }
  setCookie(s, r.id);
  s.json({ ok: true });
}));

// เปลี่ยนรหัสผ่านเอง (ต้องใส่รหัสเดิม) — เซสชันเก่าทั้งหมดจะถูกตัดออก ยกเว้นเครื่องนี้
app.post('/api/me/password', need, authLimit, w(async (q, s) => {
  const cur = String(q.body.current || '');
  const next = String(q.body.next || '');
  checkNewPassword(next);
  const r = (await pool.query('SELECT password_hash FROM users WHERE id=$1', [q.user.id])).rows[0];
  if (!r || !(await bcrypt.compare(cur, r.password_hash))) throw new HttpErr(400, 'รหัสผ่านปัจจุบันไม่ถูกต้อง');
  if (next === cur) throw new HttpErr(400, 'รหัสผ่านใหม่ต้องไม่ซ้ำกับรหัสเดิม');
  await pool.query('UPDATE users SET password_hash=$2, pw_changed_at=now() WHERE id=$1', [q.user.id, await bcrypt.hash(next, 12)]);
  setCookie(s, q.user.id);
  audit(q.user.id, 'password_change', null, q.ip);
  s.json({ ok: true });
}));

// สร้างรหัสกู้คืนใหม่ (ของเก่าใช้ไม่ได้ทันที) — แสดงครั้งเดียว
app.post('/api/me/recovery', need, authLimit, w(async (q, s) => {
  const r = (await pool.query('SELECT password_hash FROM users WHERE id=$1', [q.user.id])).rows[0];
  if (!r || !(await bcrypt.compare(String(q.body.password || ''), r.password_hash))) throw new HttpErr(400, 'รหัสผ่านไม่ถูกต้อง');
  const code = genRecoveryCode();
  await pool.query('UPDATE users SET recovery_hash=$2 WHERE id=$1', [q.user.id, await bcrypt.hash(normRecovery(code), 10)]);
  audit(q.user.id, 'recovery_regen', null, q.ip);
  s.json({ ok: true, recoveryCode: code });
}));

// ลืมรหัสผ่าน: ชื่อผู้ใช้ + รหัสกู้คืน + รหัสผ่านใหม่ (รหัสกู้คืนใช้ได้ครั้งเดียว ต้องสร้างใหม่หลังใช้)
app.post('/api/forgot', authLimit, w(async (q, s) => {
  const u = String(q.body.username || '').trim();
  const next = String(q.body.newPassword || '');
  checkNewPassword(next);
  const r = (await pool.query('SELECT id, recovery_hash FROM users WHERE username=$1', [u])).rows[0];
  const ok = await bcrypt.compare(normRecovery(q.body.recoveryCode), r && r.recovery_hash ? r.recovery_hash : DUMMY);
  if (!r || !r.recovery_hash || !ok) {
    audit(null, 'forgot_fail', { u: u.slice(0, 30) }, q.ip);
    throw new HttpErr(400, 'ชื่อผู้ใช้หรือรหัสกู้คืนไม่ถูกต้อง (ถ้าไม่มีรหัสกู้คืน ให้ติดต่อแอดมินเพื่อรีเซ็ต)');
  }
  // ใช้ WHERE recovery_hash = ... กันใช้รหัสเดียวซ้อนกันสองคำขอ
  const up = await pool.query(
    'UPDATE users SET password_hash=$2, pw_changed_at=now(), recovery_hash=NULL WHERE id=$1 AND recovery_hash=$3',
    [r.id, await bcrypt.hash(next, 12), r.recovery_hash]
  );
  if (!up.rowCount) throw new HttpErr(409, 'รหัสกู้คืนนี้ถูกใช้ไปแล้ว');
  audit(r.id, 'password_reset_recovery', null, q.ip);
  s.json({ ok: true });
}));

app.post('/api/logout', (q, s) => {
  s.clearCookie('tk');
  s.json({ ok: true });
});

// ไฟล์ที่หมดอายุจะถูกลบอัตโนมัติหลังหมดอายุกี่ชั่วโมง (ค่าเริ่มต้น 72 ชม.)
const EXPIRED_KEEP_HOURS = Math.max(1, Number(process.env.EXPIRED_KEEP_HOURS) || 72);

app.get('/api/me', w(async (q, s) => {
  if (!q.user) return s.json({ user: null });

  let refCode = q.user.referral_code;
  if (!refCode) {
    refCode = genRefCode();
    await pool.query('UPDATE users SET referral_code=$1 WHERE id=$2', [refCode, q.user.id]);
  }

  const refCount = +(await pool.query('SELECT count(*) FROM users WHERE referred_by=$1', [q.user.id])).rows[0].count;
  const o = (await pool.query(`
    SELECT o.id, o.plan_id, o.price_paid, o.account_data, o.expires_at, o.status, o.created_at, o.auto_renew, o.conn_block_until, pl.max_conns,
           p.id AS product_id, p.title, p.network, p.protocol, pl.name, pl.duration_hours, pl.duration_minutes, pl.price AS plan_price, pl.discount_percent AS plan_discount
    FROM orders o
    JOIN plans pl ON pl.id = o.plan_id
    JOIN products p ON p.id = pl.product_id
    WHERE o.user_id = $1 AND o.purged_at IS NULL
    ORDER BY o.id DESC LIMIT 100
  `, [q.user.id])).rows;

  const tickets = (await pool.query(`
    SELECT t.id, t.order_id, t.subject, t.message, t.reply, t.status, t.created_at, t.updated_at,
           (${TK_UNREAD_SQL}) AS unread
    FROM support_tickets t
    WHERE t.user_id = $1
    ORDER BY t.id DESC LIMIT 50
  `, [q.user.id])).rows;
  await attachTicketMessages(tickets);
  const unreadTickets = tickets.filter(t => t.unread).length;

  const topups = (await pool.query(`
    SELECT id, method, amount, bonus_amount, status, verified_by, verify_note, created_at
    FROM topups
    WHERE user_id = $1
    ORDER BY id DESC LIMIT 50
  `, [q.user.id])).rows;

  s.json({
    user: { id: q.user.id, username: q.user.username, role: q.user.role, is_banned: q.user.is_banned, has_recovery: q.user.has_recovery, totp_enabled: q.user.totp_enabled, referral_code: refCode, referral_count: refCount },
    credit: await balanceOf(q.user.id),
    orders: o.map(x => ({
      id: x.id,
      planId: x.plan_id,
      productId: x.product_id,
      t: x.created_at,
      n: x.title + ' – ' + x.name,
      net: x.network,
      proto: x.protocol,
      hours: x.duration_hours,
      mins: planMins(x),
      planPrice: applyPct(+x.plan_price, planPct(x.plan_price, x.plan_discount)),
      p: +x.price_paid,
      exp: x.expires_at,
      status: x.status,
      autoRenew: x.auto_renew,
      purgeAt: x.status === 'expired' ? new Date(new Date(x.expires_at).getTime() + EXPIRED_KEEP_HOURS * 3600e3).toISOString() : null,
      keepHours: EXPIRED_KEEP_HOURS,
      blockUntil: x.conn_block_until && new Date(x.conn_block_until) > new Date() ? x.conn_block_until : null,
      maxConns: x.max_conns || null,
      blockMinutes: connCfg.block_minutes,
      a: dec(x.account_data)
    })),
    tickets,
    unreadTickets,
    topups
  });
}));

// ---------- ซัพพอร์ต: ข้อความโต้ตอบหลายรอบ (ticket_messages) ----------
// ยังไม่อ่าน = มีข้อความจากแอดมินใหม่กว่าเวลาที่ลูกค้าเปิดอ่านล่าสุด
const TK_UNREAD_SQL = `EXISTS (SELECT 1 FROM ticket_messages m WHERE m.ticket_id = t.id AND m.sender = 'admin'
  AND (t.user_read_at IS NULL OR m.created_at > t.user_read_at))`;
const TK_MAX_MSGS = 200;
async function attachTicketMessages(tickets) {
  if (!tickets.length) return tickets;
  const rows = (await pool.query(
    'SELECT ticket_id, sender, body, created_at FROM ticket_messages WHERE ticket_id = ANY($1::bigint[]) ORDER BY id',
    [tickets.map(t => t.id)])).rows;
  const by = new Map();
  for (const r of rows) { if (!by.has(String(r.ticket_id))) by.set(String(r.ticket_id), []); by.get(String(r.ticket_id)).push({ sender: r.sender, body: r.body, created_at: r.created_at }); }
  for (const t of tickets) t.messages = by.get(String(t.id)) || [];
  return tickets;
}

// ---------- แจ้งเตือนเมื่อแอดมินตอบกลับซัพพอร์ต ----------
async function countUnreadTickets(userId) {
  return +(await pool.query(
    `SELECT count(*) FROM support_tickets t WHERE t.user_id=$1 AND (${TK_UNREAD_SQL})`, [userId])).rows[0].count;
}
app.get('/api/me/unread', need, unreadLimit, w(async (q, s) => {
  s.set('Cache-Control', 'no-store');
  s.json({ unread: await countUnreadTickets(q.user.id), poll_ms: perfPollNow(await perfLoad()) });
}));
app.post('/api/tickets/read', need, w(async (q, s) => {
  await pool.query(
    `UPDATE support_tickets t SET user_read_at = now()
     WHERE t.user_id=$1 AND (${TK_UNREAD_SQL})`, [q.user.id]);
  s.json({ ok: true, unread: 0 });
}));

// ---------- user actions ----------
async function approveTopupInTx(c, topupId, actorType, adminId) {
  const t = (await c.query(`
    UPDATE topups
    SET status = 'approved', verified_by = $2
    WHERE id = $1 AND status = 'pending'
    RETURNING id, user_id, method, amount, bonus_amount
  `, [topupId, actorType])).rows[0];

  if (!t) throw new HttpErr(409, 'รายการนี้ถูกจัดการไปแล้ว');

  await c.query(
    "INSERT INTO credit_ledger(user_id,amount,type,ref_id,note) VALUES($1,$2,'topup',$3,$4)",
    [t.user_id, t.amount, t.id, `เติมเงินผ่าน ${t.method} (${actorType})`]
  );

  if (+t.bonus_amount > 0) {
    await c.query(
      "INSERT INTO credit_ledger(user_id,amount,type,ref_id,note) VALUES($1,$2,'bonus',$3,$4)",
      [t.user_id, t.bonus_amount, t.id, 'โบนัสเติมเงิน']
    );
  }

  const uRow = (await c.query(
    'SELECT id, username, referred_by, referral_rewarded FROM users WHERE id=$1 FOR UPDATE',
    [t.user_id]
  )).rows[0];

  if (uRow && uRow.referred_by && !uRow.referral_rewarded) {
    const settings = await getSettingsMap(c, false);
    const refReward = Math.max(0, parseFloat(settings.referral_reward || '0') || 0);
    if (refReward > 0) {
      await c.query(
        "INSERT INTO credit_ledger(user_id,amount,type,ref_id,note) VALUES($1,$2,'referral',$3,$4)",
        [uRow.referred_by, refReward, t.id, `โบนัสแนะนำเพื่อน (${uRow.username})`]
      );
    }
    await c.query('UPDATE users SET referral_rewarded = TRUE WHERE id=$1', [uRow.id]);
  }

  if (adminId) {
    audit(adminId, 'topup_approve', { id: t.id, amount: +t.amount, bonus: +t.bonus_amount }, null);
  }
  return t;
}

app.post('/api/topup', need, w(async (q, s) => {
  const { method, proof } = q.body;
  const amount = Math.round(parseFloat(q.body.amount) * 100) / 100;
  const settings = await getSettingsMap(pool, false);
  const minTopup = Math.max(1, parseFloat(settings.min_topup_amount || '20') || 20);

  if (!['bank', 'truemoney'].includes(method)) throw new HttpErr(400, 'วิธีเติมเงินไม่ถูกต้อง');
  if (!(amount >= minTopup && amount <= 100000)) {
    throw new HttpErr(400, `ยอดเติมเงินขั้นต่ำ ${minTopup} บาท (สูงสุด 100,000 บาท)`);
  }
  if (typeof proof !== 'string' || !proof) throw new HttpErr(400, 'กรุณาแนบสลิปหรือลิงก์');
  if (method === 'bank' && !/^data:image\/(jpeg|png|webp);base64,/.test(proof)) {
    throw new HttpErr(400, 'ไฟล์สลิปต้องเป็นรูปภาพ');
  }
  if (method === 'truemoney' && !/^https:\/\/gift\.truemoney\.com\//.test(proof)) {
    throw new HttpErr(400, 'ลิงก์ซองอั่งเปาไม่ถูกต้อง');
  }

  const hash = crypto
    .createHash('sha256')
    .update(method === 'bank' ? Buffer.from(proof.split(',')[1], 'base64') : proof)
    .digest('hex');

  const bonusMin = Math.max(0, parseFloat(settings.bonus_min_amount || '0') || 0);
  const bonusPct = Math.max(0, Math.min(100, parseFloat(settings.bonus_percent || '0') || 0));
  const bonusAmount = bonusPct > 0 && amount >= bonusMin
    ? Math.round(amount * bonusPct) / 100
    : 0;

  let autoRes = { checked: false, valid: false, note: '' };
  if (method === 'bank') {
    autoRes = await verifySlipAuto(proof, amount);
  }

  const shouldAutoApprove =
    method === 'bank' &&
    String(settings.slip_auto_approve).toLowerCase() === 'true' &&
    autoRes.checked &&
    autoRes.valid;

  let topupId;
  try {
    const ins = await pool.query(
      'INSERT INTO topups(user_id,method,amount,bonus_amount,slip_hash,proof,verify_note,trans_ref) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id',
      [q.user.id, method, amount, bonusAmount, hash, proof, autoRes.note || null, autoRes.transRef || null]
    );
    topupId = ins.rows[0].id;
  } catch (e) {
    throw e.code === '23505' ? new HttpErr(409, 'สลิป/ซองนี้เคยถูกใช้แล้ว') : e;
  }

  if (shouldAutoApprove) {
    await tx(c => approveTopupInTx(c, topupId, 'auto', null));
    audit(q.user.id, 'topup_auto_approved', { topupId, amount, bonusAmount }, q.ip);
    return s.json({ ok: true, autoApproved: true, bonusAmount, credit: await balanceOf(q.user.id) });
  }

  audit(q.user.id, 'topup_request', { topupId, amount, bonusAmount, method, autoNote: autoRes.note }, q.ip);
  await notifyExternal(`🔔 มีคำขอเติมเงินใหม่ #${topupId} โดย ${q.user.username} จำนวน ${amount.toFixed(2)} บาท (${method})`);
  s.json({ ok: true, autoApproved: false, bonusAmount, verifyNote: autoRes.note || '' });
}));

const buyLimit = rateLimit({ windowMs: 60e3, limit: 8, message: { error: 'สั่งซื้อบ่อยเกินไป รอสักครู่แล้วลองใหม่' } });
app.post('/api/buy', need, buyLimit, w(async (q, s) => {
  const code = String(q.body.coupon || '').trim().toUpperCase();
  const out = await tx(async c => {
    const pl = (await c.query(`
      SELECT pl.*, p.network, p.protocol, p.title, p.server_id, p.inbound_id, p.xxt_profile
      FROM plans pl JOIN products p ON p.id = pl.product_id
      WHERE pl.id = $1 AND NOT p.is_hidden
    `, [parseInt(q.body.planId, 10) || 0])).rows[0];
    if (!pl) throw new HttpErr(404, 'ไม่พบแพ็กเกจ');

    if (+pl.price === 0) await assertTrialAvailable(c, q.user.id);
    const dpct = planPct(pl.price, pl.discount_percent);
    let price = applyPct(+pl.price, dpct);
    let cid = null;
    if (code) {
      const cp = (await c.query(`
        SELECT * FROM coupons
        WHERE code = $1 AND remaining_uses > 0 AND (expires_at IS NULL OR expires_at > now())
        FOR UPDATE
      `, [code])).rows[0];
      if (!cp) throw new HttpErr(400, 'โค้ดส่วนลดไม่ถูกต้องหรือหมดอายุ');
      if (cp.per_user_limit > 0 && (await couponUsedBy(c, cp.id, q.user.id)) >= cp.per_user_limit) {
        throw new HttpErr(400, COUPON_LIMIT_MSG);
      }
      price = applyPct(price, +cp.percent);
      cid = cp.id;
      await c.query('UPDATE coupons SET remaining_uses = remaining_uses - 1 WHERE id = $1', [cid]);
    }

    const bal = +(await c.query('SELECT credit_balance FROM users WHERE id = $1 FOR UPDATE', [q.user.id])).rows[0].credit_balance;
    if (bal < price) {
      throw new HttpErr(400, `เครดิตไม่พอ ต้องใช้ ${price} บาท เหลือ ${bal.toFixed(2)} บาท กรุณาเติมเงินก่อน`);
    }

    let server = null;
    if (pl.server_id) {
      server = (await c.query('SELECT * FROM vps_servers WHERE id = $1 AND is_active', [pl.server_id])).rows[0] || null;
      if (!server || server.last_status === 'error') {
        throw new HttpErr(503, 'เซิร์ฟเวอร์ของแพ็กเกจนี้ปิดปรับปรุงชั่วคราว ยังไม่ตัดเครดิต กรุณาเลือกแพ็กเกจอื่นหรือลองใหม่ภายหลัง');
      }
    }

    const prov = await provisionFromServer(server, pl, q.user.username);
    const o = (await c.query(`
      INSERT INTO orders(user_id,plan_id,server_id,client_email,client_uuid,price_paid,coupon_id,account_data,expires_at,inbound_id)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,now() + make_interval(mins => $9),$10)
      RETURNING id, expires_at
    `, [q.user.id, pl.id, server ? server.id : null, prov.clientEmail, prov.clientUuid, price, cid, enc(prov.accountText), planMins(pl), prov.inboundId ?? null])).rows[0];

    if (price > 0) {
      await c.query(
        "INSERT INTO credit_ledger(user_id,amount,type,ref_id,note) VALUES($1,$2,'purchase',$3,$4)",
        [q.user.id, -price, o.id, `ซื้อ ${pl.title} – ${pl.name}`]
      );
    }

    return { account: prov.accountText, paid: price, order: o.id, expiresAt: o.expires_at };
  });

  audit(q.user.id, 'purchase', { order: out.order, paid: out.paid }, q.ip);
  s.json({ ...out, credit: await balanceOf(q.user.id) });
}));

// แพ็กเกจราคา 0 = บัญชีทดลองใช้ฟรี ได้คนละ 1 ครั้ง (นับทุกแพ็กเกจราคา 0 รวมกัน)
const TRIAL_MSG = 'บัญชีทดลองใช้ฟรีได้คนละ 1 ครั้ง คุณใช้สิทธิ์ไปแล้ว';
async function assertTrialAvailable(c, userId) {
  const r = await c.query('SELECT 1 FROM orders o JOIN plans p ON p.id = o.plan_id WHERE o.user_id = $1 AND p.price = 0 LIMIT 1', [userId]);
  if (r.rows.length) throw new HttpErr(400, TRIAL_MSG);
}

// จำนวนครั้งที่ผู้ใช้คนนี้เคยใช้คูปองนี้ (นับทุกออเดอร์ รวมที่คืนเงินแล้ว กันใช้ซ้ำแล้วขอคืน)
const couponUsedBy = async (c, couponId, userId) =>
  +(await c.query('SELECT count(*) FROM orders WHERE coupon_id=$1 AND user_id=$2', [couponId, userId])).rows[0].count;
const COUPON_LIMIT_MSG = 'คุณใช้โค้ดนี้ครบจำนวนสิทธิ์ต่อคนแล้ว';

// สรุปราคาก่อนชำระเงิน (ไม่ตัดเครดิต / ไม่ใช้สิทธิ์คูปอง) ใช้แสดงในหน้าต่างยืนยันสั่งซื้อ
const quoteLimit = rateLimit({ windowMs: 60e3, limit: 30, message: { error: 'ลองบ่อยเกินไป รอสักครู่' } });
app.post('/api/quote', need, quoteLimit, w(async (q, s) => {
  const code = String(q.body.coupon || '').trim().toUpperCase();
  const pl = (await pool.query(`
    SELECT pl.id, pl.price, pl.discount_percent, pl.name, pl.duration_hours, p.title
    FROM plans pl JOIN products p ON p.id = pl.product_id
    WHERE pl.id = $1 AND NOT p.is_hidden
  `, [parseInt(q.body.planId, 10) || 0])).rows[0];
  if (!pl) throw new HttpErr(404, 'ไม่พบแพ็กเกจ');

  const original = +pl.price;
  const shopPercent = planPct(original, pl.discount_percent);
  const afterShop = applyPct(original, shopPercent);
  let total = afterShop;
  let percent = 0;
  let couponError = null;
  if (code) {
    const cp = (await pool.query(`
      SELECT id, percent, per_user_limit FROM coupons
      WHERE code = $1 AND remaining_uses > 0 AND (expires_at IS NULL OR expires_at > now())
    `, [code])).rows[0];
    if (!cp) couponError = 'โค้ดส่วนลดไม่ถูกต้องหรือหมดอายุ';
    else if (cp.per_user_limit > 0 && (await couponUsedBy(pool, cp.id, q.user.id)) >= cp.per_user_limit) {
      couponError = COUPON_LIMIT_MSG;
    } else {
      percent = +cp.percent;
      total = applyPct(afterShop, percent);
    }
  }
  let blockError = null;
  if (original === 0) {
    try { await assertTrialAvailable(pool, q.user.id); } catch (e) { blockError = e.message; }
  }
  const credit = await balanceOf(q.user.id);
  s.json({
    blockError,
    planId: pl.id,
    original,
    percent,
    shopPercent,
    shopDiscount: Math.round((original - afterShop) * 100) / 100,
    couponDiscount: Math.round((afterShop - total) * 100) / 100,
    discount: Math.round((original - total) * 100) / 100,
    total,
    credit,
    after: Math.round((credit - total) * 100) / 100,
    enough: credit >= total && !blockError,
    shortfall: Math.max(0, Math.round((total - credit) * 100) / 100),
    couponError
  });
}));

// ---------- ปริมาณการใช้ข้อมูลของลูกค้า (3x-ui + แดชบอร์ด XXTLONLINE/SSH) ----------
const usageCache = new Map(); // server.id -> { t, map, p }   (p = คำขอที่กำลังรอ — รวมหลายคำขอให้ยิงไปที่ VPS ครั้งเดียว)
const USAGE_TTL_MS = 2000;     // เรียลไทม์: แคชแค่ 2 วินาที (เดิม 60 วินาที)
async function serverClientStats(server) {
  const hit = usageCache.get(server.id);
  if (hit && hit.map && Date.now() - hit.t < USAGE_TTL_MS) return hit.map;
  if (hit && hit.p) return hit.p;                       // มีคำขอค้างอยู่แล้ว → รอผลเดียวกัน
  const p = serverClientStatsFetch(server).then(
    map => { usageCache.set(server.id, { t: Date.now(), map }); return map; },
    err => {                                            // ดึงไม่สำเร็จ → ใช้ค่าล่าสุดที่มี (ไม่เกิน 5 นาที) แทนที่จะหายไป
      const old = usageCache.get(server.id);
      usageCache.set(server.id, { t: old?.t || 0, map: old?.map });
      if (old?.map && Date.now() - old.t < 300e3) return old.map;
      throw err;
    });
  usageCache.set(server.id, { t: hit?.t || 0, map: hit?.map, p });
  return p;
}
async function serverClientStatsFetch(server) {
  if (server.type === 'xxt') {   // SSH ผ่านแดชบอร์ด XXTLONLINE v2.2+ — ยอดสะสมต่อ user (ไม่มีโควตา → total 0 = ไม่จำกัด)
    const r = await xxtCall(server, 'GET', '/users');
    if (!r.d?.ok || !Array.isArray(r.d.data)) throw xxtFail(r, 'อ่านรายชื่อผู้ใช้ไม่สำเร็จ');
    const xm = new Map();
    for (const u of r.d.data) {
      if (typeof u.used_bytes === 'number') {
        xm.set(String(u.username), {
          up: 0, down: u.used_bytes, total: 0, enable: !u.suspended, expiryTime: 0,
          // การเชื่อมต่อตอนนี้ (xxtlonline ใหม่ส่งมาให้; รุ่นเก่าไม่มี → null = ไม่ทราบ)
          conns: Number.isFinite(u.connections) ? u.connections : (Number.isFinite(u.online) ? u.online : null),
          ips: Array.isArray(u.ips) ? u.ips.slice(0, 20) : null
        });
      }
    }
    if (r.d.data.length && !xm.size) throw new Error('แดชบอร์ดรุ่นเก่า ไม่ส่งค่า used_bytes — อัปเดต xxtlonline เป็น v2.2+ แล้วรัน install.sh ซ้ำ');
    return xm;
  }
  const { baseUrl, auth } = await login3xui(server);
  const r = await xfetch(`${baseUrl}/panel/api/inbounds/list`, { headers: auth });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const d = await r.json().catch(() => ({}));
  const map = new Map();
  for (const ib of Array.isArray(d.obj) ? d.obj : []) {
    for (const cs of ib.clientStats || []) {
      map.set(String(cs.email), { up: +cs.up || 0, down: +cs.down || 0, total: +cs.total || 0, enable: cs.enable !== false, expiryTime: +cs.expiryTime || 0 });
    }
  }
  return map;
}

// เก็บยอดล่าสุดที่ดึงสำเร็จ — ถ้ารอบถัดไปดึงไม่ได้ชั่วคราว (เซิร์ฟเวอร์ช้า/ล็อกอินพลาด) ให้คืนค่าเดิมแทน ตัวเลขจะได้ไม่หาย (ใช้ค่าเก่าได้ไม่เกิน 10 นาที)
const usageLast = new Map();
const usageKeep = (id, v) => { usageLast.set(id, { ...v, at: Date.now() }); if (usageLast.size > 5000) usageLast.delete(usageLast.keys().next().value); };
const usageFallback = (id, errMsg) => {
  const l = usageLast.get(id);
  return l && Date.now() - l.at < 600e3 ? { used: l.used, total: l.total, stale: true } : { err: errMsg };
};
const usageLimit = rateLimit({ windowMs: 60e3, limit: 90, message: { error: 'ลองบ่อยเกินไป รอสักครู่' } });   // แยกจาก quoteLimit เพราะหน้าเว็บดึงทุก ~4 วินาที
app.get('/api/orders/usage', need, usageLimit, w(async (q, s) => {
  s.set('Cache-Control', 'no-store');
  const rows = (await pool.query(`
    SELECT o.id, o.client_email, o.server_id FROM orders o
    JOIN vps_servers v ON v.id = o.server_id AND v.type IN ('3xui', 'xxt')
    WHERE o.user_id = $1 AND o.status IN ('active','expired') AND o.client_email IS NOT NULL
    ORDER BY o.id DESC LIMIT 100`, [q.user.id])).rows;
  const out = {};
  const byServer = new Map();
  for (const r of rows) byServer.set(r.server_id, [...(byServer.get(r.server_id) || []), r]);
  for (const [sid, list] of byServer) {
    try {
      const srv = (await pool.query('SELECT * FROM vps_servers WHERE id=$1', [sid])).rows[0];
      if (!srv) continue;
      const map = await serverClientStats(srv);
      for (const o of list) {
        const st = map.get(String(o.client_email));
        if (st) {
          out[o.id] = { used: st.up + st.down, total: st.total };
          usageKeep(o.id, out[o.id]);
        } else {
          out[o.id] = usageFallback(o.id, 'ไม่พบบัญชีนี้บนเซิร์ฟเวอร์');
        }
      }
    } catch (e) {
      console.warn(`[usage] server #${sid} ดึงยอดไม่ได้:`, e.message);
      for (const o of list) out[o.id] = usageFallback(o.id, 'ดึงข้อมูลจากเซิร์ฟเวอร์ไม่สำเร็จ');
    }
  }
  s.json(out);
}));

// ต่ออายุออเดอร์เดิม (รองรับต่ออายุ Client เดิมบน 3x-ui) — ใช้ทั้งปุ่มต่ออายุและต่ออายุอัตโนมัติ
async function renewOrderCore(orderId, user) {
  return tx(async c => {
    const ord = (await c.query(`
      SELECT o.*, pl.duration_hours, pl.price AS plan_price, pl.discount_percent AS plan_discount, pl.name AS plan_name,
             p.title, p.network, p.protocol, p.is_hidden, p.server_id AS product_server_id, p.inbound_id AS product_inbound_id
      FROM orders o
      JOIN plans pl ON pl.id = o.plan_id
      JOIN products p ON p.id = pl.product_id
      WHERE o.id = $1 AND o.user_id = $2
      FOR UPDATE
    `, [orderId, user.id])).rows[0];

    if (!ord) throw new HttpErr(404, 'ไม่พบคำสั่งซื้อ');
    if (ord.status === 'refunded' || ord.status === 'cancelled') {
      throw new HttpErr(400, 'คำสั่งซื้อนี้ถูกคืนเงินหรือยกเลิกแล้ว ไม่สามารถต่ออายุได้');
    }
    if (ord.purged_at) throw new HttpErr(400, `ไฟล์นี้หมดอายุเกิน ${EXPIRED_KEEP_HOURS} ชั่วโมงและถูกลบอัตโนมัติแล้ว กรุณาสั่งซื้อแพ็กเกจใหม่`);
    if (ord.is_hidden) throw new HttpErr(400, 'แพ็กเกจนี้ถูกปิดให้บริการชั่วคราว');

    if (+ord.plan_price === 0) throw new HttpErr(400, 'แพ็กเกจทดลองใช้ฟรีต่ออายุไม่ได้');
    const price = applyPct(+ord.plan_price, planPct(ord.plan_price, ord.plan_discount));
    const bal = +(await c.query('SELECT credit_balance FROM users WHERE id = $1 FOR UPDATE', [user.id])).rows[0].credit_balance;
    if (bal < price) {
      throw new HttpErr(400, `เครดิตไม่พอสำหรับต่ออายุ ต้องใช้ ${price} บาท เหลือ ${bal.toFixed(2)} บาท`);
    }

    const baseExp = new Date(ord.expires_at) > new Date() ? new Date(ord.expires_at) : new Date();
    const newExp = new Date(baseExp.getTime() + Number(ord.duration_hours) * 3600e3);

    const srvId = ord.server_id || ord.product_server_id;
    let server = null;
    if (srvId) {
      server = (await c.query('SELECT * FROM vps_servers WHERE id = $1 AND is_active', [srvId])).rows[0] || null;
    }

    if (server && server.type === '3xui' && ord.client_uuid) {
      await provisionFromServer(
        server,
        { network: ord.network, protocol: ord.protocol, duration_hours: ord.duration_hours, inbound_id: ord.inbound_id || ord.product_inbound_id },
        user.username,
        { clientUuid: ord.client_uuid, clientEmail: ord.client_email, baseExpiryMs: baseExp.getTime() }
      );
    }

    if (server && server.type === 'ssh' && ord.client_email) {
      await sshExtendUser(server, ord.client_email, newExp.getTime());
    }

    if (server && server.type === 'xxt' && ord.client_email) {
      await xxtRenew(server, ord.client_email, ord.duration_hours);
    }

    await c.query(
      "UPDATE orders SET expires_at = $1, status = 'active', reminded_at = NULL, deprovisioned_at = NULL, deprov_tried_at = NULL WHERE id = $2",
      [newExp.toISOString(), ord.id]
    );

    if (price > 0) {
      await c.query(
        "INSERT INTO credit_ledger(user_id,amount,type,ref_id,note) VALUES($1,$2,'purchase',$3,$4)",
        [user.id, -price, ord.id, `ต่ออายุ ${ord.title} – ${ord.plan_name}`]
      );
    }

    return { orderId: ord.id, paid: price, newExpiresAt: newExp.toISOString() };
  });
}

app.post('/api/orders/:id/renew', need, buyLimit, w(async (q, s) => {
  const orderId = parseInt(q.params.id, 10);
  if (!(orderId > 0)) throw new HttpErr(400, 'รหัสคำสั่งซื้อไม่ถูกต้อง');
  const out = await renewOrderCore(orderId, q.user);
  audit(q.user.id, 'order_renew', out, q.ip);
  s.json({ ok: true, ...out, credit: await balanceOf(q.user.id) });
}));

// เปิด/ปิดต่ออายุอัตโนมัติ (ตัดเครดิตก่อนหมดอายุ ~6 ชม. ถ้าเครดิตพอ)
app.post('/api/orders/:id/auto-renew', need, w(async (q, s) => {
  const on = q.body.enabled === true;
  const r = await pool.query(
    "UPDATE orders SET auto_renew=$3 WHERE id=$1 AND user_id=$2 AND status IN ('active','expired') AND purged_at IS NULL RETURNING id",
    [parseInt(q.params.id, 10) || 0, q.user.id, on]
  );
  if (!r.rowCount) throw new HttpErr(404, 'ไม่พบคำสั่งซื้อ');
  s.json({ ok: true, enabled: on });
}));

// ลูกค้าดูยอดคืนเงินโดยประมาณ: วันที่เหลือ × ราคาคืนต่อวัน (แอดมินตั้งต่อแพ็กเกจ)
async function ownRefundOrder(q) {
  const orderId = parseInt(q.params.id, 10) || 0;
  const ord = (await pool.query(REFUND_SQL + ' AND o.user_id = $2', [orderId, q.user.id])).rows[0];
  if (!ord) throw new HttpErr(404, 'ไม่พบคำสั่งซื้อ');
  if (ord.status !== 'active') throw new HttpErr(400, 'คำสั่งซื้อนี้ขอคืนเงินไม่ได้ (หมดอายุ/คืนเงินแล้ว/ยกเลิก)');
  return ord;
}
app.get('/api/orders/:id/refund-estimate', need, w(async (q, s) => {
  const ord = await ownRefundOrder(q);
  const c = await refundCalc(pool, ord);
  s.json({ orderId: c.orderId, remainingDays: c.remainingDays, ratePerDay: c.ratePerDay, estimate: c.prorata,
    title: ord.title, planName: ord.plan_name, expiresAt: c.expiresAt, planDays: c.planDays, paidFirst: c.paidFirst, paidTotal: c.paidTotal, capped: c.capped });
}));
// ลูกค้ากด "ขอคืนเงิน" → ส่งเป็นเรื่องแจ้งแอดมิน (แอดมินกดคืนเครดิตเองที่ ออเดอร์ / คืนเงิน)
app.post('/api/orders/:id/refund-request', need, w(async (q, s) => {
  const ord = await ownRefundOrder(q);
  const c = await refundCalc(pool, ord);
  const subject = `ขอคืนเงิน #${ord.id}`;
  const dup = await pool.query(
    "SELECT id FROM support_tickets WHERE user_id=$1 AND order_id=$2 AND subject=$3 AND status='open'", [q.user.id, ord.id, subject]);
  if (dup.rows.length) throw new HttpErr(409, 'คุณส่งคำขอคืนเงินของออเดอร์นี้ไว้แล้ว รอแอดมินตรวจสอบ');
  const reason = String(q.body?.reason || '').trim().slice(0, 500);
  const message = `ขอคืนเงินออเดอร์ #${ord.id} (${ord.title} / ${ord.plan_name})\n` +
    `วันที่เหลือ ${c.remainingDays} วัน × ${c.ratePerDay} ฿/วัน = ประมาณ ${c.prorata} ฿` + (reason ? `\nเหตุผล: ${reason}` : '');
  const ins = await pool.query(
    'INSERT INTO support_tickets(user_id,order_id,subject,message) VALUES($1,$2,$3,$4) RETURNING id',
    [q.user.id, ord.id, subject, message]);
  audit(q.user.id, 'refund_request', { ticketId: ins.rows[0].id, orderId: ord.id, estimate: c.prorata }, q.ip);
  await notifyExternal(`💸 ขอคืนเงิน #${ord.id} จาก ${q.user.username} ≈ ${c.prorata} ฿`);
  s.json({ ok: true, id: ins.rows[0].id, estimate: c.prorata });
}));

app.post('/api/tickets', need, w(async (q, s) => {
  const subject = String(q.body.subject || '').trim();
  const message = String(q.body.message || '').trim();
  const orderId = q.body.orderId ? parseInt(q.body.orderId, 10) : null;

  if (subject.length < 3 || subject.length > 150) throw new HttpErr(400, 'หัวข้อปัญหาต้องยาว 3-150 ตัวอักษร');
  if (message.length < 5 || message.length > 2000) throw new HttpErr(400, 'รายละเอียดปัญหาต้องยาว 5-2000 ตัวอักษร');

  let validOrderId = null;
  if (orderId) {
    const chk = await pool.query('SELECT id FROM orders WHERE id=$1 AND user_id=$2', [orderId, q.user.id]);
    if (!chk.rows.length) throw new HttpErr(400, 'ไม่พบคำสั่งซื้อที่อ้างอิง');
    validOrderId = orderId;
  }

  const ins = await pool.query(
    'INSERT INTO support_tickets(user_id,order_id,subject,message) VALUES($1,$2,$3,$4) RETURNING id, created_at',
    [q.user.id, validOrderId, subject, message]
  );

  audit(q.user.id, 'ticket_create', { ticketId: ins.rows[0].id, subject }, q.ip);
  await notifyExternal(`🎫 แจ้งปัญหาใหม่ #${ins.rows[0].id} จาก ${q.user.username}: ${subject}`);
  s.json({ ok: true, id: ins.rows[0].id });
}));

// ลูกค้าตอบกลับในเรื่องเดิมได้เรื่อย ๆ จนกว่าแอดมินจะปิดเรื่อง
const ticketReplyLimit = rateLimit({ windowMs: 60e3, limit: 10, message: { error: 'ส่งบ่อยเกินไป รอสักครู่แล้วลองใหม่' } });
app.post('/api/tickets/:id/reply', need, ticketReplyLimit, w(async (q, s) => {
  const id = parseInt(q.params.id, 10);
  const body = String(q.body.message || '').trim();
  if (!Number.isSafeInteger(id)) throw new HttpErr(404, 'ไม่พบรายการแจ้งปัญหา');
  if (body.length < 1 || body.length > 2000) throw new HttpErr(400, 'ข้อความต้องยาว 1-2000 ตัวอักษร');
  const t = (await pool.query('SELECT id, status, subject FROM support_tickets WHERE id=$1 AND user_id=$2', [id, q.user.id])).rows[0];
  if (!t) throw new HttpErr(404, 'ไม่พบรายการแจ้งปัญหา');
  if (t.status === 'closed') throw new HttpErr(409, 'แอดมินปิดเรื่องนี้แล้ว หากมีปัญหาใหม่กรุณาแจ้งเรื่องใหม่');
  const cnt = +(await pool.query('SELECT count(*) FROM ticket_messages WHERE ticket_id=$1 AND sender=$2', [id, 'user'])).rows[0].count;
  if (cnt >= TK_MAX_MSGS) throw new HttpErr(429, 'ส่งข้อความในเรื่องนี้มากเกินไป กรุณารอแอดมินตอบ');
  await pool.query('INSERT INTO ticket_messages(ticket_id, sender, body) VALUES($1,$2,$3)', [id, 'user', body]);
  await pool.query("UPDATE support_tickets SET status='open', updated_at=now() WHERE id=$1 AND status<>'closed'", [id]);
  await notifyExternal(`💬 ลูกค้า ${q.user.username} ตอบกลับตั๋ว #${id}: ${t.subject}`);
  s.json({ ok: true });
}));

app.post('/api/reviews', need, w(async (q, s) => {
  const productId = parseInt(q.body.productId, 10);
  const rating = parseInt(q.body.rating, 10);
  const comment = String(q.body.comment || '').trim();

  if (!(productId > 0)) throw new HttpErr(400, 'ไม่พบสินค้า');
  if (!(rating >= 1 && rating <= 5)) throw new HttpErr(400, 'คะแนนรีวิวต้องอยู่ระหว่าง 1 ถึง 5 ดาว');
  if (comment.length < 2 || comment.length > 500) throw new HttpErr(400, 'ข้อความรีวิวต้องยาว 2-500 ตัวอักษร');

  const bought = await pool.query(`
    SELECT 1 FROM orders o
    JOIN plans pl ON pl.id = o.plan_id
    WHERE o.user_id = $1 AND pl.product_id = $2
    LIMIT 1
  `, [q.user.id, productId]);

  if (!bought.rows.length) {
    throw new HttpErr(403, 'สามารถรีวิวได้เฉพาะแพ็กเกจที่เคยสั่งซื้อแล้วเท่านั้น');
  }

  await pool.query(`
    INSERT INTO reviews(user_id, product_id, rating, comment)
    VALUES($1, $2, $3, $4)
    ON CONFLICT (user_id, product_id)
    DO UPDATE SET rating = EXCLUDED.rating, comment = EXCLUDED.comment, created_at = now()
  `, [q.user.id, productId, rating, comment]);

  audit(q.user.id, 'review_upsert', { productId, rating }, q.ip);
  s.json({ ok: true });
}));

// =====================================================
// ADMIN ENDPOINTS
// =====================================================
const SITE_KEYS = [
  'name', 'logo', 'hero', 'promo', 'title', 'sub', 'open',
  // โปสเตอร์โฆษณา / แบนเนอร์หน้าแรก (หน้า "ตั้งค่ารูปโฆษณา แบนเนอร์" ในหลังบ้าน)
  // รูปโฆษณาด้านล่างหน้าแรก (ต่อจากแพ็กเกจ สูงสุด 10 รูป)
  'ab_on', 'ab_title', 'ab_cols', 'ab_ratio', 'ab_fit', 'ab_img1', 'ab_link1', 'ab_img2', 'ab_link2', 'ab_img3', 'ab_link3', 'ab_img4', 'ab_link4', 'ab_img5', 'ab_link5', 'ab_img6', 'ab_link6', 'ab_img7', 'ab_link7', 'ab_img8', 'ab_link8', 'ab_img9', 'ab_link9', 'ab_img10', 'ab_link10',
  'ad_mode', 'ad_sec', 'ad_ratio', 'ad_ratio_m', 'ad_fit', 'ad_img1', 'ad_mimg1', 'ad_link1', 'ad_img2', 'ad_mimg2', 'ad_link2', 'ad_img3', 'ad_mimg3', 'ad_link3',
  'bankName', 'bankNo', 'bankHolder', 'line',
  'min_topup_amount', 'bonus_min_amount', 'bonus_percent', 'referral_reward',
  'slip_mode', 'slip_provider', 'slip_verify_url', 'slip_auto_approve',
  'slip_check_receiver', 'slip_receiver_acc', 'slip_receiver_name', 'terms_text', 'turnstile_site_key',
  // รูปแบบเว็บไซต์ (หน้า "รูปแบบเว็บไซต์" ในหลังบ้าน)
  'ui_preset', 'ui_mode', 'ui_font', 'ui_disp', 'ui_radius', 'ui_width', 'ui_btn', 'ui_hero',
  'ui_density', 'ui_cols', 'ui_hover', 'ui_bg', 'ui_motion', 'ui_stats', 'ui_perks',
  'ann_on', 'ann_text', 'ann_tone', 'footer_text', 'netmod_blob',
  'ui_nav', 'ui_dock', 'ui_icon', 'ui_shape', 'ui_fall', 'ff_body', 'fs_body', 'fw_body', 'ff_head', 'fs_head', 'fw_head', 'ff_btn', 'fs_btn', 'fw_btn', 'ff_nav', 'fs_nav', 'fw_nav', 'ff_tag', 'fs_tag', 'fw_tag', 'ff_input', 'fs_input', 'fw_input', 'ff_num', 'fs_num', 'fw_num', 'ff_table', 'fs_table', 'fw_table', 'ff_code', 'fs_code', 'fw_code', 'ff_ord', 'fs_ord', 'fw_ord'
];

app.get('/api/admin/settings', need, adm, w(async (q, s) => {
  const all = await getSettingsMap(pool, true);
  const { slip_api_key, turnstile_secret, ...safe } = all;
  for (const k of Object.keys(safe)) if (k.startsWith('tg_')) delete safe[k]; // token/chat id ไม่ส่งกลับไปตรง ๆ
  adMediaUrls(safe);
  s.json({ ...safe, has_slip_api_key: Boolean(slip_api_key), has_turnstile_secret: Boolean(turnstile_secret), telegram: await tgPublic(), perf: await perfPublic() });
}));

app.put('/api/admin/site', need, adm, w(async (q, s) => {
  for (const k of SITE_KEYS) {
    if (typeof q.body[k] === 'string') {
      await pool.query(
        'INSERT INTO settings(key,value,is_secret) VALUES($1,$2,FALSE) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value',
        [k, q.body[k].slice(0, 2e6)]
      );
    }
  }
  if (typeof q.body.slip_api_key === 'string' && q.body.slip_api_key.trim()) {
    await pool.query(
      'INSERT INTO settings(key,value,is_secret) VALUES($1,$2,TRUE) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value, is_secret=TRUE',
      ['slip_api_key', enc(q.body.slip_api_key.trim())]
    );
  }
  if (typeof q.body.turnstile_secret === 'string' && q.body.turnstile_secret.trim()) {
    await pool.query(
      'INSERT INTO settings(key,value,is_secret) VALUES($1,$2,TRUE) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value, is_secret=TRUE',
      ['turnstile_secret', enc(q.body.turnstile_secret.trim())]
    );
  }
  if (q.body.turnstile_clear === true) await pool.query("DELETE FROM settings WHERE key IN ('turnstile_secret','turnstile_site_key')");
  await touchUpdated();
  audit(q.user.id, 'site_update', null, q.ip);
  s.json({ ok: true });
}));

// ---------- ตั้งค่า Telegram ที่หลังบ้าน ----------
const TG_TOKEN_RE = /^\d{5,}:[A-Za-z0-9_-]{30,}$/;
const TG_CHAT_RE = /^(-?\d{1,20}|@[A-Za-z][A-Za-z0-9_]{3,})$/;
async function tgPublic() {
  const c = await tgConf();
  return {
    source: c.source,                                   // db | env | none
    has_token: Boolean(c.token),
    token_hint: c.token ? c.token.split(':')[0] + ':••••••••' : '',
    chat_id: c.chatId,
    notify_all: c.notifyAll,
    muted: [...c.mute],
    events: Object.keys(TG_LABEL).filter(k => !TG_ALREADY.has(k)).map(k => ({ key: k, label: TG_LABEL[k] }))
  };
}
const tgSet = (k, v) => pool.query(
  'INSERT INTO settings(key,value,is_secret) VALUES($1,$2,TRUE) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value, is_secret=TRUE', [k, enc(v)]);
const tgPickToken = async b => {
  const t = typeof b.token === 'string' ? b.token.trim() : '';
  if (t && !TG_TOKEN_RE.test(t)) throw new HttpErr(400, 'รูปแบบ Bot Token ไม่ถูกต้อง (ต้องเป็นแบบ 123456789:AA... จาก @BotFather)');
  const token = t || (await tgConf()).token;
  if (!token) throw new HttpErr(400, 'ยังไม่มี Bot Token');
  return token;
};

app.get('/api/admin/telegram', need, adm, w(async (q, s) => s.json(await tgPublic())));

app.put('/api/admin/telegram', need, adm, w(async (q, s) => {
  const b = q.body || {};
  if (b.clear === true) {
    await pool.query('DELETE FROM settings WHERE key = ANY($1)', [TG_KEYS]);
    tgInvalidate();
    audit(q.user.id, 'telegram_update', { name: 'ล้างค่าที่ตั้งในหลังบ้าน' }, q.ip);
    return s.json({ ok: true, telegram: await tgPublic() });
  }
  if (typeof b.token === 'string' && b.token.trim()) {
    if (!TG_TOKEN_RE.test(b.token.trim())) throw new HttpErr(400, 'รูปแบบ Bot Token ไม่ถูกต้อง (ต้องเป็นแบบ 123456789:AA... จาก @BotFather)');
    await tgSet('tg_bot_token', b.token.trim());
  }
  if (typeof b.chat_id === 'string') {
    const v = b.chat_id.trim();
    if (v && !TG_CHAT_RE.test(v)) throw new HttpErr(400, 'Chat ID ต้องเป็นตัวเลข (กลุ่มขึ้นต้นด้วย -) หรือ @ชื่อช่อง');
    if (v) await tgSet('tg_chat_id', v);
    else await pool.query("DELETE FROM settings WHERE key='tg_chat_id'");
  }
  if (typeof b.notify_all === 'boolean') await tgSet('tg_notify_all', b.notify_all ? '1' : '0');
  if (Array.isArray(b.muted)) {
    const ok = new Set(Object.keys(TG_LABEL));
    await tgSet('tg_mute_events', b.muted.filter(x => typeof x === 'string' && ok.has(x)).join(','));
  }
  tgInvalidate();
  audit(q.user.id, 'telegram_update', null, q.ip);
  s.json({ ok: true, telegram: await tgPublic() });
}));

// ส่งข้อความทดสอบ (ใช้ค่าที่กรอกอยู่บนฟอร์ม ถ้าเว้นว่างใช้ค่าที่บันทึกไว้)
app.post('/api/admin/telegram/test', need, adm, authLimit, w(async (q, s) => {
  const b = q.body || {};
  const token = await tgPickToken(b);
  const chat = (typeof b.chat_id === 'string' && b.chat_id.trim()) || (await tgConf()).chatId;
  if (!chat) throw new HttpErr(400, 'ยังไม่มี Chat ID');
  if (!TG_CHAT_RE.test(chat)) throw new HttpErr(400, 'Chat ID ต้องเป็นตัวเลข (กลุ่มขึ้นต้นด้วย -) หรือ @ชื่อช่อง');
  const me = await tgCall(token, 'getMe');
  const name = (await getSettingsMap()).name || 'Wselx';
  await tgCall(token, 'sendMessage', { chat_id: chat, text: `✅ ทดสอบแจ้งเตือนจากหลังบ้าน ${name}\nเวลา: ${new Date().toLocaleString('th-TH', { timeZone: 'Asia/Bangkok' })}` });
  s.json({ ok: true, bot: me && me.username ? '@' + me.username : '' });
}));

// หา Chat ID จากข้อความที่ส่งหาบอท / กลุ่มที่เพิ่มบอทเข้าไปล่าสุด
app.post('/api/admin/telegram/detect', need, adm, authLimit, w(async (q, s) => {
  const token = await tgPickToken(q.body || {});
  const ups = await tgCall(token, 'getUpdates', { limit: 100, timeout: 0, allowed_updates: ['message', 'channel_post', 'my_chat_member'] });
  const seen = new Map();
  for (const u of Array.isArray(ups) ? ups : []) {
    const ch = (u.message || u.channel_post || u.my_chat_member || {}).chat;
    if (!ch || ch.id == null) continue;
    seen.set(String(ch.id), {
      id: String(ch.id), type: ch.type,
      name: ch.title || [ch.first_name, ch.last_name].filter(Boolean).join(' ') || (ch.username ? '@' + ch.username : '')
    });
  }
  s.json({ chats: [...seen.values()] });
}));

app.post('/api/admin/2fa/setup', need, adm, authLimit, w(async (q, s) => {
  if (q.user.totp_enabled) throw new HttpErr(400, 'เปิดใช้ 2FA อยู่แล้ว (ปิดก่อนถ้าจะตั้งใหม่)');
  const secret = b32enc(crypto.randomBytes(20));
  await pool.query('UPDATE users SET totp_secret_enc=$2 WHERE id=$1', [q.user.id, enc(secret)]);
  const issuer = encodeURIComponent((await getSettingsMap()).name || 'Wselx');
  s.json({ secret, uri: `otpauth://totp/${issuer}:${encodeURIComponent(q.user.username)}?secret=${secret}&issuer=${issuer}` });
}));

app.post('/api/admin/2fa/enable', need, adm, authLimit, w(async (q, s) => {
  const r = (await pool.query('SELECT totp_secret_enc FROM users WHERE id=$1', [q.user.id])).rows[0];
  if (!r || !r.totp_secret_enc) throw new HttpErr(400, 'ยังไม่ได้เริ่มตั้งค่า 2FA');
  if (!totpOk(dec(r.totp_secret_enc), q.body.code)) throw new HttpErr(400, 'รหัสไม่ถูกต้อง ตรวจเวลาในมือถือแล้วลองใหม่');
  await pool.query('UPDATE users SET totp_enabled=TRUE WHERE id=$1', [q.user.id]);
  audit(q.user.id, '2fa_enable', null, q.ip);
  s.json({ ok: true });
}));

app.post('/api/admin/2fa/disable', need, adm, authLimit, w(async (q, s) => {
  const r = (await pool.query('SELECT password_hash, totp_secret_enc, totp_enabled FROM users WHERE id=$1', [q.user.id])).rows[0];
  if (!(await bcrypt.compare(String(q.body.password || ''), r.password_hash))) throw new HttpErr(400, 'รหัสผ่านไม่ถูกต้อง');
  if (r.totp_enabled && !totpOk(dec(r.totp_secret_enc), q.body.code)) throw new HttpErr(400, 'รหัส 2FA ไม่ถูกต้อง');
  await pool.query('UPDATE users SET totp_enabled=FALSE, totp_secret_enc=NULL WHERE id=$1', [q.user.id]);
  audit(q.user.id, '2fa_disable', null, q.ip);
  s.json({ ok: true });
}));

// ---------- Admin: แดชบอร์ดสรุป ----------
app.get('/api/admin/dashboard', need, adm, w(async (q, s) => {
  const one = async (sql) => (await pool.query(sql)).rows[0];
  const sales = await one(`SELECT
      COALESCE(sum(price_paid) FILTER (WHERE created_at >= date_trunc('day', now())), 0) AS today,
      COALESCE(sum(price_paid) FILTER (WHERE created_at >= date_trunc('month', now())), 0) AS month,
      count(*) FILTER (WHERE created_at >= date_trunc('day', now()))::int AS orders_today,
      count(*) FILTER (WHERE created_at >= date_trunc('month', now()))::int AS orders_month
    FROM orders WHERE status <> 'refunded'`);
  const top = await one(`SELECT
      COALESCE(sum(amount) FILTER (WHERE created_at >= date_trunc('day', now())), 0) AS today,
      COALESCE(sum(amount) FILTER (WHERE created_at >= date_trunc('month', now())), 0) AS month
    FROM topups WHERE status = 'approved'`);
  const misc = await one(`SELECT
      (SELECT count(*) FROM users WHERE created_at >= now() - interval '7 days')::int AS new_users_7d,
      (SELECT count(*) FROM users)::int AS users,
      (SELECT count(*) FROM orders WHERE status='active' AND expires_at > now())::int AS active_orders,
      (SELECT count(*) FROM orders WHERE status='active' AND expires_at BETWEEN now() AND now() + interval '3 days')::int AS expiring_3d,
      (SELECT count(*) FROM topups WHERE status='pending')::int AS pending_topups,
      (SELECT count(*) FROM support_tickets WHERE status='open')::int AS open_tickets,
      (SELECT COALESCE(sum(credit_balance),0) FROM users) AS credit_outstanding`);
  const daily = (await pool.query(`
    SELECT to_char(d::date, 'DD/MM') AS day,
           COALESCE((SELECT sum(price_paid) FROM orders o WHERE o.status <> 'refunded' AND o.created_at::date = d::date), 0) AS sales
    FROM generate_series((now()::date - 13)::timestamp, now()::date::timestamp, interval '1 day') d ORDER BY d`)).rows;
  const best = (await pool.query(`
    SELECT p.title || ' – ' || pl.name AS name, count(*)::int AS n, COALESCE(sum(o.price_paid),0) AS revenue
    FROM orders o JOIN plans pl ON pl.id = o.plan_id JOIN products p ON p.id = pl.product_id
    WHERE o.status <> 'refunded' AND o.created_at >= now() - interval '30 days'
    GROUP BY 1 ORDER BY n DESC, revenue DESC LIMIT 5`)).rows;
  s.json({
    sales: { today: +sales.today, month: +sales.month, ordersToday: sales.orders_today, ordersMonth: sales.orders_month },
    topup: { today: +top.today, month: +top.month },
    misc: { ...misc, credit_outstanding: +misc.credit_outstanding },
    daily: daily.map(r => ({ day: r.day, sales: +r.sales })),
    best: best.map(r => ({ ...r, revenue: +r.revenue }))
  });
}));

// ---------- Admin: จัดการผู้ใช้งาน (Users Management) ----------
app.get('/api/admin/users', need, adm, w(async (q, s) => {
  const search = String(q.body?.q || q.query.q || '').trim();
  const params = [];
  let where = '';
  if (search) {
    params.push(`%${search}%`);
    where = 'WHERE u.username ILIKE $1 OR u.referral_code ILIKE $1';
  }

  const rows = (await pool.query(`
    SELECT u.id, u.username, u.role, u.is_banned, u.note, u.credit_balance,
           u.referral_code, u.created_at,
           (SELECT count(*) FROM orders o WHERE o.user_id = u.id)::int AS order_count,
           (SELECT COALESCE(sum(price_paid), 0) FROM orders o WHERE o.user_id = u.id AND o.status <> 'refunded') AS total_spent,
           (SELECT COALESCE(sum(amount), 0) FROM topups t WHERE t.user_id = u.id AND t.status = 'approved') AS total_topup
    FROM users u
    ${where}
    ORDER BY u.id DESC
    LIMIT 200
  `, params)).rows;

  s.json(rows.map(r => ({
    ...r,
    credit_balance: +r.credit_balance,
    total_spent: +r.total_spent,
    total_topup: +r.total_topup
  })));
}));

app.get('/api/admin/users/:id', need, adm, w(async (q, s) => {
  const uid = parseInt(q.params.id, 10);
  const u = (await pool.query(`
    SELECT id, username, role, is_banned, note, credit_balance, referral_code, referred_by, created_at
    FROM users WHERE id = $1
  `, [uid])).rows[0];
  if (!u) throw new HttpErr(404, 'ไม่พบผู้ใช้งาน');

  const orders = (await pool.query(`
    SELECT o.id, o.price_paid, o.status, o.expires_at, o.created_at, o.client_email,
           p.title, pl.name AS plan_name
    FROM orders o
    JOIN plans pl ON pl.id = o.plan_id
    JOIN products p ON p.id = pl.product_id
    WHERE o.user_id = $1
    ORDER BY o.id DESC LIMIT 30
  `, [uid])).rows;

  const ledger = (await pool.query(`
    SELECT id, amount, type, ref_id, note, balance_after, created_at
    FROM credit_ledger
    WHERE user_id = $1
    ORDER BY id DESC LIMIT 30
  `, [uid])).rows;

  s.json({
    user: { ...u, credit_balance: +u.credit_balance },
    orders: orders.map(x => ({ ...x, price_paid: +x.price_paid })),
    ledger: ledger.map(x => ({ ...x, amount: +x.amount, balance_after: +x.balance_after }))
  });
}));

app.post('/api/admin/users/:id/adjust-credit', need, adm, w(async (q, s) => {
  const uid = parseInt(q.params.id, 10);
  const amount = Math.round(parseFloat(q.body.amount) * 100) / 100;
  const note = String(q.body.note || '').trim() || 'แอดมินปรับยอดเครดิต';
  if (!amount || Math.abs(amount) > 100000) throw new HttpErr(400, 'จำนวนเงินไม่ถูกต้อง');

  await tx(async c => {
    const u = (await c.query('SELECT id, credit_balance FROM users WHERE id = $1 FOR UPDATE', [uid])).rows[0];
    if (!u) throw new HttpErr(404, 'ไม่พบผู้ใช้งาน');
    if (+u.credit_balance + amount < 0) throw new HttpErr(400, 'ยอดเครดิตหลังหักต้องไม่ติดลบ');

    await c.query(
      "INSERT INTO credit_ledger(user_id,amount,type,note) VALUES($1,$2,'adjust',$3)",
      [uid, amount, note]
    );
  });

  audit(q.user.id, 'user_credit_adjust', { targetUserId: uid, amount, note }, q.ip);
  s.json({ ok: true, credit: await balanceOf(uid) });
}));

app.put('/api/admin/users/:id', need, adm, w(async (q, s) => {
  const uid = parseInt(q.params.id, 10);
  if (uid === q.user.id && q.body.is_banned === true) {
    throw new HttpErr(400, 'ไม่สามารถระงับบัญชีของตัวเองได้');
  }
  const role = ['user', 'admin'].includes(q.body.role) ? q.body.role : undefined;
  const isBanned = typeof q.body.is_banned === 'boolean' ? q.body.is_banned : undefined;
  const note = typeof q.body.note === 'string' ? q.body.note.slice(0, 500) : undefined;

  const cur = (await pool.query('SELECT role, is_banned, note FROM users WHERE id = $1', [uid])).rows[0];
  if (!cur) throw new HttpErr(404, 'ไม่พบผู้ใช้งาน');

  await pool.query(
    'UPDATE users SET role=$2, is_banned=$3, note=$4 WHERE id=$1',
    [uid, role ?? cur.role, isBanned ?? cur.is_banned, note ?? cur.note]
  );

  if (typeof q.body.new_password === 'string' && q.body.new_password.length >= MIN_PW) {
    await pool.query('UPDATE users SET password_hash=$2, pw_changed_at=now() WHERE id=$1', [uid, await bcrypt.hash(q.body.new_password, 12)]);
  }

  audit(q.user.id, 'user_update', { targetUserId: uid, role, isBanned }, q.ip);
  s.json({ ok: true });
}));

// ---------- Admin: จัดการเซิร์ฟเวอร์ VPS (3x-ui / SSH) ----------
app.get('/api/admin/servers', need, adm, w(async (q, s) => {
  const rows = (await pool.query(`
    SELECT id, name, type, host, panel_url, panel_user, ssh_user, (ssh_pass_enc IS NOT NULL) AS has_ssh_pass, inbound_id, protocol,
           ws_path, sni, public_port, ssh_port, udp_port, tls_enabled,
           npv_type, payload, proxy_host, proxy_port, udpgw_port,
           template, is_active, last_status, last_checked_at, created_at
    FROM vps_servers
    ORDER BY id DESC
  `)).rows;
  s.json(rows);
}));

app.post('/api/admin/servers', need, adm, w(async (q, s) => {
  const b = q.body;
  const type = ['3xui', 'ssh', 'xxt'].includes(b.type) ? b.type : '3xui';
  const name = String(b.name || '').trim();
  let host = String(b.host || '').trim();
  if (!host && type === 'xxt') { try { host = new URL(String(b.panel_url || '')).hostname; } catch { /* ปล่อยว่างให้ตรวจด้านล่าง */ } }
  if (!name || !host) throw new HttpErr(400, 'กรุณากรอกชื่อเซิร์ฟเวอร์และ Host / IP');
  if (type === 'xxt' && (!String(b.panel_url || '').trim() || !b.panel_pass)) {
    throw new HttpErr(400, 'กรุณากรอก Dashboard URL และ API Key ของแดชบอร์ด (สร้างที่แดชบอร์ด → เมนู API)');
  }
  if (type === '3xui' && (!String(b.panel_url || '').trim() || !String(b.panel_user || '').trim() || !b.panel_pass)) {
    throw new HttpErr(400, 'กรุณากรอก Panel URL, Username และ Password ของ 3x-ui');
  }

  const panelPassEnc = b.panel_pass ? enc(String(b.panel_pass)) : null;

  const ins = await pool.query(`
    INSERT INTO vps_servers(
      name, type, host, panel_url, panel_user, panel_pass_enc,
      inbound_id, protocol, ws_path, sni, public_port, ssh_port, udp_port,
      tls_enabled, template, is_active, ssh_user, ssh_pass_enc,
      npv_type, payload, proxy_host, proxy_port, udpgw_port
    ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23)
    RETURNING id
  `, [
    name,
    type,
    host,
    normalizePanelUrl(b.panel_url || ''),
    String(b.panel_user || '').trim(),
    panelPassEnc,
    parseInt(b.inbound_id, 10) || 1,
    String(b.protocol || 'vless').toLowerCase(),
    String(b.ws_path || '/').trim() || '/',
    String(b.sni || '').trim(),
    parseInt(b.public_port, 10) || null, // ว่าง = ใช้พอร์ตจริงของ inbound
    parseInt(b.ssh_port, 10) || 22,
    String(b.udp_port || '1-65535').trim() || '1-65535',
    b.tls_enabled !== false,
    String(b.template || ''),
    b.is_active !== false,
    String(b.ssh_user || '').trim() || null,
    b.ssh_pass ? enc(String(b.ssh_pass)) : null,
    npvTypeOk(b.npv_type),
    String(b.payload || '').trim() || null,
    String(b.proxy_host || '').trim() || null,
    parseInt(b.proxy_port, 10) || null,
    parseInt(b.udpgw_port, 10) || 7300
  ]);

  audit(q.user.id, 'server_add', { id: ins.rows[0].id, name, type }, q.ip);
  s.json({ ok: true, id: ins.rows[0].id });
}));

app.put('/api/admin/servers/:id', need, adm, w(async (q, s) => {
  const id = parseInt(q.params.id, 10);
  const b = q.body;
  const cur = (await pool.query('SELECT * FROM vps_servers WHERE id = $1', [id])).rows[0];
  if (!cur) throw new HttpErr(404, 'ไม่พบเซิร์ฟเวอร์');

  const name = String(b.name ?? cur.name).trim();
  const type = ['3xui', 'ssh', 'xxt'].includes(b.type) ? b.type : cur.type;
  let host = String(b.host ?? cur.host).trim();
  if (!host && type === 'xxt') { try { host = new URL(String(b.panel_url ?? cur.panel_url)).hostname; } catch { host = cur.host; } }
  const panelPassEnc = b.panel_pass && String(b.panel_pass).trim()
    ? enc(String(b.panel_pass).trim())
    : cur.panel_pass_enc;

  await pool.query(`
    UPDATE vps_servers SET
      name=$2, type=$3, host=$4, panel_url=$5, panel_user=$6, panel_pass_enc=$7,
      inbound_id=$8, protocol=$9, ws_path=$10, sni=$11, public_port=$12,
      ssh_port=$13, udp_port=$14, tls_enabled=$15, template=$16, is_active=$17, ssh_user=$18, ssh_pass_enc=$19,
      npv_type=$20, payload=$21, proxy_host=$22, proxy_port=$23, udpgw_port=$24
    WHERE id=$1
  `, [
    id,
    name,
    type,
    host,
    normalizePanelUrl(b.panel_url ?? cur.panel_url),
    String(b.panel_user ?? cur.panel_user).trim(),
    panelPassEnc,
    parseInt(b.inbound_id, 10) || cur.inbound_id,
    String(b.protocol ?? cur.protocol).toLowerCase(),
    String(b.ws_path ?? cur.ws_path).trim() || '/',
    String(b.sni ?? cur.sni).trim(),
    'public_port' in b ? (parseInt(b.public_port, 10) || null) : cur.public_port,
    parseInt(b.ssh_port, 10) || cur.ssh_port,
    String(b.udp_port ?? cur.udp_port).trim() || '1-65535',
    typeof b.tls_enabled === 'boolean' ? b.tls_enabled : cur.tls_enabled,
    String(b.template ?? cur.template ?? ''),
    typeof b.is_active === 'boolean' ? b.is_active : cur.is_active,
    typeof b.ssh_user === 'string' ? (b.ssh_user.trim() || null) : cur.ssh_user,
    b.ssh_pass && String(b.ssh_pass).trim() ? enc(String(b.ssh_pass).trim()) : cur.ssh_pass_enc,
    'npv_type' in b ? npvTypeOk(b.npv_type) : cur.npv_type,
    'payload' in b ? (String(b.payload || '').trim() || null) : cur.payload,
    'proxy_host' in b ? (String(b.proxy_host || '').trim() || null) : cur.proxy_host,
    'proxy_port' in b ? (parseInt(b.proxy_port, 10) || null) : cur.proxy_port,
    'udpgw_port' in b ? (parseInt(b.udpgw_port, 10) || 7300) : cur.udpgw_port
  ]);

  audit(q.user.id, 'server_edit', { id, name }, q.ip);
  s.json({ ok: true });
}));

// ---------- ปุ่มเชื่อมร้านค้า ↔ แดชบอร์ด XXTLONLINE (ติดตั้งโดย setup.sh: สร้าง API Key ให้ใน .env) ----------
// =====================================================
// อัปเดตระบบผ่านหลังบ้าน (ร้านค้า + แดชบอร์ด xxtlonline)
// เว็บไม่มีสิทธิ์ root: วางไฟล์คำขอ (check|shop|dash) ไว้ที่ UPD_DIR/req/request
// แล้ว systemd (wselx-updater.path) เรียกตัวทำงานสิทธิ์ root ให้ — ติดตั้งโดย install.sh (menu เมนู 3 ครั้งแรก)
// =====================================================
const updFs = require('fs');
const updPath = require('path');
const UPD_DIR = process.env.WSELX_UPDATE_DIR || '/var/lib/wselx-update';
const UPD_REQ = updPath.join(UPD_DIR, 'req', 'request');
const updJson = f => { try { return JSON.parse(updFs.readFileSync(updPath.join(UPD_DIR, f), 'utf8')); } catch { return null; } };
const updLog = () => { try { const t = updFs.readFileSync(updPath.join(UPD_DIR, 'update.log'), 'utf8'); return t.length > 12000 ? '…' + t.slice(-12000) : t; } catch { return ''; } };
const appVersion = () => { try { return JSON.parse(updFs.readFileSync(updPath.join(__dirname, 'package.json'), 'utf8')).version; } catch { return null; } };

function updState() {
  const status = updJson('status.json');
  const pending = updFs.existsSync(UPD_REQ);
  const stale = status && status.state === 'running' && (Date.now() - new Date(status.at).getTime()) > 35 * 60e3;
  return {
    available: updFs.existsSync(updPath.join(UPD_DIR, 'req')),
    busy: pending || !!(status && status.state === 'running' && !stale),
    pending,
    status,
    check: updJson('check.json'),
    log: updLog(),
    version: appVersion()
  };
}

app.get('/api/admin/update', need, adm, w(async (q, s) => {
  s.set('Cache-Control', 'no-store');
  s.json(updState());
}));

app.post('/api/admin/update', need, adm, w(async (q, s) => {
  const action = String(q.body.action || '');
  if (!['check', 'shop', 'dash'].includes(action)) throw new HttpErr(400, 'คำสั่งไม่ถูกต้อง');
  const st = updState();
  if (!st.available) throw new HttpErr(400, 'ยังไม่ได้ติดตั้งตัวอัปเดตผ่านเว็บ — ครั้งแรกให้อัปเดตผ่านเมนู VPN (พิมพ์ menu แล้วเลือก 3) หนึ่งครั้ง หลังจากนั้นกดอัปเดตผ่านเว็บได้เลย');
  if (st.busy) throw new HttpErr(409, 'กำลังมีงานอัปเดตทำงานอยู่ รอให้เสร็จก่อน');
  try { updFs.writeFileSync(UPD_REQ, action, { flag: 'wx', mode: 0o640 }); }
  catch (e) { throw new HttpErr(e.code === 'EEXIST' ? 409 : 500, e.code === 'EEXIST' ? 'กำลังมีงานอัปเดตทำงานอยู่' : 'ส่งคำสั่งอัปเดตไม่สำเร็จ: ' + e.code); }
  audit(q.user.id, 'web_update_' + action, { from: st.version }, q.ip);
  if (action !== 'check') notifyExternal(`🔄 แอดมิน ${q.user.username} สั่งอัปเดต${action === 'shop' ? 'ร้านค้า' : 'แดชบอร์ด'}ผ่านหลังบ้าน`).catch(() => {});
  s.json({ ok: true, queued: action });
}));

app.get('/api/admin/xxt-link', need, adm, w(async (q, s) => {
  const ex = (await pool.query("SELECT id, name, last_status FROM vps_servers WHERE type='xxt' AND panel_url = $1 ORDER BY id LIMIT 1", [normalizePanelUrl(XXT_PANEL_URL)])).rows[0];
  s.json({
    available: !!XXT_LINK_KEY,                       // ติดตั้งมาพร้อมแดชบอร์ดบนเครื่องเดียวกัน
    panel_web: XXT_PANEL_WEB || (SITE_DOMAIN ? '/panel/' : null),   // ตั้ง XXT_PANEL_WEB ใน .env เพื่อชี้ไปพอร์ตตรง เช่น :6787
    linked: ex || null,
    xui: {
      available: !!(XUI_PANEL_URL && XUI_USER && XUI_PASS),
      panel_web: XUI_PANEL_URL && SITE_DOMAIN ? '/xui/' : null,
      linked: (XUI_PANEL_URL && (await pool.query("SELECT id, name, last_status FROM vps_servers WHERE type='3xui' AND panel_url = $1 ORDER BY id LIMIT 1", [normalizePanelUrl(XUI_PANEL_URL)])).rows[0]) || null
    }
  });
}));

app.post('/api/admin/xxt-link', need, adm, w(async (q, s) => {
  if (!XXT_LINK_KEY) throw new HttpErr(400, 'ไม่พบ API Key ของแดชบอร์ดบนเครื่องนี้ — ติดตั้งด้วย setup.sh หรือสร้างคีย์ที่แดชบอร์ดแล้วเพิ่มเซิร์ฟเวอร์เอง');
  const url = normalizePanelUrl(XXT_PANEL_URL);
  let host = SITE_DOMAIN || '';
  if (!host) { try { host = new URL(url).hostname; } catch { host = '127.0.0.1'; } }
  const keyEnc = enc(XXT_LINK_KEY);
  let ex = (await pool.query("SELECT id FROM vps_servers WHERE type='xxt' AND panel_url = $1 ORDER BY id LIMIT 1", [url])).rows[0];
  let created = false;
  if (ex) {
    await pool.query('UPDATE vps_servers SET panel_pass_enc=$2, host=$3, is_active=true WHERE id=$1', [ex.id, keyEnc, host]);
  } else {
    ex = (await pool.query(`
      INSERT INTO vps_servers(name, type, host, panel_url, panel_user, panel_pass_enc, inbound_id, protocol, ws_path, sni,
        public_port, ssh_port, udp_port, tls_enabled, template, is_active, npv_type, udpgw_port)
      VALUES($1,'xxt',$2,$3,'',$4,1,'vless','/','',NULL,22,'1-65535',true,'',true,'SSH-Direct',7300) RETURNING id
    `, ['XXTLONLINE (VPN)', host, url, keyEnc])).rows[0];
    created = true;
  }
  const srv = (await pool.query('SELECT * FROM vps_servers WHERE id = $1', [ex.id])).rows[0];
  let info = null;
  try {
    const r = await xxtCall(srv, 'GET', '/info');
    if (!r.d?.ok || !r.d?.data) throw xxtFail(r, 'แดชบอร์ดตอบกลับไม่ถูกต้อง');
    info = r.d.data;
    await pool.query("UPDATE vps_servers SET last_status='online', last_checked_at=now() WHERE id=$1", [srv.id]);
  } catch (e) {
    await pool.query("UPDATE vps_servers SET last_status='error', last_checked_at=now() WHERE id=$1", [srv.id]);
    throw e;
  }
  audit(q.user.id, 'xxt_link', { id: srv.id, created }, q.ip);
  s.json({ ok: true, id: srv.id, created, users: info.users, online: info.online, ws_port: info.ws_port });
}));

app.post('/api/admin/xui-link', need, adm, w(async (q, s) => {
  if (!(XUI_PANEL_URL && XUI_USER && XUI_PASS)) throw new HttpErr(400, 'ไม่พบข้อมูล 3x-ui ที่ setup.sh ตั้งไว้ — เพิ่มเซิร์ฟเวอร์ 3x-ui เองด้วยฟอร์มด้านล่าง');
  const url = normalizePanelUrl(XUI_PANEL_URL);
  const host = SITE_DOMAIN || '127.0.0.1';
  const passEnc = enc(XUI_PASS);
  let ex = (await pool.query("SELECT id FROM vps_servers WHERE type='3xui' AND panel_url = $1 ORDER BY id LIMIT 1", [url])).rows[0];
  let created = false;
  if (ex) {
    await pool.query('UPDATE vps_servers SET panel_user=$2, panel_pass_enc=$3, host=$4, is_active=true WHERE id=$1', [ex.id, XUI_USER, passEnc, host]);
  } else {
    ex = (await pool.query(`
      INSERT INTO vps_servers(name, type, host, panel_url, panel_user, panel_pass_enc, inbound_id, protocol, ws_path, sni,
        public_port, ssh_port, udp_port, tls_enabled, template, is_active, npv_type, udpgw_port)
      VALUES($1,'3xui',$2,$3,$4,$5,1,'vless','/','',NULL,22,'1-65535',true,'',true,'SSH-Direct',7300) RETURNING id
    `, ['3x-ui (VLESS/VMess)', host, url, XUI_USER, passEnc])).rows[0];
    created = true;
  }
  const srv = (await pool.query('SELECT * FROM vps_servers WHERE id = $1', [ex.id])).rows[0];
  let t;
  try {
    t = await test3xuiServer(srv);
    // ถ้า inbound ที่ตั้งไว้ (#1) ไม่มีอยู่จริง ให้ใช้ inbound แรกที่เปิดอยู่
    const first = (t.inbounds || []).find(x => x.enable) || (t.inbounds || [])[0];
    if (first && !(t.inbounds || []).some(x => Number(x.id) === Number(srv.inbound_id))) {
      await pool.query('UPDATE vps_servers SET inbound_id=$2, protocol=$3 WHERE id=$1', [srv.id, first.id, String(first.protocol || 'vless').toLowerCase()]);
    }
    await pool.query("UPDATE vps_servers SET last_status='online', last_checked_at=now() WHERE id=$1", [srv.id]);
  } catch (e) {
    await pool.query("UPDATE vps_servers SET last_status='error', last_checked_at=now() WHERE id=$1", [srv.id]);
    throw e;
  }
  audit(q.user.id, 'xui_link', { id: srv.id, created }, q.ip);
  s.json({ ok: true, id: srv.id, created, inbounds: (t.inbounds || []).length });
}));

app.delete('/api/admin/servers/:id', need, adm, w(async (q, s) => {
  await pool.query('DELETE FROM vps_servers WHERE id = $1', [q.params.id]);
  audit(q.user.id, 'server_delete', { id: q.params.id }, q.ip);
  s.json({ ok: true });
}));

// รายการ inbound ที่สร้างไว้ใน 3x-ui (ใช้ให้แอดมินเลือกตอนเพิ่มแพ็กเกจ)
app.get('/api/admin/servers/:id/inbounds', need, adm, w(async (q, s) => {
  const srv = (await pool.query('SELECT * FROM vps_servers WHERE id = $1', [parseInt(q.params.id, 10) || 0])).rows[0];
  if (!srv) throw new HttpErr(404, 'ไม่พบเซิร์ฟเวอร์');
  if (srv.type !== '3xui') throw new HttpErr(400, 'เซิร์ฟเวอร์นี้ไม่ใช่ 3x-ui');
  const r = await test3xuiServer(srv);
  s.json({ inbounds: r.inbounds });
}));

// รายการรูปแบบ Config (Profile) ที่สร้างไว้ในแดชบอร์ด XXTLONLINE (ใช้ให้แอดมินเลือกตอนเพิ่มแพ็กเกจ)
app.get('/api/admin/servers/:id/profiles', need, adm, w(async (q, s) => {
  const srv = (await pool.query('SELECT * FROM vps_servers WHERE id = $1', [parseInt(q.params.id, 10) || 0])).rows[0];
  if (!srv) throw new HttpErr(404, 'ไม่พบเซิร์ฟเวอร์');
  if (srv.type !== 'xxt') throw new HttpErr(400, 'เซิร์ฟเวอร์นี้ไม่ใช่แดชบอร์ด XXTLONLINE');
  const r = await xxtCall(srv, 'GET', '/info');
  const i = r.d?.data;
  if (!r.d?.ok || !i) throw xxtFail(r, 'แดชบอร์ดตอบกลับไม่ถูกต้อง');
  s.json({
    profiles: (i.profiles || []).map(p => ({ id: String(p.id), name: String(p.name || p.id) })),
    defaultProfile: i.default_profile || null,
    serverProfile: xxtProfile(srv) || null   // ค่าที่ตั้งไว้ในฟอร์มเซิร์ฟเวอร์ (ถ้ามี)
  });
}));

app.post('/api/admin/servers/:id/test', need, adm, w(async (q, s) => {
  const srv = (await pool.query('SELECT * FROM vps_servers WHERE id = $1', [q.params.id])).rows[0];
  if (!srv) throw new HttpErr(404, 'ไม่พบเซิร์ฟเวอร์');

  if (srv.type === '3xui') {
    try {
      const result = await test3xuiServer(srv);
      await pool.query("UPDATE vps_servers SET last_status='online', last_checked_at=now() WHERE id=$1", [srv.id]);
      return s.json(result);
    } catch (e) {
      await pool.query("UPDATE vps_servers SET last_status='error', last_checked_at=now() WHERE id=$1", [srv.id]);
      throw e;
    }
  }

  if (srv.type === 'xxt') {
    try {
      const r = await xxtCall(srv, 'GET', '/info');
      const i = r.d?.data;
      if (!r.d?.ok || !i) throw xxtFail(r, 'แดชบอร์ดตอบกลับไม่ถูกต้อง');
      await pool.query("UPDATE vps_servers SET last_status='online', last_checked_at=now() WHERE id=$1", [srv.id]);
      return s.json({ ok: true, sample: `เชื่อมต่อแดชบอร์ดสำเร็จ (API Key ใช้ได้)\nHost: ${i.host}  WS Port: ${i.ws_port}\nผู้ใช้ทั้งหมด: ${i.users}  ออนไลน์: ${i.online}\n` +
        `รูปแบบ Config บนแดชบอร์ด (เลือกต่อแพ็กเกจได้ตอนเพิ่ม/แก้ไขแพ็กเกจ / หรือใส่ Profile ID ในฟอร์มเซิร์ฟเวอร์เป็นค่าเริ่มต้น):\n` +
        (i.profiles || []).map(p => `  ${p.id}${p.id === i.default_profile ? ' ★ค่าหลัก' : ''} = ${p.name}`).join('\n') });
    } catch (e) {
      await pool.query("UPDATE vps_servers SET last_status='error', last_checked_at=now() WHERE id=$1", [srv.id]);
      throw e;
    }
  }

  // ทดสอบสร้างข้อความตัวอย่างสำหรับ SSH/UDP
  try {
    const who = await sshExec(srv, 'id -u; command -v useradd chpasswd chage');
    const isRoot = who.split('\n')[0] === '0';
    await pool.query("UPDATE vps_servers SET last_status='online', last_checked_at=now() WHERE id=$1", [srv.id]);
    s.json({ ok: true, sample: `เชื่อมต่อ SSH สำเร็จ\nสิทธิ์ root: ${isRoot ? 'ใช่' : 'ไม่ใช่ (สร้าง user ไม่ได้)'}\n${who}` });
  } catch (e) {
    await pool.query("UPDATE vps_servers SET last_status='error', last_checked_at=now() WHERE id=$1", [srv.id]);
    throw e;
  }
}));

// ---------- Admin: จัดการแพ็กเกจ (Products) ----------
async function saveProduct(c, id, b) {
  const NET = ['AIS', 'TRUE', 'dtac'];
  const PRO = ['SSH', 'V2RAY', 'UDP'];
  if (!NET.includes(b.net) || !PRO.includes(b.proto) || !String(b.title || '').trim()) {
    throw new HttpErr(400, 'ข้อมูลแพ็กเกจไม่ครบ');
  }
  const plans = (b.plans || []).map(k => ({
    n: String(k.n).trim(), tm: parseDurMin(k.d), p: parseFloat(k.p),
    rf: k.rf === undefined || k.rf === null || String(k.rf).trim() === '' ? null : parseFloat(k.rf),
    dc: k.dc === undefined || k.dc === null || String(k.dc).trim() === '' ? 0 : parseFloat(k.dc),
    mc: k.mc === undefined || k.mc === null || String(k.mc).trim() === '' ? null : parseInt(k.mc, 10),
    id: Number(k.id) > 0 ? Number(k.id) : null
  }));
  plans.forEach(k => { k.h = Math.max(1, Math.ceil(k.tm / 60)); k.m = k.tm % 60 === 0 ? null : k.tm; });
  if (!plans.length || plans.some(k => !k.n || !(k.tm > 0) || !(k.p >= 0) || (k.rf !== null && !(k.rf >= 0)) || !(k.dc >= 0 && k.dc <= 90))) {
    throw new HttpErr(400, 'ข้อมูลราคาไม่ถูกต้อง (ส่วนลดต้องอยู่ระหว่าง 0-90%)');
  }
  if (plans.some(k => k.mc !== null && !(k.mc >= 1 && k.mc <= 100))) throw new HttpErr(400, 'จำนวนเชื่อมต่อสูงสุดต้องเป็น 1-100 เครื่อง (เว้นว่าง = ค่าเริ่มต้น)');
  if (new Set(plans.map(k => k.n)).size !== plans.length) throw new HttpErr(400, 'ชื่อแพ็กเกจในสินค้าเดียวกันซ้ำกัน — ตั้งชื่อไม่ให้ซ้ำ');
  const badge = String(b.badge || '').trim().slice(0, 30);
  const serverId = b.serverId ? parseInt(b.serverId, 10) : null;
  const inboundId = serverId && b.inboundId ? (parseInt(b.inboundId, 10) || null) : null;

  // Profile ของแดชบอร์ด XXTLONLINE (เลือกต่อแพ็กเกจ) — เก็บเฉพาะเมื่อแพ็กเกจผูกกับเซิร์ฟเวอร์ประเภท xxt
  let xxtProfileId = null;
  if (serverId) {
    const sv = (await c.query('SELECT type FROM vps_servers WHERE id=$1', [serverId])).rows[0];
    if (!sv) throw new HttpErr(400, 'ไม่พบเซิร์ฟเวอร์ที่เลือก');
    const raw = String(b.xxtProfile || '').trim();
    if (sv.type === 'xxt' && raw) {
      if (!XXT_PROFILE_RE.test(raw)) throw new HttpErr(400, 'Profile ID ไม่ถูกต้อง');
      xxtProfileId = raw;
    }
  }

  if (id) {
    const img = b.img === undefined || b.img === null ? null : b.img;
    await c.query(
      'UPDATE products SET server_id=$2, network=$3, protocol=$4, title=$5, description=$6, badge=$7, image_url=COALESCE($8,image_url), inbound_id=$9, xxt_profile=$10 WHERE id=$1',
      [id, serverId, b.net, b.proto, b.title.trim(), b.desc || '', badge, img, inboundId, xxtProfileId]
    );
  } else {
    id = (await c.query(
      'INSERT INTO products(server_id,network,protocol,title,description,image_url,badge,inbound_id,xxt_profile) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id',
      [serverId, b.net, b.proto, b.title.trim(), b.desc || '', b.img || null, badge, inboundId, xxtProfileId]
    )).rows[0].id;
  }

  const keep = [];
  for (const k of plans) {
    const vals = [k.h, k.p, k.rf, k.dc, k.m, k.mc];
    let pid = null;
    if (k.id) {      // แก้ไขแพ็กเกจเดิมด้วย id → เปลี่ยนชื่อได้โดยไม่สร้างแถวใหม่
      const u = await c.query('UPDATE plans SET name=$3, duration_hours=$4, price=$5, refund_per_day=$6, discount_percent=$7, duration_minutes=$8, max_conns=$9 WHERE id=$1 AND product_id=$2 RETURNING id', [k.id, id, k.n, ...vals]);
      pid = u.rows[0]?.id || null;
    }
    if (!pid) {
      const u = await c.query('UPDATE plans SET duration_hours=$3, price=$4, refund_per_day=$5, discount_percent=$6, duration_minutes=$7, max_conns=$8 WHERE product_id=$1 AND name=$2 RETURNING id', [id, k.n, ...vals]);
      pid = u.rows[0]?.id || null;
    }
    if (!pid) {
      pid = (await c.query('INSERT INTO plans(product_id,name,duration_hours,price,refund_per_day,discount_percent,duration_minutes,max_conns) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id', [id, k.n, ...vals])).rows[0].id;
    }
    keep.push(pid);
  }

  await c.query(
    'DELETE FROM plans WHERE product_id=$1 AND id<>ALL($2::bigint[]) AND id NOT IN (SELECT plan_id FROM orders)',
    [id, keep]
  );
  return id;
}

app.post('/api/admin/products', need, adm, w(async (q, s) => {
  const id = await tx(c => saveProduct(c, null, q.body));
  await touchUpdated();
  audit(q.user.id, 'product_add', { id }, q.ip);
  s.json({ id });
}));

app.put('/api/admin/products/:id', need, adm, w(async (q, s) => {
  await tx(c => saveProduct(c, q.params.id, q.body));
  await touchUpdated();
  audit(q.user.id, 'product_edit', { id: q.params.id }, q.ip);
  s.json({ ok: true });
}));

app.delete('/api/admin/products/:id', need, adm, w(async (q, s) => {
  await pool.query('UPDATE products SET is_hidden=true WHERE id=$1', [q.params.id]);
  await touchUpdated();
  audit(q.user.id, 'product_hide', { id: q.params.id }, q.ip);
  s.json({ ok: true });
}));

// ---------- Admin: เติมเงิน / คูปอง / คืนเงิน / แจ้งปัญหา ----------
app.get('/api/admin/topups', need, adm, w(async (q, s) => {
  const rows = (await pool.query(`
    SELECT t.id, t.method, t.amount, t.bonus_amount, t.proof, t.verify_note, t.created_at, u.username
    FROM topups t JOIN users u ON u.id = t.user_id
    WHERE t.status = 'pending'
    ORDER BY t.id
  `)).rows;
  s.json(rows);
}));

// รายการเติมเงินล่าสุด (ทุกสถานะ) ไว้เช็กว่าระบบตรวจสลิปอนุมัติอัตโนมัติจริงไหม
app.get('/api/admin/topups-recent', need, adm, w(async (q, s) => {
  const rows = (await pool.query(`
    SELECT t.id, t.method, t.amount, t.status, t.verified_by, t.verify_note, t.created_at, u.username
    FROM topups t JOIN users u ON u.id = t.user_id
    ORDER BY t.id DESC
    LIMIT 10
  `)).rows;
  s.json(rows);
}));

app.post('/api/admin/topups/:id/:act', need, adm, w(async (q, s) => {
  const ok = q.params.act === 'approve';
  if (!ok && q.params.act !== 'reject') throw new HttpErr(400, 'bad request');

  await tx(async c => {
    if (ok) {
      await approveTopupInTx(c, q.params.id, 'admin', q.user.id);
    } else {
      const t = (await c.query(
        "UPDATE topups SET status='rejected', verified_by='admin' WHERE id=$1 AND status='pending' RETURNING id",
        [q.params.id]
      )).rows[0];
      if (!t) throw new HttpErr(409, 'รายการนี้ถูกจัดการไปแล้ว');
      audit(q.user.id, 'topup_reject', { id: t.id }, q.ip);
    }
  });

  s.json({ ok: true });
}));

app.get('/api/admin/coupons', need, adm, w(async (q, s) => {
  const rows = (await pool.query('SELECT c.id, c.code, c.percent, c.remaining_uses, c.per_user_limit, c.expires_at, c.created_at, (SELECT count(*) FROM orders o WHERE o.coupon_id = c.id)::int AS used FROM coupons c ORDER BY c.id DESC LIMIT 100')).rows;
  s.json(rows);
}));

app.post('/api/admin/coupons', need, adm, w(async (q, s) => {
  const code = String(q.body.code || '').trim().toUpperCase();
  const percent = parseInt(q.body.percent, 10);
  const remainingUses = parseInt(q.body.remaining_uses, 10);
  const expiresAt = q.body.expires_at ? new Date(q.body.expires_at).toISOString() : null;
  const perUser = q.body.per_user_limit === undefined || q.body.per_user_limit === '' ? 1 : parseInt(q.body.per_user_limit, 10);

  if (!/^[A-Z0-9_-]{2,40}$/.test(code)) throw new HttpErr(400, 'โค้ดส่วนลดใช้ได้เฉพาะ A-Z 0-9 _ - ความยาว 2-40 ตัว');
  if (!(percent >= 1 && percent <= 100)) throw new HttpErr(400, 'ส่วนลดต้องอยู่ระหว่าง 1-100%');
  if (!(remainingUses >= 1)) throw new HttpErr(400, 'จำนวนสิทธิ์ต้องอย่างน้อย 1 ครั้ง');
  if (!(perUser >= 0 && perUser <= 1000)) throw new HttpErr(400, 'สิทธิ์ต่อคนต้องเป็น 0-1000 (0 = ไม่จำกัด)');

  try {
    const r = await pool.query(
      'INSERT INTO coupons(code, percent, remaining_uses, per_user_limit, expires_at) VALUES($1, $2, $3, $4, $5) RETURNING id',
      [code, percent, remainingUses, perUser, expiresAt]
    );
    audit(q.user.id, 'coupon_create', { id: r.rows[0].id, code, percent }, q.ip);
    s.json({ ok: true, id: r.rows[0].id });
  } catch (e) {
    throw e.code === '23505' ? new HttpErr(409, 'โค้ดส่วนลดนี้มีอยู่แล้ว') : e;
  }
}));

app.delete('/api/admin/coupons/:id', need, adm, w(async (q, s) => {
  await pool.query('UPDATE coupons SET remaining_uses = 0 WHERE id = $1', [q.params.id]);
  audit(q.user.id, 'coupon_disable', { id: q.params.id }, q.ip);
  s.json({ ok: true });
}));

const ORDER_STATUSES = ['active', 'expired', 'refunded', 'cancelled'];

// แนบ "เชื่อมต่ออยู่กี่ IP" ให้แต่ละออเดอร์ (เฉพาะเซิร์ฟเวอร์ xxtlonline; ที่เหลือ = null ไม่ทราบ)
async function attachLive(rows) {
  const byServer = new Map();
  for (const r of rows) {
    if (r.server_type === 'xxt' && r.client_email && r.status !== 'refunded') {
      byServer.set(r.server_id, [...(byServer.get(r.server_id) || []), r]);
    }
  }
  for (const [sid, list] of byServer) {
    try {
      const srv = (await pool.query('SELECT * FROM vps_servers WHERE id = $1', [sid])).rows[0];
      const map = srv ? await serverClientStats(srv) : null;
      if (!map) continue;
      for (const r of list) {
        const st = map.get(String(r.client_email));
        if (st && st.conns !== null && st.conns !== undefined) {
          r.live = { conns: st.conns, ips: st.ips ? st.ips.length : null, ipList: st.ips || [] };
        }
      }
    } catch { /* เซิร์ฟเวอร์ตอบไม่ได้ → ไม่แสดงสถานะสด */ }
  }
  return rows;
}

// รายการออเดอร์ทั้งหมด (ค้นหา/กรองได้): ?q=ชื่อผู้ใช้|#เลข|อีเมลบัญชี|ชื่อสินค้า  &status=  &limit=
app.get('/api/admin/orders', need, adm, w(async (q, s) => {
  const where = [], args = [];
  const st = String(q.query.status || '');
  if (ORDER_STATUSES.includes(st)) { args.push(st); where.push(`o.status = $${args.length}`); }
  const kw = String(q.query.q || '').trim().slice(0, 80);
  if (kw) {
    const id = /^#?\d+$/.test(kw) ? parseInt(kw.replace('#', ''), 10) : 0;
    args.push('%' + kw.replace(/[%_\\]/g, m => '\\' + m) + '%');
    const like = `$${args.length}`;
    args.push(id);
    where.push(`(u.username ILIKE ${like} OR o.client_email ILIKE ${like} OR p.title ILIKE ${like} OR pl.name ILIKE ${like} OR o.id = $${args.length})`);
  }
  const limit = Math.min(500, Math.max(1, parseInt(q.query.limit, 10) || 200));
  const rows = (await pool.query(`
    SELECT o.id, o.user_id, o.price_paid, o.status, o.expires_at, o.created_at, o.client_email, o.auto_renew,
           o.server_id, o.deprovisioned_at,
           u.username, p.title, pl.name AS plan_name, pl.max_conns, sv.name AS server_name, sv.type AS server_type
    FROM orders o
    JOIN users u ON u.id = o.user_id
    JOIN plans pl ON pl.id = o.plan_id
    JOIN products p ON p.id = pl.product_id
    LEFT JOIN vps_servers sv ON sv.id = o.server_id
    ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
    ORDER BY o.id DESC LIMIT ${limit}
  `, args)).rows;
  const total = +(await pool.query('SELECT count(*) AS n FROM orders')).rows[0].n;
  s.setHeader('X-Total-Orders', String(total));
  s.json(await attachLive(rows));
}));

// รายละเอียดออเดอร์เต็ม (รวมข้อมูลบัญชีที่ส่งให้ลูกค้า, เซิร์ฟเวอร์, ประวัติเครดิต, เรื่องแจ้งปัญหา)
app.get('/api/admin/orders/:id', need, adm, w(async (q, s) => {
  const id = parseInt(q.params.id, 10);
  if (!(id > 0)) throw new HttpErr(400, 'รหัสคำสั่งซื้อไม่ถูกต้อง');
  const o = (await pool.query(`
    SELECT o.*, u.username, u.is_banned, u.credit_balance,
           p.title, p.id AS product_id, pl.name AS plan_name, pl.price AS plan_price, pl.duration_hours, pl.max_conns,
           sv.name AS server_name, sv.type AS server_type, sv.host AS server_host,
           c.code AS coupon_code, c.percent AS coupon_percent
    FROM orders o
    JOIN users u ON u.id = o.user_id
    JOIN plans pl ON pl.id = o.plan_id
    JOIN products p ON p.id = pl.product_id
    LEFT JOIN vps_servers sv ON sv.id = o.server_id
    LEFT JOIN coupons c ON c.id = o.coupon_id
    WHERE o.id = $1`, [id])).rows[0];
  if (!o) throw new HttpErr(404, 'ไม่พบคำสั่งซื้อ');
  const ledger = (await pool.query(
    `SELECT id, amount, type, note, created_at FROM credit_ledger
      WHERE user_id = $1 AND ref_id = $2 AND type IN ('purchase','refund') ORDER BY id`, [o.user_id, id])).rows;
  const tickets = (await pool.query(
    'SELECT id, subject, status, created_at FROM support_tickets WHERE order_id = $1 ORDER BY id DESC LIMIT 10', [id])).rows;
  let usage = null;
  if (o.server_id && o.server_type === 'xxt' && o.client_email) {
    try {
      const srv = (await pool.query('SELECT * FROM vps_servers WHERE id = $1', [o.server_id])).rows[0];
      const st = (await serverClientStats(srv)).get(String(o.client_email));
      if (st) usage = { used: st.up + st.down, total: st.total };
    } catch { /* ดึงค่าไม่ได้ก็ข้าม */ }
  }
  const [lv] = await attachLive([{ ...o, server_type: o.server_type, server_id: o.server_id }]);
  s.json({ ...o, ledger, tickets, usage, live: lv.live || null });
}));

// แก้ไขออเดอร์ (แก้เฉพาะข้อมูลในร้าน — ไม่ได้สั่งเปลี่ยนบัญชีบนเซิร์ฟเวอร์ VPS)
// แก้ได้: สถานะ (active/expired/cancelled), วันหมดอายุ, ข้อมูลบัญชีที่ลูกค้าเห็น, อีเมล/ชื่อบัญชี, ต่ออายุอัตโนมัติ
// สถานะ refunded ตั้ง/ถอนเองไม่ได้ — ต้องใช้ปุ่ม "คืนเครดิต" เพื่อให้ยอดเครดิตตรงกับ ledger
app.put('/api/admin/orders/:id', need, adm, w(async (q, s) => {
  const id = parseInt(q.params.id, 10);
  if (!(id > 0)) throw new HttpErr(400, 'รหัสคำสั่งซื้อไม่ถูกต้อง');
  const cur = (await pool.query('SELECT * FROM orders WHERE id = $1', [id])).rows[0];
  if (!cur) throw new HttpErr(404, 'ไม่พบคำสั่งซื้อ');
  const b = q.body || {};
  const sets = [], args = [id], diff = {};
  const add = (col, val) => { args.push(val); sets.push(`${col} = $${args.length}`); };

  if (b.status !== undefined && b.status !== cur.status) {
    if (!ORDER_STATUSES.includes(b.status)) throw new HttpErr(400, 'สถานะไม่ถูกต้อง');
    if (b.status === 'refunded') throw new HttpErr(400, 'ตั้งเป็น refunded เองไม่ได้ — ใช้ปุ่ม "คืนเครดิต" เพื่อให้ยอดเครดิตถูกต้อง');
    if (cur.status === 'refunded') throw new HttpErr(400, 'ออเดอร์ที่คืนเงินแล้วแก้สถานะไม่ได้');
    add('status', b.status); diff.status = [cur.status, b.status];
  }
  if (b.expires_at !== undefined) {
    const d = new Date(b.expires_at);
    if (isNaN(d)) throw new HttpErr(400, 'วันหมดอายุไม่ถูกต้อง');
    if (d.getTime() !== new Date(cur.expires_at).getTime()) {
      add('expires_at', d.toISOString()); sets.push('reminded_at = NULL'); diff.expires_at = [cur.expires_at, d.toISOString()];
    }
  }
  if (b.account_data !== undefined) {
    const t = String(b.account_data);
    if (!t.trim()) throw new HttpErr(400, 'ข้อมูลบัญชีต้องไม่ว่าง');
    if (t.length > 20000) throw new HttpErr(400, 'ข้อมูลบัญชียาวเกินไป');
    if (t !== cur.account_data) { add('account_data', t); diff.account_data = 'changed'; }
  }
  if (b.client_email !== undefined) {
    const t = String(b.client_email || '').trim().slice(0, 150) || null;
    if (t !== cur.client_email) { add('client_email', t); diff.client_email = [cur.client_email, t]; }
  }
  if (b.auto_renew !== undefined && !!b.auto_renew !== cur.auto_renew) {
    add('auto_renew', !!b.auto_renew); diff.auto_renew = [cur.auto_renew, !!b.auto_renew];
  }
  if (!sets.length) return s.json({ ok: true, changed: false });
  await pool.query(`UPDATE orders SET ${sets.join(', ')} WHERE id = $1`, args);
  audit(q.user.id, 'admin_order_edit', { orderId: id, ...diff }, q.ip);
  s.json({ ok: true, changed: true });
}));

// คำนวณยอดคืนเงิน: จำนวนวันที่เหลือ × ราคาคืนต่อวัน (ตั้งต่อแพ็กเกจ; ว่าง = ราคาแพ็กเกจ ÷ จำนวนวัน)
const r2 = n => Math.round(n * 100) / 100;
async function refundCalc(db, ord) {
  const sum = +(await db.query(
    "SELECT COALESCE(-sum(amount), 0) AS s FROM credit_ledger WHERE type = 'purchase' AND ref_id = $1 AND user_id = $2",
    [ord.id, ord.user_id]
  )).rows[0].s;
  const paidFirst = +ord.price_paid;
  const paidTotal = Math.max(paidFirst, sum);
  const remainingDays = new Date(ord.expires_at) > new Date() ? Math.ceil((new Date(ord.expires_at) - Date.now()) / 86400e3) : 0;
  const planDays = Math.max(1, Number(ord.duration_hours) / 24);
  const hasRate = ord.refund_per_day !== null && ord.refund_per_day !== undefined;
  const ratePerDay = hasRate ? +ord.refund_per_day : r2(+ord.plan_price / planDays);
  const raw = r2(remainingDays * ratePerDay);
  return {
    orderId: ord.id, status: ord.status, expiresAt: ord.expires_at, planDays,
    paidFirst, paidTotal, remainingDays, ratePerDay, rateSource: hasRate ? 'plan' : 'auto',
    prorata: Math.min(raw, paidTotal), capped: raw > paidTotal
  };
}
const REFUND_SQL = `
  SELECT o.id, o.user_id, o.price_paid, o.status, o.client_email, o.client_uuid, o.server_id, o.inbound_id, o.expires_at,
         pl.duration_hours, pl.price AS plan_price, pl.refund_per_day, pl.name AS plan_name, p.title, u.username
  FROM orders o
  JOIN plans pl ON pl.id = o.plan_id
  JOIN products p ON p.id = pl.product_id
  JOIN users u ON u.id = o.user_id
  WHERE o.id = $1`;

app.get('/api/admin/orders/:id/refund-preview', need, adm, w(async (q, s) => {
  const orderId = parseInt(q.params.id, 10);
  const ord = (await pool.query(REFUND_SQL, [orderId])).rows[0];
  if (!ord) throw new HttpErr(404, 'ไม่พบคำสั่งซื้อ');
  s.json({ ...(await refundCalc(pool, ord)), title: ord.title, planName: ord.plan_name, username: ord.username });
}));

app.get('/api/admin/plans', need, adm, w(async (q, s) => {
  s.json((await pool.query('SELECT id, product_id, name, refund_per_day, discount_percent, max_conns FROM plans')).rows);
}));

app.post('/api/admin/orders/:id/refund', need, adm, w(async (q, s) => {
  const orderId = parseInt(q.params.id, 10);
  if (!(orderId > 0)) throw new HttpErr(400, 'รหัสคำสั่งซื้อไม่ถูกต้อง');
  const force = q.body?.force === true;                    // คืนเงินต่อแม้ปิดบัญชีบนเซิร์ฟเวอร์ไม่สำเร็จ
  const includeRenewals = q.body?.includeRenewals === true; // โหมด full: รวมค่าต่ออายุด้วย
  const mode = ['prorata', 'full', 'custom'].includes(q.body?.mode) ? q.body.mode : 'full'; // ไม่ส่ง mode = พฤติกรรมเดิม

  const out = await tx(async c => {
    const ord = (await c.query(REFUND_SQL + ' FOR UPDATE OF o', [orderId])).rows[0];
    if (!ord) throw new HttpErr(404, 'ไม่พบคำสั่งซื้อ');
    if (ord.status === 'refunded') throw new HttpErr(409, 'คำสั่งซื้อนี้คืนเงินไปแล้ว');

    const calc = await refundCalc(c, ord);
    let amount;
    let label;
    if (mode === 'prorata') {
      amount = calc.prorata;
      label = `คืนตามวันที่เหลือ ${calc.remainingDays} วัน × ${calc.ratePerDay} ฿`;
    } else if (mode === 'custom') {
      amount = r2(parseFloat(q.body?.customAmount));
      if (!(amount >= 0) || amount > calc.paidTotal) {
        throw new HttpErr(400, `ยอดคืนต้องอยู่ระหว่าง 0 - ${calc.paidTotal} บาท`);
      }
      label = 'คืนตามที่แอดมินกำหนด';
    } else {
      amount = includeRenewals ? calc.paidTotal : calc.paidFirst;
      label = includeRenewals ? 'คืนเต็มรวมค่าต่ออายุ' : 'คืนเต็มราคาซื้อครั้งแรก';
    }

    // ปิด/ลบบัญชีบนเซิร์ฟเวอร์ก่อน แล้วค่อยคืนเงิน
    let account = 'skipped';
    if (ord.server_id) {
      const server = (await c.query('SELECT * FROM vps_servers WHERE id = $1', [ord.server_id])).rows[0];
      if (server) {
        try {
          account = await deprovisionAccount(server, ord, 'delete');
        } catch (e) {
          if (!force) {
            throw new HttpErr(502, `ปิดบัญชีบนเซิร์ฟเวอร์ไม่สำเร็จ: ${e.message} (ยังไม่ได้คืนเงิน)`, 'DEPROV_FAILED');
          }
          account = 'failed_forced';
        }
      }
    }

    await c.query("UPDATE orders SET status = 'refunded', deprovisioned_at = now() WHERE id = $1", [ord.id]);
    if (amount > 0) {
      await c.query(
        "INSERT INTO credit_ledger(user_id,amount,type,ref_id,note) VALUES($1,$2,'refund',$3,$4)",
        [ord.user_id, amount, ord.id, `คืนเงินคำสั่งซื้อ #${ord.id} (${label})`]
      );
    }
    return { amount, account, mode, remainingDays: calc.remainingDays, ratePerDay: calc.ratePerDay };
  });

  audit(q.user.id, 'order_refund', { orderId, ...out, force, includeRenewals }, q.ip);
  s.json({ ok: true, ...out });
}));

app.get('/api/admin/tickets', need, adm, w(async (q, s) => {
  const rows = (await pool.query(`
    SELECT t.id, t.user_id, t.order_id, t.subject, t.message, t.reply, t.status, t.created_at, t.updated_at, u.username
    FROM support_tickets t JOIN users u ON u.id = t.user_id
    ORDER BY CASE t.status WHEN 'open' THEN 0 WHEN 'answered' THEN 1 ELSE 2 END, t.updated_at DESC
    LIMIT 100
  `)).rows;
  await attachTicketMessages(rows);
  s.json(rows);
}));

app.post('/api/admin/tickets/:id/reply', need, adm, w(async (q, s) => {
  const ticketId = parseInt(q.params.id, 10);
  const reply = String(q.body.reply || '').trim().slice(0, 2000);
  const status = ['closed', 'open'].includes(q.body.status) ? q.body.status : 'answered';
  if (!Number.isSafeInteger(ticketId)) throw new HttpErr(404, 'ไม่พบรายการแจ้งปัญหา');
  if (!reply && status === 'answered') throw new HttpErr(400, 'กรุณากรอกข้อความตอบกลับ');

  const upd = await pool.query(
    'UPDATE support_tickets SET reply=COALESCE($1, reply), status=$2, updated_at=now() WHERE id=$3 RETURNING id',
    [reply || null, status, ticketId]
  );
  if (!upd.rows.length) throw new HttpErr(404, 'ไม่พบรายการแจ้งปัญหา');
  if (reply) await pool.query('INSERT INTO ticket_messages(ticket_id, sender, body) VALUES($1,$2,$3)', [ticketId, 'admin', reply]);

  audit(q.user.id, 'ticket_reply', { ticketId, status }, q.ip);
  s.json({ ok: true });
}));

// =====================================================
// ดีเลย์การเช็กข้อความซัพพอร์ต ตามภาระเครื่อง (หลังบ้าน → ตั้งค่าเว็บไซต์ → ดีเลย์เช็กข้อความซัพพอร์ต)
// หน้าเว็บลูกค้าเช็ก /api/me/unread เป็นระยะ (ตัวเลขที่ปุ่มซัพพอร์ต / แชตที่เปิดค้าง) — เซิร์ฟเวอร์บอกช่วงเช็กรอบถัดไปกลับไปในคำตอบ
// auto  = เครื่องว่างใช้ช่วงปกติ เครื่องหนักค่อย ๆ ห่างขึ้นถึงค่าสูงสุด (ดูภาระจาก CPU / ความหน่วงโปรเซส / RAM / load)
// manual = ใช้ช่วงปกติคงที่ตลอด
// =====================================================
const perfFs = require('fs');
const perfOs = require('os');
const { monitorEventLoopDelay: perfLagHist } = require('perf_hooks');

const PERF_DEF = { mode: 'auto', poll_min: 5, poll_max: 30 };   // วินาที
let perfCfg = { ...PERF_DEF }, perfCfgAt = 0;
const perfClamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
const perfInt = (v, d) => (Number.isFinite(parseInt(v, 10)) ? parseInt(v, 10) : d);

function perfClean(o, base = PERF_DEF) {
  const mode = ['auto', 'manual'].includes(o.mode) ? o.mode : base.mode;
  const poll_min = perfClamp(perfInt(o.poll_min, base.poll_min), 3, 60);       // ต่ำสุด 3 วิ (ลิมิตต่อ IP คือ 40 ครั้ง/นาที)
  const poll_max = perfClamp(perfInt(o.poll_max, base.poll_max), poll_min, 120);
  return { mode, poll_min, poll_max };
}

async function perfLoad(force) {
  if (!force && Date.now() - perfCfgAt < 15e3) return perfCfg;
  try {
    const rows = (await pool.query("SELECT key, value FROM settings WHERE left(key, 5) = 'perf_'")).rows;
    const o = {};
    for (const r of rows) o[r.key.slice(5)] = r.value;
    perfCfg = perfClean(o);
  } catch (e) { /* ใช้ค่าเดิม */ }
  perfCfgAt = Date.now();
  return perfCfg;
}

// ---------- ตัวตรวจภาระเครื่อง (สุ่มทุก 5 วินาที) ----------
const PERF = { cpu: 0, lag_ms: 0, mem_free_pct: 100, load_pct: 0, score: 0, level: 'ok' };
const perfLag = perfLagHist({ resolution: 20 });
perfLag.enable();
const perfCpuTimes = () => {
  let idle = 0, total = 0;
  for (const c of perfOs.cpus()) { for (const k in c.times) total += c.times[k]; idle += c.times.idle; }
  return { idle, total };
};
let perfPrevCpu = perfCpuTimes();
function perfMemFreePct() {
  try {
    const t = perfFs.readFileSync('/proc/meminfo', 'utf8');
    const a = /MemAvailable:\s+(\d+)/.exec(t), tot = /MemTotal:\s+(\d+)/.exec(t);
    if (a && tot) return (a[1] / tot[1]) * 100;
  } catch (e) { /* ไม่ใช่ Linux */ }
  return (perfOs.freemem() / perfOs.totalmem()) * 100;
}
const perfNorm = (v, lo, hi) => perfClamp((v - lo) / (hi - lo), 0, 1);
setInterval(() => {
  const cur = perfCpuTimes();
  const dt = cur.total - perfPrevCpu.total, di = cur.idle - perfPrevCpu.idle;
  perfPrevCpu = cur;
  const cpu = dt > 0 ? Math.round((1 - di / dt) * 100) : 0;
  let lag = perfLag.percentile(99) / 1e6;
  perfLag.reset();
  if (!Number.isFinite(lag)) lag = 0;
  const mem = perfMemFreePct();
  const load = (perfOs.loadavg()[0] / Math.max(1, perfOs.cpus().length)) * 100;
  // คะแนน 0..1 = ตัวที่แย่สุดของ 4 ค่า (CPU 60→95% • lag 50→300ms • RAM ว่าง 15→5% • load 80→150%)
  const raw = Math.max(perfNorm(cpu, 60, 95), perfNorm(lag, 50, 300), perfNorm(15 - mem, 0, 10), perfNorm(load, 80, 150));
  PERF.score = PERF.score + (raw - PERF.score) * (raw > PERF.score ? 0.6 : 0.2); // ขึ้นเร็ว ลงช้า กันแกว่ง
  PERF.cpu = cpu;
  PERF.lag_ms = Math.round(lag);
  PERF.mem_free_pct = Math.round(mem);
  PERF.load_pct = Math.round(load);
  PERF.level = PERF.score < 0.25 ? 'ok' : PERF.score < 0.6 ? 'busy' : 'overloaded';
}, 5000).unref();

// ช่วงเช็กข้อความซัพพอร์ตรอบถัดไป (มิลลิวินาที)
const perfPollNow = c => Math.round(1000 * (c.mode === 'manual'
  ? c.poll_min
  : c.poll_min + (c.poll_max - c.poll_min) * Math.pow(PERF.score, 1.5)));

async function perfPublic() {
  const cfg = await perfLoad();
  return {
    cfg,
    cores: perfOs.cpus().length,
    status: {
      level: PERF.level, score: +PERF.score.toFixed(2), cpu: PERF.cpu, lag_ms: PERF.lag_ms,
      mem_free_pct: PERF.mem_free_pct, load_pct: PERF.load_pct, poll_ms: perfPollNow(cfg)
    }
  };
}

app.get('/api/admin/perf', need, adm, w(async (q, s) => s.json(await perfPublic())));

app.put('/api/admin/perf', need, adm, w(async (q, s) => {
  const c = perfClean(q.body || {}, await perfLoad());
  for (const [k, v] of Object.entries(c)) {
    await pool.query(
      'INSERT INTO settings(key,value,is_secret) VALUES($1,$2,FALSE) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value',
      ['perf_' + k, String(v)]
    );
  }
  perfCfg = c; perfCfgAt = Date.now();
  audit(q.user.id, 'perf_update', { name: `ดีเลย์เช็กข้อความซัพพอร์ต: ${c.mode} ${c.poll_min}-${c.poll_max} วินาที` }, q.ip);
  s.json({ ok: true, ...(await perfPublic()) });
}));

// ---------- static + errors ----------
app.use(express.static(require('path').join(__dirname, 'public')));

app.get('/api/admin/conn', need, adm, w(async (q, s) => {
  s.set('Cache-Control', 'no-store');
  const cfg = await connLoad(true);
  const rows = (await pool.query(`
    SELECT o.id, o.client_email, o.status, o.conn_block_until, o.conn_strikes, o.conn_last_block_at, u.username, p.title, pl.name AS plan_name, pl.max_conns
    FROM orders o JOIN users u ON u.id = o.user_id JOIN plans pl ON pl.id = o.plan_id JOIN products p ON p.id = pl.product_id
    WHERE o.conn_block_until > now() OR o.conn_last_block_at > now() - interval '7 days'
    ORDER BY (o.conn_block_until > now()) DESC NULLS LAST, o.conn_last_block_at DESC NULLS LAST LIMIT 100`)).rows;
  s.json({ cfg, def: CONN_DEF, rows });
}));
app.put('/api/admin/conn', need, adm, w(async (q, s) => {
  const cfg = connClean(q.body || {}, connCfg);
  for (const [k, v] of Object.entries(cfg)) {
    await pool.query('INSERT INTO settings(key,value,is_secret) VALUES($1,$2,FALSE) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value', ['conn_' + k, String(v)]);
  }
  connCfg = cfg; connCfgAt = Date.now();
  audit(q.user.id, 'conn_settings', cfg, q.ip);
  s.json({ ok: true, cfg });
}));
app.post('/api/admin/conn/:id/unblock', need, adm, w(async (q, s) => {
  const o = (await pool.query('SELECT id, status, client_email, server_id FROM orders WHERE id=$1', [+q.params.id])).rows[0];
  if (!o) throw new HttpErr(404, 'ไม่พบออเดอร์');
  await connRelease(o, true);
  if (q.body && q.body.reset) await pool.query('UPDATE orders SET conn_strikes=0, conn_last_block_at=NULL WHERE id=$1', [o.id]);
  audit(q.user.id, 'conn_unblock', { orderId: o.id, reset: !!(q.body && q.body.reset) }, q.ip);
  s.json({ ok: true });
}));

app.use((e, q, s, n) => {
  if (e instanceof HttpErr) return s.status(e.status).json({ error: e.message, code: e.code });
  if (e.type === 'entity.too.large') return s.status(413).json({ error: 'ไฟล์ใหญ่เกินไป' });
  console.error(e);
  s.status(500).json({ error: 'เซิร์ฟเวอร์ผิดพลาด ลองใหม่อีกครั้ง' });
});

// ปิดบัญชีที่หมดอายุจริงบนเซิร์ฟเวอร์ (3x-ui: disable client / SSH: lock user + kick session)
async function deprovisionExpired() {
  const rows = (await pool.query(`
    SELECT id, client_email, client_uuid, server_id, inbound_id
    FROM orders
    WHERE status = 'expired' AND deprovisioned_at IS NULL AND server_id IS NOT NULL
      AND (deprov_tried_at IS NULL OR deprov_tried_at < now() - interval '5 minutes')
    ORDER BY deprov_tried_at NULLS FIRST, id
    LIMIT 20
  `)).rows;

  for (const o of rows) {
    await pool.query('UPDATE orders SET deprov_tried_at = now() WHERE id = $1', [o.id]);
    try {
      const server = (await pool.query('SELECT * FROM vps_servers WHERE id = $1', [o.server_id])).rows[0];
      const result = server ? await deprovisionAccount(server, o, 'disable') : 'no_server';
      await pool.query("UPDATE orders SET deprovisioned_at = now() WHERE id = $1 AND status = 'expired'", [o.id]);
      audit(null, 'order_deprovision', { orderId: o.id, result }, null);
    } catch (e) {
      console.error(`ปิดบัญชีหมดอายุ order #${o.id} ไม่สำเร็จ:`, e.message);
    }
  }
}

// คอลัมน์ purged_at (ลบไฟล์ที่หมดอายุอัตโนมัติ) — สร้างให้เองถ้ายังไม่มี ไม่ต้องรัน schema.sql ใหม่
(async () => {
  try { await pool.query('ALTER TABLE orders ADD COLUMN IF NOT EXISTS purged_at TIMESTAMPTZ'); }
  catch (e) { console.error('migrate purged_at', e.message); }
})();

// =====================================================
// จำกัดการเชื่อมต่อต่อไฟล์: เกินที่แพ็กเกจกำหนด → ตัดการเชื่อมต่อชั่วคราว แล้วเปิดให้ใช้ใหม่เอง
// ใช้กับเซิร์ฟเวอร์ XXTLONLINE (รู้จำนวนการเชื่อมต่อจริง) เฉพาะแพ็กเกจที่ตั้ง "เชื่อมต่อสูงสุด (เครื่อง)" ไว้
// ตั้งค่า/ดู/ปลดการตัดได้ที่หลังบ้าน → การเชื่อมต่อไฟล์ (เก็บในตาราง settings คีย์ conn_*) — ค่าเริ่มต้นอ่านจาก .env
// =====================================================
const CONN_DEF = {
  enabled: String(process.env.CONN_LIMIT_ENABLED || 'true').toLowerCase() !== 'false',
  block_minutes: Math.max(1, Number(process.env.CONN_BLOCK_MINUTES) || 3),   // ครั้งที่ 1
  block_minutes_2: 10,                                                       // ครั้งที่ 2 (ทำผิดซ้ำภายในช่วงรีเซ็ต)
  block_minutes_3: 30,                                                       // ครั้งที่ 3 ขึ้นไป
  escalate: false,                                                           // เปิด = ตัดนานขึ้นเมื่อทำผิดซ้ำ
  reset_hours: 24,                                                           // ไม่ทำผิดนานเท่านี้ → นับครั้งใหม่
  confirm_rounds: 2,                                                         // เกินติดกันกี่รอบเช็กถึงตัด
  check_seconds: Math.max(10, Number(process.env.CONN_CHECK_SECONDS) || 20) // เช็กทุกกี่วินาที
};
let connCfg = { ...CONN_DEF }, connCfgAt = 0;
const connInt = (v, d, lo, hi) => { const n = parseInt(v, 10); return Math.min(hi, Math.max(lo, Number.isFinite(n) ? n : d)); };
const connBool = (v, d) => (v === undefined || v === null || v === '' ? d : ['true', '1', 'on', 'yes'].includes(String(v).toLowerCase()));
function connClean(o, base = CONN_DEF) {
  return {
    enabled: connBool(o.enabled, base.enabled),
    block_minutes: connInt(o.block_minutes, base.block_minutes, 1, 1440),
    block_minutes_2: connInt(o.block_minutes_2, base.block_minutes_2, 1, 1440),
    block_minutes_3: connInt(o.block_minutes_3, base.block_minutes_3, 1, 1440),
    escalate: connBool(o.escalate, base.escalate),
    reset_hours: connInt(o.reset_hours, base.reset_hours, 1, 720),
    confirm_rounds: connInt(o.confirm_rounds, base.confirm_rounds, 1, 5),
    check_seconds: connInt(o.check_seconds, base.check_seconds, 10, 300)
  };
}
async function connLoad(force) {
  if (!force && Date.now() - connCfgAt < 10e3) return connCfg;
  try {
    const rows = (await pool.query("SELECT key, value FROM settings WHERE left(key, 5) = 'conn_'")).rows;
    const o = {};
    for (const r of rows) o[r.key.slice(5)] = r.value;
    connCfg = connClean(o);
  } catch (e) { /* ใช้ค่าเดิม */ }
  connCfgAt = Date.now();
  return connCfg;
}
const connMinutesFor = (cfg, n) => (!cfg.escalate || n <= 1 ? cfg.block_minutes : n === 2 ? cfg.block_minutes_2 : cfg.block_minutes_3);
const connOver = new Map();   // orderId → จำนวนรอบติดกันที่เกินกำหนด
(async () => {
  try {
    await pool.query('ALTER TABLE orders ADD COLUMN IF NOT EXISTS conn_block_until TIMESTAMPTZ');
    await pool.query('ALTER TABLE orders ADD COLUMN IF NOT EXISTS conn_strikes INTEGER NOT NULL DEFAULT 0');
    await pool.query('ALTER TABLE orders ADD COLUMN IF NOT EXISTS conn_last_block_at TIMESTAMPTZ');
  } catch (e) { console.error('migrate conn_block', e.message); }
})();

// เปิดบัญชีกลับ (resume) แล้วล้างสถานะถูกตัด — ใช้ทั้งตอนครบเวลา และตอนแอดมินกดปลดเอง
async function connRelease(o, force) {
  if (o.status === 'active' && o.server_id && o.client_email) {
    const server = (await pool.query('SELECT * FROM vps_servers WHERE id=$1', [o.server_id])).rows[0];
    if (server && server.type === 'xxt') {
      const r = await xxtCall(server, 'POST', `/users/${needSafeUser(o.client_email)}/resume`);
      if (!r.d?.ok && !xxtNotFound(r)) throw new Error('resume ไม่สำเร็จ');
    }
  }
  await pool.query(force ? 'UPDATE orders SET conn_block_until=NULL WHERE id=$1' : 'UPDATE orders SET conn_block_until=NULL WHERE id=$1 AND conn_block_until <= now()', [o.id]);
  connOver.delete(o.id);
}

let connSweeping = false;
async function connLimitSweep() {
  if (connSweeping) return;
  connSweeping = true;
  try {
    const cfg = await connLoad();
    // 1) เปิดบัญชีที่ครบเวลาตัดแล้ว (ทำเสมอ แม้ปิดระบบไปแล้ว จะได้ไม่มีใครค้างถูกตัด)
    const due = (await pool.query(
      "SELECT id, status, client_email, server_id FROM orders WHERE conn_block_until IS NOT NULL AND conn_block_until <= now() LIMIT 50")).rows;
    for (const o of due) {
      try { await connRelease(o, false); }
      catch (e) { console.error(`เปิดบัญชีหลังตัดการเชื่อมต่อ order #${o.id} ไม่สำเร็จ (จะลองใหม่):`, e.message); }
    }
    if (!cfg.enabled) { connOver.clear(); return; }

    // 2) ตรวจจำนวนการเชื่อมต่อของออเดอร์ที่ใช้งานอยู่และมีกำหนดจำนวนเครื่อง
    const servers = (await pool.query("SELECT * FROM vps_servers WHERE is_active AND type='xxt'")).rows;
    for (const server of servers) {
      let stats;
      try { stats = await serverClientStatsFetch(server); } catch { continue; }
      const ords = (await pool.query(`
        SELECT o.id, o.client_email, o.conn_strikes, o.conn_last_block_at, pl.max_conns
        FROM orders o JOIN plans pl ON pl.id = o.plan_id
        WHERE o.server_id = $1 AND o.status = 'active' AND o.expires_at > now()
          AND o.conn_block_until IS NULL AND pl.max_conns IS NOT NULL AND pl.max_conns > 0 AND o.client_email IS NOT NULL`, [server.id])).rows;
      for (const o of ords) {
        const st = stats.get(String(o.client_email));
        if (!st || !Number.isFinite(st.conns) || st.conns <= o.max_conns) { connOver.delete(o.id); continue; }
        const n = (connOver.get(o.id) || 0) + 1;
        connOver.set(o.id, n);
        if (n < cfg.confirm_rounds) continue;
        try {
          const r = await xxtCall(server, 'POST', `/users/${needSafeUser(o.client_email)}/suspend`);
          if (!r.d?.ok) throw new Error('suspend ไม่สำเร็จ');
          const fresh = o.conn_last_block_at && (Date.now() - new Date(o.conn_last_block_at).getTime()) < cfg.reset_hours * 3600e3;
          const strike = (fresh ? o.conn_strikes : 0) + 1;
          const minutes = connMinutesFor(cfg, strike);
          await pool.query('UPDATE orders SET conn_block_until = now() + make_interval(mins => $2::int), conn_strikes = $3, conn_last_block_at = now() WHERE id=$1', [o.id, minutes, strike]);
          connOver.delete(o.id);
          audit(null, 'conn_limit_block', { orderId: o.id, conns: st.conns, limit: o.max_conns, minutes, strike }, null);
        } catch (e) { console.error(`ตัดการเชื่อมต่อ order #${o.id} ไม่สำเร็จ:`, e.message); }
      }
    }
  } catch (e) {
    console.error('conn limit sweep', e.message);
  } finally {
    connSweeping = false;
  }
}
(function connLoop() {
  setTimeout(async () => { await connLimitSweep().catch(() => {}); connLoop(); }, connCfg.check_seconds * 1000);
})();

let sweeping = false;
setInterval(async () => {
  if (sweeping) return;
  sweeping = true;
  try {
    await pool.query("UPDATE orders SET status='expired' WHERE status='active' AND expires_at < now()");
    await deprovisionExpired();
    // ลบไฟล์/ข้อมูลบัญชีที่หมดอายุเกินกำหนด (ค่าเริ่มต้น 72 ชม.) — เก็บแถวออเดอร์ไว้เป็นประวัติ แต่ลบ account_data และซ่อนจากหน้าลูกค้า
    await pool.query(
      "UPDATE orders SET account_data=$1, purged_at=now(), auto_renew=FALSE WHERE status='expired' AND purged_at IS NULL AND expires_at < now() - make_interval(hours => $2::int)",
      [enc(''), EXPIRED_KEEP_HOURS]
    );
    // ต่ออายุอัตโนมัติ: ออเดอร์ที่เปิดไว้และจะหมดภายใน 6 ชม. (ลองใหม่ได้ชั่วโมงละครั้งถ้าเครดิตไม่พอ/ผิดพลาด)
    const ar = (await pool.query(`
      SELECT o.id, o.user_id, u.username FROM orders o JOIN users u ON u.id = o.user_id
      WHERE o.auto_renew AND o.status = 'active' AND NOT u.is_banned
        AND o.expires_at <= now() + interval '6 hours'
        AND (o.auto_renew_tried_at IS NULL OR o.auto_renew_tried_at < now() - interval '1 hour')
      LIMIT 20
    `)).rows;
    for (const r of ar) {
      await pool.query('UPDATE orders SET auto_renew_tried_at = now() WHERE id = $1', [r.id]);
      try {
        const out = await renewOrderCore(r.id, { id: r.user_id, username: r.username });
        audit(r.user_id, 'order_auto_renew', out, null);
      } catch (e) {
        audit(r.user_id, 'order_auto_renew_fail', { orderId: r.id, error: e.message }, null);
      }
    }
    const soonRows = (await pool.query(`
      SELECT o.id, o.expires_at, u.username, p.title, pl.name AS plan_name
      FROM orders o
      JOIN users u ON u.id = o.user_id
      JOIN plans pl ON pl.id = o.plan_id
      JOIN products p ON p.id = pl.product_id
      WHERE o.status = 'active'
        AND o.reminded_at IS NULL
        AND o.expires_at > now()
        AND o.expires_at <= now() + interval '24 hours'
        AND pl.price > 0
      LIMIT 50
    `)).rows;

    for (const r of soonRows) {
      await notifyExternal(`⏰ แจ้งเตือนแพ็กเกจใกล้หมดอายุ: ออเดอร์ #${r.id} ของคุณ ${r.username} (${r.title} – ${r.plan_name}) จะหมดอายุ ${new Date(r.expires_at).toLocaleString('th-TH')}`);
      await pool.query('UPDATE orders SET reminded_at = now() WHERE id = $1', [r.id]);
    }
  } catch (err) {
    console.error(err);
  } finally {
    sweeping = false;
  }
}, 60e3);

// ตัวเช็กสถานะเซิร์ฟเวอร์เป็นระยะ (ทุก 2 นาที) — พลาดติดกัน 2 รอบถึงถือว่าออฟไลน์ (กันสะดุดชั่วคราว) แล้วหน้าร้านจะซ่อนแพ็กเกจของเครื่องนั้น
// กลับมาเชื่อมต่อได้เมื่อไหร่ แพ็กเกจจะกลับมาเองและแจ้งเตือนผ่าน webhook/Telegram ทั้งตอนล่มและตอนกลับมา
const withTimeout = (p, ms = 20000) => Promise.race([p, new Promise((_, rj) => setTimeout(() => rj(new Error('timeout')), ms))]);
async function probeServer(srv) {
  if (srv.type === '3xui') return withTimeout(login3xui(srv));
  if (srv.type === 'xxt') {
    const r = await withTimeout(xxtCall(srv, 'GET', '/ping'));
    if (!r?.d?.ok) throw new Error('แดชบอร์ดตอบกลับไม่ถูกต้อง');
    return;
  }
  return withTimeout(sshExec(srv, 'echo ok'));
}
let probing = false;
async function healthSweep() {
  if (probing) return;
  probing = true;
  try {
    const rows = (await pool.query('SELECT * FROM vps_servers WHERE is_active')).rows;
    await Promise.allSettled(rows.map(async srv => {
      let err = null;
      try { await probeServer(srv); } catch (e) { err = e.message || 'error'; }
      if (!err) {
        await pool.query("UPDATE vps_servers SET last_status='online', fail_count=0, last_checked_at=now() WHERE id=$1", [srv.id]);
        if (srv.last_status === 'error') notifyExternal(`✅ เซิร์ฟเวอร์ ${srv.name} กลับมาออนไลน์แล้ว แพ็กเกจกลับมาขายตามปกติ`);
      } else {
        const fc = (srv.fail_count || 0) + 1;
        const status = fc >= 2 ? 'error' : srv.last_status;
        await pool.query('UPDATE vps_servers SET fail_count=$2, last_status=$3, last_checked_at=now() WHERE id=$1', [srv.id, fc, status]);
        if (fc >= 2 && srv.last_status !== 'error') notifyExternal(`🔴 เซิร์ฟเวอร์ ${srv.name} เชื่อมต่อไม่ได้ (${String(err).slice(0, 120)}) ระบบซ่อนแพ็กเกจของเครื่องนี้ชั่วคราว`);
      }
    }));
  } catch (e) {
    console.error('health check', e.message);
  } finally {
    probing = false;
  }
}
setInterval(healthSweep, 120e3);
setTimeout(healthSweep, 15e3);

// เพิ่มคอลัมน์ user_read_at (แจ้งเตือนตอบกลับซัพพอร์ต) ถ้ายังไม่มี — รายการที่ตอบไปแล้วก่อนอัปเดตจะถือว่าอ่านแล้ว
(async () => {
  try {
    const has = (await pool.query(
      "SELECT 1 FROM information_schema.columns WHERE table_name='support_tickets' AND column_name='user_read_at'")).rows.length;
    if (!has) {
      await pool.query('ALTER TABLE support_tickets ADD COLUMN IF NOT EXISTS user_read_at TIMESTAMPTZ');
      await pool.query('UPDATE support_tickets SET user_read_at = now() WHERE reply IS NOT NULL AND user_read_at IS NULL');
    }
  } catch (e) { console.error('migrate user_read_at', e.message); }
})();

// ตาราง ticket_messages (โต้ตอบหลายรอบ) — สร้างเองตอนเริ่มระบบ เพื่อให้อัปเดตจากเมนูแล้วใช้ได้เลย
(async () => {
  try {
    await pool.query(`CREATE TABLE IF NOT EXISTS ticket_messages (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      ticket_id BIGINT NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
      sender VARCHAR(5) NOT NULL CHECK (sender IN ('user','admin')),
      body TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now())`);
    await pool.query('CREATE INDEX IF NOT EXISTS idx_ticket_messages_ticket ON ticket_messages (ticket_id, id)');
    // ย้ายคำตอบเดิมของแอดมิน (คอลัมน์ reply) เข้าเป็นข้อความ — ทำครั้งเดียวต่อเรื่อง
    await pool.query(`INSERT INTO ticket_messages(ticket_id, sender, body, created_at)
      SELECT t.id, 'admin', t.reply, t.updated_at FROM support_tickets t
      WHERE t.reply IS NOT NULL AND t.reply <> '' AND NOT EXISTS (SELECT 1 FROM ticket_messages m WHERE m.ticket_id = t.id)`);
  } catch (e) { console.error('migrate ticket_messages', e.message); }
})();

// เตือนถ้ายังไม่มีแอดมินในระบบ: คนที่สมัครด้วยชื่อ ADMIN_USERNAME ก่อนจะได้เป็นแอดมิน
pool.query("SELECT 1 FROM users WHERE role = 'admin' LIMIT 1").then(r => {
  if (!r.rows.length) {
    console.warn(ADMIN_USERNAME
      ? `⚠️  ยังไม่มีแอดมินในระบบ — สมัครบัญชีชื่อ "${ADMIN_USERNAME}" ทันทีหลังติดตั้ง ก่อนมีคนอื่นใช้ชื่อนี้`
      : '⚠️  ยังไม่มีแอดมิน และไม่ได้ตั้ง ADMIN_USERNAME ใน .env');
  }
}).catch(() => {});

app.listen(process.env.PORT || 3000, process.env.HOST || '0.0.0.0', () => console.log('Wselx Shop v3 พร้อมใช้งานที่', (process.env.HOST || '0.0.0.0') + ':' + (process.env.PORT || 3000)));
