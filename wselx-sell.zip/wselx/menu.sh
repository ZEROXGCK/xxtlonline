#!/usr/bin/env bash
# =====================================================================
# Wselx — เมนูจัดการเซิร์ฟเวอร์ (พิมพ์ menu หรือ wselx-menu บน VPS)
# ติดตั้งให้อัตโนมัติโดย install.sh / setup.sh (ที่ /usr/local/bin/wselx-menu และ /usr/local/bin/menu)
#
# ตั้งค่าเพิ่มได้ที่ /etc/wselx-menu.conf (ไม่บังคับ) เช่น
#   GH_REPO=ZEROXGCK/xxtlonline   GH_BRANCH=main   ZIP_NAME=wselx-sell.zip
#   ZIP_URL=https://.../wselx-sell.zip   (ถ้าตั้ง จะใช้ลิงก์นี้แทน GitHub)
#   APP_DIR=/opt/wselx   WSELX_SRC=/opt/wselx-src
# =====================================================================
set -u

[ -f /etc/wselx-menu.conf ] && . /etc/wselx-menu.conf
APP_DIR="${APP_DIR:-/opt/wselx}"
WSELX_SRC="${WSELX_SRC:-/opt/wselx-src}"
GH_REPO="${GH_REPO:-ZEROXGCK/xxtlonline}"
GH_BRANCH="${GH_BRANCH:-main}"
ZIP_NAME="${ZIP_NAME:-wselx-sell.zip}"
ZIP_URL="${ZIP_URL:-https://raw.githubusercontent.com/$GH_REPO/$GH_BRANCH/$ZIP_NAME}"
SERVICE="wselx"
INFO_FILE="/root/xxtl-wselx-info.txt"
ENV_FILE="$APP_DIR/.env"

if [ "$(id -u)" -ne 0 ]; then
  exec sudo -E bash "$0" "$@"
fi

C0=$'\033[0m'; CB=$'\033[1m'; CG=$'\033[1;32m'; CR=$'\033[1;31m'; CY=$'\033[1;33m'; CC=$'\033[1;36m'; CD=$'\033[2m'
ok()   { printf '%s✔ %s%s\n' "$CG" "$*" "$C0"; }
bad()  { printf '%s✘ %s%s\n' "$CR" "$*" "$C0"; }
warn() { printf '%s! %s%s\n' "$CY" "$*" "$C0"; }
say()  { printf '\n%s==> %s%s\n' "$CC" "$*" "$C0"; }
pause() { echo; read -r -p "กด Enter เพื่อกลับเมนู... " _ || true; }
confirm() { # confirm "คำถาม" → 0 = ใช่
  local a; read -r -p "$1 [y/N]: " a || a=""; case "$a" in y|Y|yes|YES|ใช่) return 0 ;; *) return 1 ;; esac
}

need_app() { [ -f "$ENV_FILE" ] || { bad "ไม่พบ $ENV_FILE — ยังไม่ได้ติดตั้งร้านค้า (wselx)"; return 1; }; }
getenv() { grep -E "^$1=" "$ENV_FILE" 2>/dev/null | tail -n1 | cut -d= -f2- | sed -e 's/^["'\'']//' -e 's/["'\'']$//'; }
set_env() { # set_env KEY VALUE  (ไม่ใช้ sed จึงใส่อักขระพิเศษได้)
  local k="$1" v="$2" tmp; tmp="$(mktemp)"
  grep -v -E "^$k=" "$ENV_FILE" > "$tmp" 2>/dev/null || true
  printf '%s=%s\n' "$k" "$v" >> "$tmp"
  cat "$tmp" > "$ENV_FILE"; rm -f "$tmp"; chmod 600 "$ENV_FILE"
}
db_url() { getenv DATABASE_URL; }
app_ver() { grep -m1 '"version"' "$APP_DIR/package.json" 2>/dev/null | sed -E 's/.*"version": *"([^"]+)".*/\1/'; }
svc_on() { systemctl is-active --quiet "$1" 2>/dev/null; }
svc_line() {
  systemctl cat "$1" >/dev/null 2>&1 || return 0
  if svc_on "$1"; then printf '  %-18s %s\n' "$1" "${CG}ทำงานอยู่${C0}"; else printf '  %-18s %s\n' "$1" "${CR}หยุดทำงาน${C0}"; fi
}
restart_shop() { systemctl restart "$SERVICE" && sleep 2 && { svc_on "$SERVICE" && ok "ร้านค้ากลับมาทำงานแล้ว" || { bad "ร้านค้าไม่ขึ้น — ดู log (เมนู 5)"; return 1; }; }; }

# ---------------------------------------------------------------------
# สำรอง / ดึงไฟล์อัปเดต
# ---------------------------------------------------------------------
do_backup() {
  need_app || return 1
  if [ -x /usr/local/bin/wselx-backup ]; then
    APP_DIR="$APP_DIR" /usr/local/bin/wselx-backup
  elif [ -f "$APP_DIR/backup.sh" ]; then
    APP_DIR="$APP_DIR" bash "$APP_DIR/backup.sh"
  else
    local d="/var/backups/wselx" f; mkdir -p "$d"; f="$d/wselx-$(date +%Y%m%d-%H%M%S).sql.gz"
    pg_dump "$(db_url)" --no-owner | gzip -9 > "$f" && cp "$ENV_FILE" "$d/env-$(date +%Y%m%d-%H%M%S).bak" && echo "สำรองแล้ว: $f"
  fi
}

WORK=""
cleanup() { [ -n "$WORK" ] && rm -rf "$WORK"; }
trap cleanup EXIT

# fetch_zip <path|url|remote> → ตั้ง SRC_DIR SRC_VER SRC_SHA SRC_LABEL
fetch_zip() {
  local from="$1" zip
  SRC_DIR=""; SRC_VER=""; SRC_SHA=""; SRC_LABEL="$from"
  [ -n "$WORK" ] && rm -rf "$WORK"
  WORK="$(mktemp -d)"; zip="$WORK/src.zip"
  command -v unzip >/dev/null || { apt-get update -qq && apt-get install -y -qq unzip >/dev/null; }
  if [ "$from" = remote ]; then
    SRC_LABEL="$ZIP_URL"
    curl -fsSL --max-time 90 "$ZIP_URL" -o "$zip" || { bad "ดาวน์โหลดไม่สำเร็จ: $ZIP_URL (repo ต้องเป็น public และมีไฟล์ชื่อ $ZIP_NAME)"; return 1; }
  elif [[ "$from" =~ ^https?:// ]]; then
    curl -fsSL --max-time 90 "$from" -o "$zip" || { bad "ดาวน์โหลดไม่สำเร็จ: $from"; return 1; }
  else
    [ -f "$from" ] || { bad "ไม่พบไฟล์ $from"; return 1; }
    cp "$from" "$zip"
  fi
  mkdir -p "$WORK/x"
  unzip -oq "$zip" -d "$WORK/x" 2>/dev/null || { bad "แตกไฟล์ zip ไม่ได้ (ไฟล์เสีย?)"; return 1; }
  local sj; sj="$(find "$WORK/x" -maxdepth 3 -name server.js -not -path '*/node_modules/*' | head -n1)"
  [ -n "$sj" ] || { bad "ใน zip ไม่พบ server.js — ไม่ใช่ไฟล์ร้านค้า wselx"; return 1; }
  SRC_DIR="$(dirname "$sj")"
  [ -f "$SRC_DIR/schema.sql" ] && [ -f "$SRC_DIR/install.sh" ] || { bad "ใน zip ไม่ครบ (ต้องมี schema.sql และ install.sh)"; return 1; }
  SRC_VER="$(grep -m1 '"version"' "$SRC_DIR/package.json" 2>/dev/null | sed -E 's/.*"version": *"([^"]+)".*/\1/')"
  SRC_SHA="$(sha256sum "$zip" | cut -d' ' -f1)"
  return 0
}

newest_local_zip() {
  ls -1t /root/wselx*.zip /root/*sell*.zip /tmp/wselx*.zip /home/*/wselx*.zip 2>/dev/null | head -n1
}

ver_gt() { [ "$1" != "$2" ] && [ "$(printf '%s\n%s\n' "$1" "$2" | sort -V | tail -n1)" = "$1" ]; }

# ---------------------------------------------------------------------
# 1) สถานะระบบ
# ---------------------------------------------------------------------
m_status() {
  say "สถานะระบบ"
  if need_app; then
    local dom; dom="$(getenv SITE_DOMAIN)"
    echo "  เวอร์ชันร้านค้า : $(app_ver)"
    echo "  โดเมน           : ${dom:-(ไม่มี — โหมดทดสอบ)}"
    echo "  โฟลเดอร์        : $APP_DIR"
  fi
  echo
  echo "  บริการ:"
  for s in wselx postgresql nginx xxtlonline-dash xxtlonline-ws x-ui; do svc_line "$s"; done
  echo
  echo "  ทรัพยากร:"
  printf '  ดิสก์  : %s\n' "$(df -h / | awk 'NR==2{print $3" ใช้ / "$2" ("$5")"}')"
  printf '  RAM    : %s\n' "$(free -h | awk '/Mem:/{print $3" ใช้ / "$2}')"
  printf '  โหลด   : %s\n' "$(cut -d' ' -f1-3 /proc/loadavg)"
  printf '  เปิดมา : %s\n' "$(uptime -p 2>/dev/null)"
  if need_app >/dev/null 2>&1; then
    local port; port="$(getenv PORT)"; port="${port:-3000}"
    if curl -fsS --max-time 5 "http://127.0.0.1:$port/api/site" >/dev/null 2>&1; then ok "เว็บร้านค้าตอบสนองปกติ (พอร์ต $port)"; else bad "เว็บร้านค้าไม่ตอบสนองที่พอร์ต $port"; fi
    local tg="ยังไม่ได้ตั้ง"; [ -n "$(getenv TELEGRAM_BOT_TOKEN)" ] && [ -n "$(getenv TELEGRAM_CHAT_ID)" ] && tg="ตั้งแล้ว"
    echo "  Telegram: $tg"
    local last; last="$(ls -1t /var/backups/wselx/wselx-*.sql.gz 2>/dev/null | head -n1)"
    echo "  สำรองล่าสุด: ${last:-ยังไม่มี}"
  fi
}

# ---------------------------------------------------------------------
# 2) ตรวจการอัปเดต
# ---------------------------------------------------------------------
m_check() {
  need_app || return
  say "ตรวจการอัปเดต"
  local cur sha_file="$APP_DIR/.menu_zip_sha" last_sha="" lz
  cur="$(app_ver)"; [ -f "$sha_file" ] && last_sha="$(cat "$sha_file")"
  echo "  เวอร์ชันที่ติดตั้งอยู่ : ${cur:-?}"
  echo
  lz="$(newest_local_zip)"
  if [ -n "$lz" ]; then
    if fetch_zip "$lz"; then
      echo "  zip ในเครื่อง ($lz)"
      echo "    เวอร์ชันในไฟล์ : $SRC_VER"
      if [ "$SRC_SHA" = "$last_sha" ]; then ok "    ติดตั้งไฟล์นี้ไปแล้ว";
      elif ver_gt "$SRC_VER" "$cur"; then warn "    ใหม่กว่าที่ติดตั้งอยู่ → เลือกเมนู 3 เพื่ออัปเดต";
      else echo "    เนื้อหาไม่เหมือนที่ติดตั้ง (เวอร์ชันเท่ากัน/เก่ากว่า) — อาจมีการแก้ไขโดยไม่เปลี่ยนเลขเวอร์ชัน"; fi
    fi
  else
    echo "  zip ในเครื่อง : ไม่พบ (ถ้าจะอัปเดตจากไฟล์ ให้อัปโหลด $ZIP_NAME ไว้ที่ /root/)"
  fi
  echo
  echo "  ตรวจจากออนไลน์: $ZIP_URL"
  if fetch_zip remote; then
    echo "    เวอร์ชันออนไลน์ : $SRC_VER"
    if [ "$SRC_SHA" = "$last_sha" ]; then ok "    ตรงกับที่ติดตั้งแล้ว — เป็นเวอร์ชันล่าสุด";
    elif ver_gt "$SRC_VER" "$cur"; then warn "    มีเวอร์ชันใหม่ $SRC_VER → เลือกเมนู 3 แล้วเลือกดาวน์โหลดออนไลน์";
    else echo "    ไฟล์ออนไลน์ต่างจากที่ติดตั้ง แต่เลขเวอร์ชันไม่ใหม่กว่า (ตรวจเนื้อหาเองก่อนอัปเดต)"; fi
  fi
}

# ---------------------------------------------------------------------
# 3) อัปเดตร้านค้า
# ---------------------------------------------------------------------
apply_update() { # ใช้ SRC_DIR ที่เตรียมไว้
  [ -d "$WSELX_SRC" ] || mkdir -p "$WSELX_SRC"
  command -v git >/dev/null || { apt-get update -qq && apt-get install -y -qq git >/dev/null; }
  [ -d "$WSELX_SRC/.git" ] || git -C "$WSELX_SRC" init -q -b main
  say "สำรองฐานข้อมูลก่อนอัปเดต"
  do_backup || { bad "สำรองไม่สำเร็จ — ยกเลิกการอัปเดตเพื่อความปลอดภัย"; return 1; }

  say "คัดลอกไฟล์ใหม่"
  find "$WSELX_SRC" -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +
  cp -a "$SRC_DIR"/. "$WSELX_SRC"/
  # กันบั๊ก BIGINT → string ถ้า zip รุ่นเก่ายังไม่มีแพตช์ (เหมือนที่ setup.sh ทำ)
  if ! grep -q "setTypeParser" "$WSELX_SRC/server.js"; then
    sed -i "0,/^const { Pool } = require('pg');/s//const { Pool, types: pgTypes } = require('pg');\npgTypes.setTypeParser(20, v => parseInt(v, 10));/" "$WSELX_SRC/server.js"
  fi
  git -C "$WSELX_SRC" add -A
  git -C "$WSELX_SRC" -c user.name=menu -c user.email=menu@localhost commit -qm "wselx ${SRC_VER:-?} $(date +%F-%H%M)" 2>/dev/null || true

  local skip=0
  if [ -f /etc/nginx/conf.d/wselx-xxtl.conf ] || [ ! -f /etc/nginx/sites-available/wselx ]; then skip=1; fi
  say "ติดตั้งอัปเดต (ไม่แตะ .env / ฐานข้อมูล / ข้อมูลลูกค้า)"
  NONINTERACTIVE=1 SKIP_NGINX="$skip" REPO_URL="$WSELX_SRC" BRANCH=main APP_DIR="$APP_DIR" \
    bash "$WSELX_SRC/install.sh" || { bad "install.sh ล้มเหลว — ดูข้อความด้านบน (ย้อนกลับได้ที่เมนู 4)"; return 1; }
  [ -n "$SRC_SHA" ] && { echo "$SRC_SHA" > "$APP_DIR/.menu_zip_sha"; chmod 600 "$APP_DIR/.menu_zip_sha"; }
  sleep 2
  if svc_on "$SERVICE"; then ok "อัปเดตสำเร็จ — เวอร์ชันตอนนี้ $(app_ver)"; else bad "อัปเดตแล้วแต่ร้านค้าไม่ขึ้น — ดู log (เมนู 5) หรือย้อนกลับ (เมนู 4)"; return 1; fi
}

m_update() {
  need_app || return
  say "อัปเดตร้านค้า (เวอร์ชันตอนนี้ $(app_ver))"
  local lz; lz="$(newest_local_zip)"
  echo "  เลือกแหล่งไฟล์อัปเดต:"
  if [ -n "$lz" ]; then echo "    1) ไฟล์ zip ในเครื่อง ($lz)"; else echo "    1) ไฟล์ zip ในเครื่อง (ไม่พบ — อัปโหลดไว้ที่ /root/)"; fi
  echo "    2) ดาวน์โหลดออนไลน์  ($ZIP_URL)"
  echo "    3) ระบุ path หรือ URL เอง"
  echo "    0) ยกเลิก"
  local c src; read -r -p "  เลือก: " c || c=0
  case "$c" in
    1) [ -n "$lz" ] || { bad "ไม่พบไฟล์ zip"; return; }; src="$lz" ;;
    2) src=remote ;;
    3) read -r -p "  path หรือ URL ของ zip: " src; [ -n "$src" ] || return ;;
    *) return ;;
  esac
  fetch_zip "$src" || return
  echo
  echo "  ติดตั้งอยู่ : $(app_ver)"
  echo "  ไฟล์ใหม่    : ${SRC_VER:-?}   ($SRC_LABEL)"
  if [ -f "$APP_DIR/.menu_zip_sha" ] && [ "$(cat "$APP_DIR/.menu_zip_sha")" = "$SRC_SHA" ]; then warn "ไฟล์นี้ถูกติดตั้งไปแล้ว"; fi
  confirm "ยืนยันอัปเดต? (จะสำรองฐานข้อมูลให้อัตโนมัติก่อน)" || { echo "ยกเลิก"; return; }
  apply_update
}

# ---------------------------------------------------------------------
# 4) ย้อนกลับเวอร์ชัน
# ---------------------------------------------------------------------
m_rollback() {
  need_app || return
  [ -d "$WSELX_SRC/.git" ] || { bad "ไม่มีประวัติเวอร์ชันที่ $WSELX_SRC"; return; }
  say "ย้อนกลับเวอร์ชันร้านค้า"
  git -C "$WSELX_SRC" log --pretty='%h  %ad  %s' --date=format:'%d/%m/%Y %H:%M' -n 8 | nl -w2 -s') '
  local n h; read -r -p "  เลือกลำดับที่จะย้อนไป (Enter = ยกเลิก): " n || n=""
  [ -n "$n" ] || return
  h="$(git -C "$WSELX_SRC" log --pretty='%h' -n 8 | sed -n "${n}p")"
  [ -n "$h" ] || { bad "ลำดับไม่ถูกต้อง"; return; }
  warn "ย้อนกลับเฉพาะโค้ด — ฐานข้อมูลไม่ถูกย้อน (ตารางที่เพิ่มใหม่จะยังอยู่ ซึ่งปกติไม่กระทบ)"
  confirm "ย้อนไปที่ $h ?" || return
  do_backup || { bad "สำรองไม่สำเร็จ ยกเลิก"; return; }
  git -C "$WSELX_SRC" checkout "$h" -- . || { bad "checkout ไม่สำเร็จ"; return; }
  git -C "$WSELX_SRC" add -A
  git -C "$WSELX_SRC" -c user.name=menu -c user.email=menu@localhost commit -qm "rollback to $h" 2>/dev/null || true
  local skip=0; if [ -f /etc/nginx/conf.d/wselx-xxtl.conf ] || [ ! -f /etc/nginx/sites-available/wselx ]; then skip=1; fi
  NONINTERACTIVE=1 SKIP_NGINX="$skip" REPO_URL="$WSELX_SRC" BRANCH=main APP_DIR="$APP_DIR" bash "$WSELX_SRC/install.sh" \
    && { rm -f "$APP_DIR/.menu_zip_sha"; ok "ย้อนกลับแล้ว — เวอร์ชันตอนนี้ $(app_ver)"; } || bad "ย้อนกลับไม่สำเร็จ ดูข้อความด้านบน"
}

# ---------------------------------------------------------------------
# 5-6) บริการ / log
# ---------------------------------------------------------------------
m_service() {
  say "ควบคุมร้านค้า"
  echo "  1) รีสตาร์ต   2) หยุด   3) เริ่ม   4) รีสตาร์ตทุกบริการ (ร้านค้า + nginx + VPN panel)   0) กลับ"
  local c; read -r -p "  เลือก: " c || c=0
  case "$c" in
    1) restart_shop ;;
    2) confirm "หยุดร้านค้า? (ลูกค้าจะเข้าเว็บไม่ได้)" && systemctl stop "$SERVICE" && ok "หยุดแล้ว" ;;
    3) systemctl start "$SERVICE" && sleep 2 && { svc_on "$SERVICE" && ok "เริ่มแล้ว" || bad "ไม่ขึ้น — ดู log"; } ;;
    4) for s in "$SERVICE" xxtlonline-dash xxtlonline-ws x-ui nginx; do
         systemctl cat "$s" >/dev/null 2>&1 && { systemctl restart "$s" 2>/dev/null && ok "รีสตาร์ต $s" || bad "$s รีสตาร์ตไม่สำเร็จ"; }
       done ;;
  esac
}

m_logs() {
  say "ดู log ร้านค้า"
  echo "  1) 60 บรรทัดล่าสุด   2) ติดตามสด (กด Ctrl+C เพื่อออก)   3) เฉพาะ error วันนี้   0) กลับ"
  local c; read -r -p "  เลือก: " c || c=0
  case "$c" in
    1) journalctl -u "$SERVICE" -n 60 --no-pager ;;
    2) journalctl -u "$SERVICE" -f -n 20 ;;
    3) journalctl -u "$SERVICE" --since today -p err --no-pager | tail -n 80 ;;
  esac
}

# ---------------------------------------------------------------------
# 7-8) สำรอง / กู้คืน
# ---------------------------------------------------------------------
m_backup() {
  say "สำรองฐานข้อมูลตอนนี้"
  do_backup || return
  local dir; dir="$(getenv BACKUP_DIR)"; dir="${dir:-/var/backups/wselx}"
  echo; echo "  ไฟล์สำรองล่าสุด:"
  ls -1t "$dir"/wselx-*.sql.gz 2>/dev/null | head -n 5 | while read -r f; do printf '  %s  %s\n' "$(du -h "$f" | cut -f1)" "$f"; done
  echo "  (เก็บไฟล์ .env คู่กับไฟล์สำรองเสมอ ไม่งั้นถอดรหัสข้อมูลไม่ได้)"
}

m_restore() {
  need_app || return
  local dir; dir="$(getenv BACKUP_DIR)"; dir="${dir:-/var/backups/wselx}"
  say "กู้คืนฐานข้อมูล (จาก $dir)"
  mapfile -t files < <(ls -1t "$dir"/wselx-*.sql.gz 2>/dev/null | head -n 10)
  [ "${#files[@]}" -gt 0 ] || { bad "ไม่พบไฟล์สำรอง"; return; }
  local i=1; for f in "${files[@]}"; do printf '  %2d) %s  (%s)\n' "$i" "$(basename "$f")" "$(du -h "$f" | cut -f1)"; i=$((i+1)); done
  local n; read -r -p "  เลือกไฟล์ที่จะกู้ (Enter = ยกเลิก): " n || n=""
  [ -n "$n" ] && [ "$n" -ge 1 ] 2>/dev/null && [ "$n" -le "${#files[@]}" ] || { echo "ยกเลิก"; return; }
  local pick="${files[$((n-1))]}"
  warn "การกู้คืนจะ ลบข้อมูลปัจจุบันทั้งหมด แล้วแทนที่ด้วยข้อมูลในไฟล์ $(basename "$pick")"
  local t; read -r -p "  พิมพ์ YES (ตัวใหญ่) เพื่อยืนยัน: " t || t=""
  [ "$t" = "YES" ] || { echo "ยกเลิก"; return; }
  say "สำรองสภาพปัจจุบันไว้ก่อน (เผื่อกู้กลับ)"
  do_backup || { bad "สำรองสภาพปัจจุบันไม่สำเร็จ — ยกเลิก"; return; }
  systemctl stop "$SERVICE"
  local db; db="$(db_url)"
  if psql "$db" -v ON_ERROR_STOP=1 -q -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;" \
     && gunzip -c "$pick" | psql "$db" -v ON_ERROR_STOP=1 -q >/dev/null; then
    ok "กู้คืนข้อมูลเรียบร้อย"
  else
    bad "กู้คืนไม่สำเร็จ — ไฟล์สำรองล่าสุดก่อนกู้อยู่ที่ $dir (ไฟล์ wselx-*.sql.gz ใหม่สุด)"
  fi
  restart_shop
}

# ---------------------------------------------------------------------
# 9) Telegram
# ---------------------------------------------------------------------
tg_test() {
  local tok chat; tok="$(getenv TELEGRAM_BOT_TOKEN)"; chat="$(getenv TELEGRAM_CHAT_ID)"
  [ -n "$tok" ] && [ -n "$chat" ] || { bad "ยังไม่ได้ตั้ง Telegram"; return 1; }
  local r; r="$(curl -fsS --max-time 15 "https://api.telegram.org/bot$tok/sendMessage" \
     -d "chat_id=$chat" --data-urlencode "text=✅ ทดสอบแจ้งเตือนจากเมนู VPN ($(hostname)) $(date '+%d/%m/%Y %H:%M:%S')" 2>&1)" \
     && ok "ส่งข้อความทดสอบแล้ว — ตรวจใน Telegram" || { bad "ส่งไม่สำเร็จ: ${r:0:200}"; echo "  ตรวจ token / chat id และว่าได้ทักบอทหรือเพิ่มบอทเข้ากลุ่มแล้ว"; return 1; }
}
m_telegram() {
  need_app || return
  say "ตั้งค่า Telegram แจ้งเตือน"
  echo "  (หมายเหตุ: ถ้าตั้งไว้ที่หลังบ้านเว็บ ค่านั้นจะถูกใช้ก่อนค่าใน .env ด้านล่าง)"
  echo "  token ตอนนี้ : $([ -n "$(getenv TELEGRAM_BOT_TOKEN)" ] && echo "ตั้งแล้ว (ซ่อนไว้)" || echo "ยังไม่ตั้ง")"
  echo "  chat id      : $(getenv TELEGRAM_CHAT_ID)"
  echo "  1) ตั้ง/เปลี่ยน token และ chat id   2) ทดสอบส่งข้อความ   3) ปิดการแจ้งเตือน   0) กลับ"
  local c; read -r -p "  เลือก: " c || c=0
  case "$c" in
    1) local tok chat
       read -r -p "  Bot Token (จาก @BotFather): " tok; read -r -p "  Chat ID: " chat
       [ -n "$tok" ] && [ -n "$chat" ] || { bad "ต้องกรอกทั้งสองค่า"; return; }
       set_env TELEGRAM_BOT_TOKEN "$tok"; set_env TELEGRAM_CHAT_ID "$chat"
       restart_shop && tg_test ;;
    2) tg_test ;;
    3) confirm "ปิดแจ้งเตือน Telegram?" && { set_env TELEGRAM_BOT_TOKEN ""; set_env TELEGRAM_CHAT_ID ""; restart_shop; } ;;
  esac
}

# ---------------------------------------------------------------------
# 10) แก้ .env
# ---------------------------------------------------------------------
m_env() {
  need_app || return
  say "แก้ไฟล์ตั้งค่า $ENV_FILE"
  warn "ห้ามแก้ DATA_KEY / JWT_SECRET — ถ้าเปลี่ยนจะถอดรหัสข้อมูลลูกค้าไม่ได้ และทุกคนต้องล็อกอินใหม่"
  cp "$ENV_FILE" "/root/wselx.env.$(date +%Y%m%d-%H%M%S).bak"
  local ed="${EDITOR:-}"; [ -n "$ed" ] || { command -v nano >/dev/null && ed=nano || ed=vi; }
  "$ed" "$ENV_FILE"
  chmod 600 "$ENV_FILE"
  confirm "รีสตาร์ตร้านค้าเพื่อใช้ค่าใหม่?" && restart_shop
}

# ---------------------------------------------------------------------
# 11-12) บัญชีผู้ใช้
# ---------------------------------------------------------------------
m_resetpw() {
  need_app || return
  say "รีเซ็ตรหัสผ่านสมาชิก / แอดมิน"
  local u p1 p2; read -r -p "  ชื่อผู้ใช้: " u; [ -n "$u" ] || return
  read -r -s -p "  รหัสผ่านใหม่ (อย่างน้อย 8 ตัว): " p1; echo
  read -r -s -p "  ยืนยันรหัสผ่านอีกครั้ง: " p2; echo
  [ "$p1" = "$p2" ] || { bad "รหัสไม่ตรงกัน"; return; }
  [ "${#p1}" -ge 8 ] || { bad "สั้นเกินไป (อย่างน้อย 8 ตัว)"; return; }
  ( cd "$APP_DIR" && NEWPW="$p1" UNAME="$u" DB_URL="$(db_url)" node -e '
    const { Pool } = require("pg"), bcrypt = require("bcryptjs");
    (async () => {
      const pool = new Pool({ connectionString: process.env.DB_URL });
      const h = await bcrypt.hash(process.env.NEWPW, 12);
      const r = await pool.query("UPDATE users SET password_hash=$2 WHERE username=$1 RETURNING username, role", [process.env.UNAME, h]);
      console.log(r.rows.length ? "เปลี่ยนรหัสผ่านของ " + r.rows[0].username + " (" + r.rows[0].role + ") เรียบร้อย" : "ไม่พบชื่อผู้ใช้นี้");
      await pool.end(); process.exit(r.rows.length ? 0 : 2);
    })().catch(e => { console.error(e.message); process.exit(1); });
  ' ) && ok "สำเร็จ" || bad "ไม่สำเร็จ"
}

m_2fa() {
  need_app || return
  say "ปิด 2FA ของผู้ใช้ (กรณีแอดมินเข้าไม่ได้)"
  local u; read -r -p "  ชื่อผู้ใช้: " u; [ -n "$u" ] || return
  confirm "ปิด 2FA ของ $u ?" || return
  local out; out="$(psql "$(db_url)" -t -A -v u="$u" <<'SQL'
UPDATE users SET totp_enabled = FALSE, totp_secret_enc = NULL WHERE username = :'u' RETURNING username;
SQL
)"
  [ -n "$out" ] && ok "ปิด 2FA ของ $u แล้ว (ตั้งใหม่ได้ในหน้าแอดมิน)" || bad "ไม่พบชื่อผู้ใช้นี้"
}

# ---------------------------------------------------------------------
# 13) HTTPS / ข้อมูลเข้าระบบ
# ---------------------------------------------------------------------
m_ssl() {
  say "ใบรับรอง HTTPS"
  command -v certbot >/dev/null || { bad "ไม่พบ certbot"; return; }
  certbot certificates 2>/dev/null | grep -E "Certificate Name|Domains|Expiry" | sed 's/^/  /'
  echo
  confirm "ทดสอบต่ออายุ (dry-run ไม่เปลี่ยนอะไร)?" && certbot renew --dry-run 2>&1 | tail -n 12
}

m_info() {
  say "ข้อมูลเข้าระบบ"
  if [ -f "$INFO_FILE" ]; then
    warn "ไฟล์นี้มีรหัสผ่านแอดมิน — อย่าแคปหน้าจอส่งใคร"
    confirm "แสดงข้อมูล?" && cat "$INFO_FILE"
  else
    echo "  ไม่พบ $INFO_FILE"; need_app && echo "  ร้านค้า : https://$(getenv SITE_DOMAIN)/  แอดมิน: $(getenv ADMIN_USERNAME)"
  fi
}

# ---------------------------------------------------------------------
# เมนูหลัก
# ---------------------------------------------------------------------
header() {
  clear 2>/dev/null || true
  local v dom st
  v="$(app_ver)"; dom="$(getenv SITE_DOMAIN 2>/dev/null)"
  if svc_on "$SERVICE"; then st="${CG}● ทำงานอยู่${C0}"; else st="${CR}● หยุดทำงาน${C0}"; fi
  printf '%s╔══════════════════════════════════════════════╗%s\n' "$CC" "$C0"
  printf '%s║        เมนูจัดการร้านค้า Wselx (VPS)         ║%s\n' "$CC" "$C0"
  printf '%s╚══════════════════════════════════════════════╝%s\n' "$CC" "$C0"
  printf '  เวอร์ชัน %s%s%s • %s • %s\n' "$CB" "${v:-?}" "$C0" "$st" "${dom:-ไม่มีโดเมน}"
  echo
  echo "   1) สถานะระบบ"
  echo "   2) ตรวจการอัปเดต"
  echo "   3) อัปเดตร้านค้า"
  echo "   4) ย้อนกลับเวอร์ชัน"
  echo "   5) ดู log"
  echo "   6) รีสตาร์ต / หยุด / เริ่ม"
  echo "   7) สำรองฐานข้อมูลตอนนี้"
  echo "   8) กู้คืนฐานข้อมูล"
  echo "   9) ตั้งค่า Telegram แจ้งเตือน"
  echo "  10) แก้ไฟล์ตั้งค่า (.env)"
  echo "  11) รีเซ็ตรหัสผ่านสมาชิก/แอดมิน"
  echo "  12) ปิด 2FA ของผู้ใช้"
  echo "  13) ตรวจใบรับรอง HTTPS"
  echo "  14) ข้อมูลเข้าระบบ"
  echo "   0) ออก"
  echo
}

# เรียกตรงจากคำสั่งได้ เช่น: menu update | menu check | menu status | menu backup | menu restart
case "${1:-}" in
  status)  m_status; exit ;;
  check)   m_check; exit ;;
  update)  m_update; exit ;;
  backup)  m_backup; exit ;;
  restart) need_app && restart_shop; exit ;;
  logs)    m_logs; exit ;;
  -h|--help|help)
    echo "ใช้: menu              เปิดเมนู"
    echo "     menu status|check|update|backup|restart|logs"; exit ;;
esac

while :; do
  header
  read -r -p "  เลือกเมนู: " c || exit 0
  case "$c" in
    1) m_status; pause ;;
    2) m_check; pause ;;
    3) m_update; pause ;;
    4) m_rollback; pause ;;
    5) m_logs; pause ;;
    6) m_service; pause ;;
    7) m_backup; pause ;;
    8) m_restore; pause ;;
    9) m_telegram; pause ;;
    10) m_env; pause ;;
    11) m_resetpw; pause ;;
    12) m_2fa; pause ;;
    13) m_ssl; pause ;;
    14) m_info; pause ;;
    0|q|Q|exit) echo; exit 0 ;;
    *) ;;
  esac
done
