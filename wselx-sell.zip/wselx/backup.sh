#!/usr/bin/env bash
# สำรองฐานข้อมูล Wselx (pg_dump -> .sql.gz) เก็บ 14 วัน
# ใช้เอง: sudo APP_DIR=/opt/wselx ./backup.sh   |  ติดตั้งแล้ว cron รันให้ทุกวัน 03:30 (ดู install.sh)
# ตั้งใน .env (ไม่บังคับ): BACKUP_DIR=/var/backups/wselx  BACKUP_KEEP_DAYS=14  BACKUP_REMOTE=user@host:/path (ส่งออกนอกเครื่องด้วย rsync/ssh)
set -euo pipefail
APP_DIR="${APP_DIR:-/opt/wselx}"
ENV_FILE="$APP_DIR/.env"
[ -f "$ENV_FILE" ] || { echo "ไม่พบ $ENV_FILE"; exit 1; }
getenv() { { grep -E "^$1=" "$ENV_FILE" || true; } | tail -n1 | cut -d= -f2- | sed -e 's/^["'\'']//' -e 's/["'\'']$//'; }

DB_URL="$(getenv DATABASE_URL)"
BACKUP_DIR="$(getenv BACKUP_DIR)"; BACKUP_DIR="${BACKUP_DIR:-/var/backups/wselx}"
KEEP="$(getenv BACKUP_KEEP_DAYS)"; KEEP="${KEEP:-14}"
REMOTE="$(getenv BACKUP_REMOTE)"
[ -n "$DB_URL" ] || { echo "ไม่พบ DATABASE_URL ใน .env"; exit 1; }

umask 077
mkdir -p "$BACKUP_DIR"
STAMP="$(date +%Y%m%d-%H%M%S)"
OUT="$BACKUP_DIR/wselx-$STAMP.sql.gz"
pg_dump "$DB_URL" --no-owner | gzip -9 > "$OUT.tmp"
mv "$OUT.tmp" "$OUT"
# DATA_KEY อยู่ใน .env — ต้องเก็บ .env คู่กับไฟล์สำรอง ไม่งั้นรหัสเซิร์ฟเวอร์/คีย์ที่เข้ารหัสไว้ถอดไม่ได้
cp "$ENV_FILE" "$BACKUP_DIR/env-$STAMP.bak"
find "$BACKUP_DIR" -type f \( -name 'wselx-*.sql.gz' -o -name 'env-*.bak' \) -mtime +"$KEEP" -delete
echo "[$(date -Is)] สำรองเรียบร้อย: $OUT ($(du -h "$OUT" | cut -f1))"

if [ -n "$REMOTE" ]; then
  rsync -az -e "ssh -o StrictHostKeyChecking=accept-new" "$OUT" "$BACKUP_DIR/env-$STAMP.bak" "$REMOTE/" \
    && echo "ส่งไป $REMOTE แล้ว" || echo "⚠️ ส่งไป $REMOTE ไม่สำเร็จ (ไฟล์ในเครื่องยังอยู่)"
fi
# กู้คืน: gunzip -c wselx-XXXX.sql.gz | psql "$DATABASE_URL"
