#!/usr/bin/python3
"""xxtlonline-dashboard v2: เว็บจัดการ user + REST API สำหรับเชื่อมกับ panel ร้านค้า (stdlib ล้วน)"""
import base64, getpass, hashlib, hmac, ipaddress, json, os, re, secrets, shutil, subprocess, sys, threading, time
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import quote, urlsplit

VERSION = "2.3"
CONF = os.environ.get("XXTLONLINE_DASH_CONF", "/etc/xxtlonline/dashboard.json")
EXP_DIR = os.environ.get("XXTLONLINE_EXP_DIR", "/etc/xxtlonline/exp")
UNTIL_DIR = os.environ.get("XXTLONLINE_UNTIL_DIR", "/etc/xxtlonline/until")
CLI = os.environ.get("XXTLONLINE_CLI", "/usr/local/bin/xxtlonline")
HOST = os.environ.get("XXTLONLINE_DASH_HOST", "127.0.0.1")
PORT = int(os.environ.get("XXTLONLINE_DASH_PORT", "8088"))
DOMAIN = os.environ.get("XXTLONLINE_DASH_DOMAIN", "").strip().lower()   # ตั้งเมื่อใช้งานผ่าน nginx + HTTPS
BASE = "/" + os.environ.get("XXTLONLINE_DASH_BASE", "").strip().strip("/") if os.environ.get("XXTLONLINE_DASH_BASE", "").strip().strip("/") else ""   # เช่น /panel เมื่ออยู่ใต้โดเมนเดียวกับร้านค้า
NPV_CONF = os.environ.get("XXTLONLINE_NPV_CONF", "/etc/xxtlonline/npv.json")          # เวอร์ชันเก่า (ย้ายเข้า profiles อัตโนมัติ)
PROF_CONF = os.environ.get("XXTLONLINE_PROF_CONF", "/etc/xxtlonline/profiles.json")
KEYS_CONF = os.environ.get("XXTLONLINE_KEYS_CONF", "/etc/xxtlonline/apikeys.json")
SYS_CONF = os.environ.get("XXTLONLINE_SYS_CONF", "/etc/xxtlonline/xxtlonline.conf")
SUSP_DIR = os.environ.get("XXTLONLINE_SUSP_DIR", "/etc/xxtlonline/susp")
USAGE_DIR = os.environ.get("XXTLONLINE_USAGE_DIR", "/etc/xxtlonline/usage")   # ยอดข้อมูลสะสมต่อ user (ไบต์)

PW_RE = re.compile(r"^[A-Za-z0-9!@#%^&*_+=.,-]{6,64}$")
USER_RE = re.compile(r"^[a-z][a-z0-9_-]{2,15}$")
ADMIN_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")
SESSION_TTL = 8 * 3600
MAX_PROFILES = 30
MAX_KEYS = 10

sessions = {}    # token -> (expires, csrf)
fails = {}       # ip -> [count, locked_until]   (login)
api_fails = {}   # ip -> [count, locked_until]   (api key)
lock = threading.RLock()       # เขียนไฟล์คอนฟิก
cli_lock = threading.Lock()    # สั่ง CLI ทีละคำสั่ง กัน add/del ชนกัน

DEFAULT_PROFILE = {
    "name": "ค่าเริ่มต้น",
    "bug": "",        # บัคโฮส -> ใช้ตัวแปร {bug} (ว่าง = ใช้ host)
    "host": "", "port": 0,
    "sni": "", "proxy": "",
    "payload": "POST /cdn-cgi/speculation HTTP/1.1[crlf]Host: search.ais.co.th[crlf]User-Agent: [ua][crlf][crlf][split][cr]PATCH /ssh HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]Upgrade: websocket[crlf][crlf]",
    "remarks": "{user}",
    "template": "Host: {host}\nPort: {port}\nUsername: {user}\nPassword: {pass}\nหมดอายุ: {exp}\n"
                "Response status: 200 Connection established\nPayload: POST /cdn-cgi/speculation HTTP/1.1[crlf]Host: search.ais.co.th[crlf]User-Agent: [ua][crlf][crlf][split][cr]PATCH /ssh HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]Upgrade: websocket[crlf][crlf]",
    "ext": "txt", "fname": "{user}",
}


# ---------- ไฟล์ JSON ----------
def read_json(path, default):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        return default

def write_json(path, obj):
    old = os.umask(0o077)
    try:
        tmp = path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(obj, f, ensure_ascii=False)
        os.replace(tmp, path)
    finally:
        os.umask(old)


# ---------- บัญชีแอดมิน (user + password) ----------
def hash_pw(pw, salt):
    return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 200_000).hex()

def load_auth():
    return read_json(CONF, {})

def admin_name():
    return str(load_auth().get("user") or "admin")

def _save_auth(user, pw):
    salt = secrets.token_bytes(16)
    write_json(CONF, {"user": user, "salt": salt.hex(), "hash": hash_pw(pw, salt)})

def set_password(from_stdin=False, user_arg=None):
    user = user_arg or os.environ.get("XXTLONLINE_DASH_USER") or admin_name()
    if from_stdin:
        pw = sys.stdin.readline().rstrip("\n")
        if len(pw) < 8:
            sys.exit("รหัสผ่านต้องยาวอย่างน้อย 8 ตัว")
    else:
        user = input("ชื่อผู้ใช้แดชบอร์ด [%s]: " % user).strip() or user
        while True:
            pw = getpass.getpass("ตั้งรหัสผ่านแดชบอร์ด (อย่างน้อย 8 ตัว): ")
            if len(pw) < 8:
                print("สั้นเกินไป"); continue
            if pw != getpass.getpass("ยืนยันรหัสผ่าน: "):
                print("ไม่ตรงกัน"); continue
            break
    if not ADMIN_RE.match(user):
        sys.exit("ชื่อผู้ใช้ใช้ได้เฉพาะ a-z A-Z 0-9 _ . - ยาว 3-32 ตัว")
    _save_auth(user, pw)
    print("บันทึกแล้ว — ชื่อผู้ใช้: %s" % user)

def check_login(user, pw):
    c = load_auth()
    try:
        ok_pw = hmac.compare_digest(hash_pw(pw, bytes.fromhex(c["salt"])), c["hash"])
    except Exception:
        return False
    ok_user = hmac.compare_digest((str(c.get("user") or "admin")).encode(), user.encode())
    return ok_pw and ok_user

def change_account(tok, b):
    cur = str(b.get("current", ""))
    if not check_login(admin_name(), cur):
        time.sleep(1)
        return "รหัสผ่านปัจจุบันไม่ถูกต้อง"
    nu = str(b.get("username", "")).strip() or admin_name()
    npw = str(b.get("password", ""))
    if not ADMIN_RE.match(nu):
        return "ชื่อผู้ใช้ใช้ได้เฉพาะ a-z A-Z 0-9 _ . - ยาว 3-32 ตัว"
    if npw and len(npw) < 8:
        return "รหัสผ่านใหม่ต้องยาวอย่างน้อย 8 ตัว"
    with lock:
        if npw:
            _save_auth(nu, npw)
        else:
            c = load_auth(); c["user"] = nu; write_json(CONF, c)
        for t in [t for t in sessions if t != tok]:   # ออกจากระบบอุปกรณ์อื่นทั้งหมด
            sessions.pop(t, None)
    return None


# ---------- ข้อมูลเครื่อง ----------
def sys_conf():
    c = {}
    try:
        for line in open(SYS_CONF):
            if "=" in line:
                k, v = line.strip().split("=", 1)
                c[k] = v
    except Exception:
        pass
    return c

def ws_port():
    try:
        return int(sys_conf().get("WS_PORT", "80") or 80)
    except Exception:
        return 80

def ws_ports():
    c = sys_conf()
    out = [int(x) for x in re.split(r"[,\s]+", c.get("WS_PORTS", "") or "") if x.isdigit()]
    return out or [ws_port()]

def ssl_port():
    """พอร์ต TLS/SNI ของอุโมงค์ (ตัวแรก) หรือ 0 ถ้าปิด"""
    for x in re.split(r"[,\s]+", sys_conf().get("SSL_PORT", "") or ""):
        if x.isdigit():
            return int(x)
    return 0

def udp_port():
    try:
        return int(sys_conf().get("UDPGW_PORT", "7300") or 7300)
    except Exception:
        return 7300

_ip = [0.0, ""]
def public_ip():
    if time.time() < _ip[0]:
        return _ip[1]
    ip = ""
    try:
        import urllib.request
        ip = urllib.request.urlopen("https://api.ipify.org", timeout=3).read().decode().strip()
    except Exception:
        try:
            ip = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=3).stdout.split()[0]
        except Exception:
            ip = ""
    _ip[0], _ip[1] = time.time() + (600 if ip else 30), ip
    return ip

def server_host():
    return DOMAIN or public_ip()


# ---------- รูปแบบ Config (profiles) ----------
def load_profiles():
    d = read_json(PROF_CONF, None)
    if isinstance(d, dict) and isinstance(d.get("profiles"), list) and d["profiles"]:
        profs = []
        for x in d["profiles"]:
            if isinstance(x, dict) and x.get("id"):
                p = dict(DEFAULT_PROFILE); p.update({k: v for k, v in x.items() if k in DEFAULT_PROFILE})
                p["id"] = str(x["id"]); profs.append(p)
        if profs:
            default = d.get("default") if any(p["id"] == d.get("default") for p in profs) else profs[0]["id"]
            return {"default": default, "profiles": profs}
    # ย้ายจาก npv.json เวอร์ชันเก่า (ถ้ามี)
    old = read_json(NPV_CONF, {})
    p = dict(DEFAULT_PROFILE); p["id"] = "default"
    for src, dst in (("template", "template"), ("host", "host"), ("port", "port"), ("ext", "ext"), ("fname", "fname"),
                     ("npv_remarks", "remarks"), ("npv_proxy", "proxy"), ("npv_sni", "sni"), ("npv_payload", "payload")):
        if src in old:
            p[dst] = old[src]
    return {"default": "default", "profiles": [p]}

def clean_profile(b):
    def g(k, d=""):
        v = b.get(k)
        return d if v is None else str(v)
    p = {"name": g("name").strip(), "bug": g("bug").strip(), "host": g("host").strip(),
         "sni": g("sni").strip(), "proxy": g("proxy").strip(),
         "payload": g("payload", DEFAULT_PROFILE["payload"]), "remarks": g("remarks", "{user}").strip(),
         "template": g("template"), "ext": g("ext", "txt").strip().lstrip("."), "fname": g("fname", "{user}").strip()}
    try:
        p["port"] = int(b.get("port") or 0)
    except Exception:
        return None, "พอร์ตไม่ถูกต้อง"
    if not re.fullmatch(r"[^\x00-\x1f<>]{1,40}", p["name"]): return None, "ชื่อรูปแบบต้องยาว 1-40 ตัวอักษร"
    if not re.fullmatch(r"[A-Za-z0-9.-]{0,253}", p["bug"]): return None, "บัคโฮสใช้ได้เฉพาะ a-z 0-9 . -"
    if not re.fullmatch(r"[A-Za-z0-9.-]{0,253}", p["host"]): return None, "host ไม่ถูกต้อง"
    if not 0 <= p["port"] <= 65535: return None, "พอร์ตไม่ถูกต้อง"
    if p["sni"] and not re.fullmatch(r"[A-Za-z0-9.{}-]{1,253}", p["sni"]): return None, "SNI ไม่ถูกต้อง"
    if p["proxy"] and not re.fullmatch(r"[A-Za-z0-9.{}-]{1,253}:[0-9]{1,5}", p["proxy"]): return None, "HTTP proxy ต้องเป็นรูปแบบ host:port หรือเว้นว่าง"
    if not 1 <= len(p["payload"]) <= 2000: return None, "payload ต้องยาว 1-2000 ตัวอักษร"
    if not 1 <= len(p["remarks"]) <= 60: return None, "ชื่อโปรไฟล์ต้องยาว 1-60 ตัวอักษร"
    if not 1 <= len(p["template"]) <= 4000: return None, "รูปแบบข้อความต้องยาว 1-4000 ตัวอักษร"
    if not re.fullmatch(r"[A-Za-z0-9]{1,8}", p["ext"]): return None, "นามสกุลไฟล์ใช้ a-z 0-9 ยาวไม่เกิน 8"
    if not re.fullmatch(r"[A-Za-z0-9_.{}-]{1,40}", p["fname"]): return None, "ชื่อไฟล์ใช้ได้เฉพาะ a-z 0-9 _ . - และตัวแปร {user}"
    return p, None

def save_profile(b):
    p, err = clean_profile(b)
    if err:
        return None, err
    with lock:
        d = load_profiles()
        pid = str(b.get("id") or "")
        if pid:
            idx = next((i for i, x in enumerate(d["profiles"]) if x["id"] == pid), None)
            if idx is None:
                return None, "ไม่พบรูปแบบนี้"
            p["id"] = pid; d["profiles"][idx] = p
        else:
            if len(d["profiles"]) >= MAX_PROFILES:
                return None, "เพิ่มได้สูงสุด %d รูปแบบ" % MAX_PROFILES
            p["id"] = secrets.token_hex(4); d["profiles"].append(p)
        if b.get("make_default") or len(d["profiles"]) == 1:
            d["default"] = p["id"]
        write_json(PROF_CONF, d)
    return p["id"], None

def del_profile(pid):
    with lock:
        d = load_profiles()
        if len(d["profiles"]) <= 1:
            return "ต้องเหลืออย่างน้อย 1 รูปแบบ"
        left = [x for x in d["profiles"] if x["id"] != pid]
        if len(left) == len(d["profiles"]):
            return "ไม่พบรูปแบบนี้"
        d["profiles"] = left
        if d["default"] == pid:
            d["default"] = left[0]["id"]
        write_json(PROF_CONF, d)
    return None

def set_default_profile(pid):
    with lock:
        d = load_profiles()
        if not any(x["id"] == pid for x in d["profiles"]):
            return "ไม่พบรูปแบบนี้"
        d["default"] = pid
        write_json(PROF_CONF, d)
    return None

def pick_profile(pid=""):
    d = load_profiles()
    want = pid or d["default"]
    return next((p for p in d["profiles"] if p["id"] == want), None)

_probe_cache = {}
def _probe_ws(port):
    """ต่อเข้าพอร์ต WS จริง ส่ง payload แล้วต้องได้ 101 + SSH banner ของ Dropbear กลับมา"""
    import socket
    try:
        s = socket.create_connection(("127.0.0.1", port), timeout=3)
        s.settimeout(3)
        s.sendall(b"GET / HTTP/1.1\r\nHost: probe\r\nUpgrade: websocket\r\n\r\n")
        buf = b""
        while b"SSH-" not in buf and len(buf) < 512:
            d = s.recv(512)
            if not d:
                break
            buf += d
        s.close()
        return (b" 101 " in buf or b" 200 " in buf) and b"SSH-2.0" in buf
    except Exception:
        return False

def live_ws_port():
    """พอร์ต WS แรกที่ใช้งานได้จริง (0 = ไม่มีพอร์ตไหนต่อ Dropbear ได้) — แคช 15 วินาที"""
    now = time.time()
    c = _probe_cache.get("ws")
    if c and now < c[0]:
        return c[1]
    port = next((p for p in ws_ports() if _probe_ws(p)), 0)
    _probe_cache["ws"] = (now + 15, port)
    return port

def eff(p):
    # รูปแบบที่ตั้ง SNI = ต่อผ่าน TLS → ใช้พอร์ต SSL ของอุโมงค์ (ถ้าเปิดอยู่)
    # ไม่งั้นใช้พอร์ต WS แรกที่ตอบ SSH banner ได้จริง (กันไฟล์ชี้พอร์ต 80 ที่ถูกโปรแกรมอื่นแย่งไป)
    default_port = ssl_port() if (p["sni"] and ssl_port()) else (live_ws_port() or ws_port())
    return (p["host"] or server_host()), (p["port"] or default_port)

def profile_view(p):
    v = dict(p); v["host_eff"], v["port_eff"] = eff(p)
    return v


# ---------- สร้างข้อความ / ลิงก์จากรูปแบบ ----------
TOKEN_RE = re.compile(r"\{(host|port|user|pass|exp|bug)\}")

def fill(t, v):
    return TOKEN_RE.sub(lambda m: str(v[m.group(1)]), t)

def _b64(s):
    return base64.b64encode(s.encode()).decode()

def render(p, c):
    """c = {user, password, exp} -> ข้อความ/ไฟล์/ลิงก์ NPV/NetMod ตามรูปแบบ p"""
    host, port = eff(p)
    v = {"host": host, "port": port, "user": c["user"], "pass": c["password"], "exp": c["exp"], "bug": p["bug"] or host}
    w = lambda s: "npvs1:" + _b64(s) if s else ""
    remarks, payload = fill(p["remarks"], v), fill(p["payload"], v)
    sni, proxy = fill(p["sni"], v), fill(p["proxy"], v)
    npv = {"sshConfigType": w("SSH-Proxy-Payload"), "remarks": w(remarks), "sshHost": w(host), "sshPort": port,
           "sshUsername": w(c["user"]), "sshPassword": w(c["password"]), "sshAuthMethod": w("PASSWORD"),
           "sshPrivateKey": "", "sshPrivateKeyPassphrase": "", "sni": sni, "tlsVersion": w("DEFAULT"),
           "httpProxy": w(proxy), "authenticateProxy": False, "proxyUsername": "", "proxyPassword": "",
           "payload": w(payload), "dnsTTMode": w("UDP"), "dnsServer": "", "nameserver": "", "publicKey": "",
           "udpgwPort": udp_port(), "udpgwTransparentDNS": True}
    q = lambda s: quote(str(s), safe="!~*'()")
    nm_link = "ssh://%s:%s@%s:%s#%s" % (q(c["user"]), q(c["password"]), host, port, q(remarks))
    nm = (nm_link + "\n\nHost: %s\nPort: %s\nUsername: %s\nPassword: %s\nPayload: %s\nSNI: %s\nHTTP Proxy: %s\nUDPGW: 127.0.0.1:%s"
          % (host, port, c["user"], c["password"], payload, sni or "-", proxy or "-", udp_port()))
    fname = re.sub(r"[^A-Za-z0-9_.-]", "_", fill(p["fname"], v)) + "." + p["ext"]
    warn = ""
    if not p["sni"] and not live_ws_port():
        warn = "ตรวจแล้วยังไม่มีพอร์ต WS ไหนต่อ Dropbear ได้ — รัน: sudo xxtlonline status"
    return {"name": p["name"], "host": host, "port": port, "warn": warn, "text": fill(p["template"], v), "filename": fname,
            "npv": "npvt-ssh://" + _b64(json.dumps(npv, separators=(",", ":"), ensure_ascii=False)),
            "netmod": nm, "netmod_link": nm_link}


# ---------- API keys ----------
def key_hash(k):
    return hashlib.sha256(k.encode()).hexdigest()

def load_keys():
    d = read_json(KEYS_CONF, {})
    ks = d.get("keys") if isinstance(d, dict) else None
    return [k for k in (ks or []) if isinstance(k, dict) and k.get("id") and k.get("hash")]

def parse_ips(s):
    out = []
    for x in re.split(r"[\s,;]+", str(s or "").strip()):
        if x:
            try:
                out.append(str(ipaddress.ip_address(x)))
            except ValueError:
                return None
    return out[:10]

def create_key(label, ips):
    label = str(label or "").strip()
    if not re.fullmatch(r"[^\x00-\x1f<>]{1,40}", label):
        return None, None, "ชื่อคีย์ต้องยาว 1-40 ตัวอักษร"
    ips = parse_ips(ips)
    if ips is None:
        return None, None, "รูปแบบ IP ไม่ถูกต้อง (คั่นด้วยเว้นวรรคหรือ ,)"
    with lock:
        keys = load_keys()
        if len(keys) >= MAX_KEYS:
            return None, None, "สร้างคีย์ได้สูงสุด %d ชุด" % MAX_KEYS
        k = "xxtl_" + secrets.token_urlsafe(32)
        rec = {"id": secrets.token_hex(4), "label": label, "hash": key_hash(k), "prefix": k[:9],
               "created": time.strftime("%Y-%m-%d %H:%M"), "last_used": "", "last_ts": 0, "ips": ips}
        keys.append(rec)
        write_json(KEYS_CONF, {"keys": keys})
    return k, rec, None

def del_key(kid):
    with lock:
        keys = load_keys()
        left = [k for k in keys if k["id"] != kid]
        if len(left) == len(keys):
            return "ไม่พบคีย์นี้"
        write_json(KEYS_CONF, {"keys": left})
    return None

def find_key(tok):
    h = key_hash(tok)
    for r in load_keys():
        if hmac.compare_digest(r["hash"], h):
            return r
    return None

def touch_key(rec):
    now = time.time()
    if now - float(rec.get("last_ts") or 0) < 60:
        return
    with lock:
        keys = load_keys()
        for k in keys:
            if k["id"] == rec["id"]:
                k["last_ts"] = now; k["last_used"] = time.strftime("%Y-%m-%d %H:%M")
        write_json(KEYS_CONF, {"keys": keys})

def key_view(r):
    return {k: r.get(k) for k in ("id", "label", "prefix", "created", "last_used", "ips")}


# ---------- ผู้ใช้ / ระบบ ----------
def user_until(u):
    """เวลาหมดอายุละเอียด (epoch) ของบัญชีทดลอง/แพ็กเกจสั้น หรือ None"""
    try:
        return int(open(os.path.join(UNTIL_DIR, u)).read().strip())
    except Exception:
        return None

def user_exp(u):
    ts = user_until(u)
    if ts:
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))
    try:
        return open(os.path.join(EXP_DIR, u)).read().strip()
    except Exception:
        return ""

def run_cli(*args):
    try:
        with cli_lock:
            r = subprocess.run([CLI, *args], capture_output=True, text=True, timeout=20)
        return r.returncode == 0, (r.stdout + r.stderr).strip()
    except Exception as e:
        return False, str(e)

ONLINE_FILE = os.environ.get("XXTLONLINE_ONLINE_FILE", "/run/xxtlonline/online.json")

def online_detail():
    """{user: {"conns": n, "ips": {ip: n}}} จาก xxtlonline-acct (สดไม่เกิน ~10 วินาที) — ไม่มี = {}"""
    try:
        if time.time() - os.path.getmtime(ONLINE_FILE) > 10:
            return None
        return json.load(open(ONLINE_FILE)).get("users", {})
    except Exception:
        return None

def online_counts():
    det = online_detail()
    if det is not None:
        return {u: v.get("conns", 0) for u, v in det.items()}
    counts = {}
    try:
        out = subprocess.run(["ps", "-eo", "user:32=,comm="], capture_output=True,
                             text=True, timeout=5).stdout
        for line in out.splitlines():
            p = line.split()
            if len(p) == 2 and p[1] in ("dropbear", "sshd") and p[0] != "root":
                counts[p[0]] = counts.get(p[0], 0) + 1
    except Exception:
        pass
    return counts

ACCT_FILE = os.environ.get("XXTLONLINE_ACCT_FILE", "/run/xxtlonline/acct.json")

def acct_status():
    """สถานะตัวนับข้อมูล xxtlonline-acct (ไว้วินิจฉัย) — ไม่มี/เก่าเกิน 15 วิ = ตัวนับไม่ทำงาน"""
    try:
        d = json.load(open(ACCT_FILE))
        d["alive"] = time.time() - d.get("ts", 0) < 15
        return d
    except Exception:
        return {"alive": False}

_USAGE_LAST = {}   # user → ยอดล่าสุดที่อ่านได้ (กันยอดวูบเป็น 0 ตอนอ่านชนช่วงที่ไฟล์กำลังถูกเขียน)

def user_usage(u):
    p = os.path.join(USAGE_DIR, u)
    for _ in range(3):
        try:
            v = open(p).read().strip()
            if v:
                n = max(0, int(v))
                _USAGE_LAST[u] = n
                return n
        except FileNotFoundError:
            _USAGE_LAST.pop(u, None)          # ยังไม่มีไฟล์/ถูกลบแล้ว = 0 จริง
            return 0
        except Exception:
            pass
        time.sleep(0.01)                      # ไฟล์ว่าง/อ่านไม่ได้ชั่วคราว → ลองใหม่
    return _USAGE_LAST.get(u, 0)

def list_users():
    today = time.strftime("%Y-%m-%d")
    online = online_counts()
    detail = online_detail() or {}
    users = []
    try:
        names = sorted(os.listdir(EXP_DIR))
    except Exception:
        names = []
    for n in names:
        if not USER_RE.match(n):
            continue
        try:
            exp = open(os.path.join(EXP_DIR, n)).read().strip()
        except Exception:
            continue
        ts = user_until(n)
        if ts:
            exp, expired = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts)), time.time() >= ts
        else:
            expired = exp < today
        users.append({"user": n, "exp": exp, "expired": expired, "online": online.get(n, 0),
                      "ips": sorted((detail.get(n) or {}).get("ips", {})),
                      "suspended": os.path.exists(os.path.join(SUSP_DIR, n)), "used": user_usage(n)})
    return users

def service_state(name):
    r = subprocess.run(["systemctl", "is-active", name], capture_output=True, text=True)
    return r.stdout.strip() == "active"

def stats():
    mem = {}
    for line in open("/proc/meminfo"):
        k, v = line.split(":")
        mem[k] = int(v.split()[0])
    total, avail = mem.get("MemTotal", 1), mem.get("MemAvailable", 0)
    du = shutil.disk_usage("/")
    up = float(open("/proc/uptime").read().split()[0])
    return {"load": round(os.getloadavg()[0], 2),
            "mem_pct": round(100 * (total - avail) / total),
            "disk_pct": round(100 * du.used / du.total),
            "uptime_h": round(up / 3600, 1)}

def state():
    users = list_users()
    P = load_profiles()
    svcs = {"Dropbear": "xxtlonline-dropbear", "WS Proxy": "xxtlonline-ws",
            "UDPGW": "xxtlonline-udpgw", "SSH": "ssh"}
    return {"users": users,
            "online_total": sum(u["online"] for u in users),
            "services": {k: service_state(v) for k, v in svcs.items()},
            "stats": stats(),
            "server": {"host": server_host(), "ws_port": ws_port(), "ws_live": live_ws_port(), "ws_ports": ws_ports(), "ssl_port": ssl_port(),
                       "udp_port": udp_port(), "https": bool(DOMAIN)},
            "profiles": [profile_view(p) for p in P["profiles"]], "default_profile": P["default"],
            "keys": [key_view(k) for k in load_keys()],
            "me": admin_name(), "version": VERSION}

def creds_from(out, user):
    m = re.search(r"Password\s*:\s*(\S+)", out)
    if not m:
        return None
    return {"user": user, "password": m.group(1), "exp": user_exp(user)}

def dash_creds(c):
    """ข้อมูลบัญชีสำหรับหน้าเว็บ: เรนเดอร์ครบทุกรูปแบบ ให้กดสลับได้ทันที"""
    c["renders"] = {p["id"]: render(p, c) for p in load_profiles()["profiles"]}
    return c


# ---------- REST API (/api/v1/...) สำหรับ panel ร้านค้า ----------
def cli_reply(ok, out, extra=None, okcode=200):
    if ok:
        d = {"ok": True, "message": out}
        d.update(extra or {})
        return okcode, d
    code = 404 if "ไม่พบ" in out else 409 if "อยู่แล้ว" in out else 400
    return code, {"ok": False, "error": out}

def api_creds(user, pw, p):
    r = render(p, {"user": user, "password": pw, "exp": user_exp(user)})
    return {"username": user, "password": pw, "expires": user_exp(user), "host": r["host"], "port": r["port"],
            "udpgw_port": udp_port(), "warn": r["warn"], "profile": {"id": p["id"], "name": p["name"]}, "text": r["text"],
            "filename": r["filename"], "links": {"npv": r["npv"], "netmod": r["netmod_link"]},
            "netmod_text": r["netmod"]}

def api_user(u):
    return {"username": u["user"], "expires": u["exp"], "expired": u["expired"],
            "suspended": u["suspended"], "online": u["online"], "used_bytes": u["used"],
            "connections": u["online"], "online_ips": len(u.get("ips", [])), "ips": u.get("ips", [])}

def api_minutes(body):
    """แพ็กเกจสั้นกว่า 1 วัน (เช่น ทดลอง 20 นาที): body.minutes 1-1440 — ไม่มี = None"""
    if body.get("minutes") in (None, ""):
        return None, None
    try:
        m = int(body.get("minutes"))
        assert 1 <= m <= 1440
        return m, None
    except Exception:
        return None, "จำนวนนาทีไม่ถูกต้อง (1-1440)"

def api_days(body, default=30):
    try:
        days = int(body.get("days", default))
        assert 1 <= days <= 3650
        return days, None
    except Exception:
        return None, "จำนวนวันไม่ถูกต้อง (1-3650)"

def api_route(method, parts, body):
    if parts == ["ping"] and method == "GET":
        return 200, {"ok": True, "service": "xxtlonline", "version": VERSION}
    if parts == ["info"] and method == "GET":
        users = list_users(); P = load_profiles()
        return 200, {"ok": True, "data": {
            "host": server_host(), "ws_port": ws_port(), "ws_ports": ws_ports(), "ssl_port": ssl_port(), "udpgw_port": udp_port(),
            "users": len(users), "online": sum(u["online"] for u in users),
            "acct": acct_status(),
            "default_profile": P["default"],
            "profiles": [{"id": p["id"], "name": p["name"]} for p in P["profiles"]]}}
    if not parts or parts[0] != "users":
        return 404, {"ok": False, "error": "not found"}
    if len(parts) == 1:
        if method == "GET":
            return 200, {"ok": True, "data": [api_user(u) for u in list_users()]}
        if method == "POST":
            user = str(body.get("username") or body.get("user") or "")
            if not USER_RE.match(user):
                return 400, {"ok": False, "error": "ชื่อผู้ใช้ไม่ถูกต้อง (a-z 0-9 _ - ยาว 3-16 เริ่มด้วยตัวอักษร)"}
            minutes, err = api_minutes(body)
            if err:
                return 400, {"ok": False, "error": err}
            days, err = (None, None) if minutes else api_days(body)
            if err:
                return 400, {"ok": False, "error": err}
            pw = str(body.get("password") or "")
            if pw and not PW_RE.match(pw):
                return 400, {"ok": False, "error": "รหัสผ่านต้องยาว 6-64 ตัว ใช้ตัวอักษร ตัวเลข และ !@#%^&*_+=.,- เท่านั้น"}
            p = pick_profile(str(body.get("profile") or ""))
            if not p:
                return 400, {"ok": False, "error": "ไม่พบรูปแบบ (profile) ที่ระบุ"}
            ok, out = run_cli("add", user, (str(minutes) + "m") if minutes else str(days), *([pw] if pw else []))
            c = creds_from(out, user) if ok else None
            if ok and c:
                return 201, {"ok": True, "data": api_creds(user, c["password"], p)}
            return cli_reply(ok, out)
        return 405, {"ok": False, "error": "method not allowed"}
    user = parts[1]
    if not USER_RE.match(user):
        return 400, {"ok": False, "error": "ชื่อผู้ใช้ไม่ถูกต้อง"}
    if len(parts) == 2:
        if method == "GET":
            u = next((x for x in list_users() if x["user"] == user), None)
            return (200, {"ok": True, "data": api_user(u)}) if u else (404, {"ok": False, "error": "ไม่พบ user นี้"})
        if method == "DELETE":
            return cli_reply(*run_cli("del", user))
        return 405, {"ok": False, "error": "method not allowed"}
    if len(parts) == 3 and method == "POST":
        act = parts[2]
        if act == "extend":
            days, err = api_days(body)
            if err:
                return 400, {"ok": False, "error": err}
            ok, out = run_cli("extend", user, str(days))
            return cli_reply(ok, out, {"data": {"username": user, "expires": user_exp(user)}})
        if act == "passwd":
            pw = str(body.get("password") or "")
            if pw and not PW_RE.match(pw):
                return 400, {"ok": False, "error": "รหัสผ่านต้องยาว 6-64 ตัว ใช้ตัวอักษร ตัวเลข และ !@#%^&*_+=.,- เท่านั้น"}
            p = pick_profile(str(body.get("profile") or ""))
            if not p:
                return 400, {"ok": False, "error": "ไม่พบรูปแบบ (profile) ที่ระบุ"}
            ok, out = run_cli("passwd", user, *([pw] if pw else []))
            c = creds_from(out, user) if ok else None
            if ok and c:
                return 200, {"ok": True, "data": api_creds(user, c["password"], p)}
            return cli_reply(ok, out)
        if act in ("suspend", "resume"):
            ok, out = run_cli(act, user)
            return cli_reply(ok, out, {"data": {"username": user, "suspended": act == "suspend"}})
    return 404, {"ok": False, "error": "not found"}


# ---------- web ----------
PAGE = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "index.html"), "rb").read()


class Handler(BaseHTTPRequestHandler):
    server_version = "xxtlonline-dash"
    def log_message(self, *a): pass

    def _send(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy",
            "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
            "img-src data:; connect-src 'self'; frame-ancestors 'none'")
        if getattr(self, "_cookie", None):
            self.send_header("Set-Cookie", self._cookie)
        self.end_headers()
        self.wfile.write(data)

    def _host_ok(self):
        if HOST not in ("127.0.0.1", "localhost"):
            return True
        h = (self.headers.get("Host") or "").rsplit(":", 1)[0].lower()
        return h in ("127.0.0.1", "localhost") or (DOMAIN != "" and h == DOMAIN)

    def _ip(self):
        ip = self.client_address[0]
        if ip in ("127.0.0.1", "::1"):          # มาจาก nginx บนเครื่องเดียวกัน
            ip = (self.headers.get("X-Real-IP") or ip).strip()[:64]
        return ip

    def _session(self):
        c = SimpleCookie(self.headers.get("Cookie", ""))
        tok = c["sid"].value if "sid" in c else ""
        s = sessions.get(tok)
        if s and s[0] > time.time():
            return tok, s[1]
        sessions.pop(tok, None)
        return None, None

    def _body(self, strict):
        if strict and "application/json" not in (self.headers.get("Content-Type") or ""):
            raise ValueError
        n = int(self.headers.get("Content-Length") or 0)
        if n < 0 or n > 16384:
            raise ValueError
        if n == 0:
            return {}
        b = json.loads(self.rfile.read(n))
        if not isinstance(b, dict):
            raise ValueError
        return b

    # ----- API key -----
    def _api(self, method, path):
        ip, now = self._ip(), time.time()
        f = api_fails.get(ip, [0, 0])
        if f[1] > now:
            return self._send(429, {"ok": False, "error": "ลองมากเกินไป รอ 5 นาที"})
        auth = self.headers.get("Authorization", "")
        tok = auth[7:].strip() if auth.lower().startswith("bearer ") else (self.headers.get("X-API-Key") or "").strip()
        rec = find_key(tok) if tok else None
        if not rec:
            f[0] += 1
            if f[0] >= 10:
                f = [0, now + 300]
            api_fails[ip] = f
            if len(api_fails) > 500:
                for k in [k for k, v in api_fails.items() if v[1] < now][:250]:
                    api_fails.pop(k, None)
            time.sleep(0.3)
            return self._send(401, {"ok": False, "error": "API key ไม่ถูกต้อง"})
        if rec.get("ips") and ip not in rec["ips"]:
            return self._send(403, {"ok": False, "error": "IP นี้ไม่ได้รับอนุญาต"})
        api_fails.pop(ip, None)
        try:
            body = self._body(False) if method in ("POST", "DELETE") else {}
        except Exception:
            return self._send(400, {"ok": False, "error": "bad request (ต้องเป็น JSON)"})
        touch_key(rec)
        parts = [x for x in path[len("/api/v1/"):].split("/") if x]
        try:
            code, d = api_route(method, parts, body)
        except Exception:
            code, d = 500, {"ok": False, "error": "internal error"}
        self._send(code, d)

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        path = urlsplit(self.path).path
        if path.startswith("/api/v1/"):
            return self._api("GET", path)
        if path == "/":
            return self._send(200, PAGE, "text/html")
        if path == "/api/state":
            tok, csrf = self._session()
            if not tok:
                return self._send(401, {"error": "login required"})
            d = state(); d["csrf"] = csrf
            return self._send(200, d)
        self._send(404, {"error": "not found"})

    def do_DELETE(self):
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        path = urlsplit(self.path).path
        if path.startswith("/api/v1/"):
            return self._api("DELETE", path)
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if not self._host_ok():
            return self._send(403, {"error": "bad host"})
        path = urlsplit(self.path).path
        if path.startswith("/api/v1/"):
            return self._api("POST", path)
        try:
            body = self._body(True)
        except Exception:
            return self._send(400, {"ok": False, "error": "bad request"})

        if path == "/api/login":
            return self._login(body)

        tok, csrf = self._session()
        if not tok:
            return self._send(401, {"ok": False, "error": "login required"})
        if not hmac.compare_digest(self.headers.get("X-CSRF", ""), csrf):
            return self._send(403, {"ok": False, "error": "csrf"})

        if path == "/api/logout":
            sessions.pop(tok, None)
            return self._send(200, {"ok": True})

        # --- รูปแบบ config ---
        if path == "/api/profile/save":
            pid, err = save_profile(body)
            return self._send(200, {"ok": err is None, "error": err, "id": pid})
        if path == "/api/profile/del":
            err = del_profile(str(body.get("id", "")))
            return self._send(200, {"ok": err is None, "error": err})
        if path == "/api/profile/default":
            err = set_default_profile(str(body.get("id", "")))
            return self._send(200, {"ok": err is None, "error": err})

        # --- API key ---
        if path == "/api/keys/create":
            k, rec, err = create_key(body.get("label"), body.get("ips"))
            return self._send(200, {"ok": err is None, "error": err, "key": k, "rec": key_view(rec) if rec else None})
        if path == "/api/keys/del":
            err = del_key(str(body.get("id", "")))
            return self._send(200, {"ok": err is None, "error": err})

        # --- บัญชีแอดมิน ---
        if path == "/api/account":
            err = change_account(tok, body)
            return self._send(200, {"ok": err is None, "error": err, "me": admin_name()})

        # --- จัดการ user ---
        user = str(body.get("user", ""))
        if not USER_RE.match(user):
            return self._send(400, {"ok": False, "error": "ชื่อผู้ใช้ไม่ถูกต้อง"})

        pw = str(body.get("password", "") or "")
        if pw and not PW_RE.match(pw):
            return self._send(400, {"ok": False, "error": "รหัสผ่านต้องยาว 6-64 ตัว ใช้ตัวอักษร ตัวเลข และ !@#%^&*_+=.,- เท่านั้น"})

        if path in ("/api/add", "/api/extend"):
            days, err = api_days(body)
            if err:
                return self._send(400, {"ok": False, "error": err})
            if path == "/api/add":
                ok, out = run_cli("add", user, str(days), *([pw] if pw else []))
            else:
                ok, out = run_cli("extend", user, str(days))
        elif path == "/api/passwd":
            ok, out = run_cli("passwd", user, *([pw] if pw else []))
        elif path == "/api/suspend":
            ok, out = run_cli("suspend", user)
        elif path == "/api/resume":
            ok, out = run_cli("resume", user)
        elif path == "/api/del":
            ok, out = run_cli("del", user)
        else:
            return self._send(404, {"ok": False, "error": "not found"})

        creds = None
        if ok and path in ("/api/add", "/api/passwd"):
            c = creds_from(out, user)
            if c:
                creds = dash_creds(c)
        return self._send(200, {"ok": ok, "output": out, "creds": creds, "error": None if ok else out})

    def _login(self, body):
        ip = self._ip()
        now = time.time()
        f = fails.get(ip, [0, 0])
        if f[1] > now:
            return self._send(429, {"ok": False, "error": "ลองมากเกินไป รอ 5 นาที"})
        if check_login(str(body.get("username", "")).strip(), str(body.get("password", ""))):
            fails.pop(ip, None)
            for t in [t for t, s in sessions.items() if s[0] < now]:
                sessions.pop(t, None)
            tok, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(16)
            sessions[tok] = (now + SESSION_TTL, csrf)
            secure = "; Secure" if self.headers.get("X-Forwarded-Proto") == "https" else ""
            self._cookie = f"sid={tok}; HttpOnly; SameSite=Strict; Path={BASE or '/'}; Max-Age={SESSION_TTL}{secure}"
            return self._send(200, {"ok": True, "csrf": csrf})
        f[0] += 1
        if f[0] >= 5:
            f = [0, now + 300]
        fails[ip] = f
        time.sleep(1)
        self._send(401, {"ok": False, "error": "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง"})


if __name__ == "__main__":
    if "--create-key" in sys.argv:       # python3 app.py --create-key "ชื่อคีย์" [IP ...]  → พิมพ์ API key ออกทาง stdout
        i = sys.argv.index("--create-key")
        k, _rec, err = create_key(sys.argv[i + 1] if i + 1 < len(sys.argv) else "", " ".join(sys.argv[i + 2:]))
        if err:
            sys.exit(err)
        print(k)
    elif "--set-password" in sys.argv:
        ua = sys.argv[sys.argv.index("--user") + 1] if "--user" in sys.argv[:-1] else None
        set_password("--stdin" in sys.argv, ua)
    else:
        if not os.path.exists(CONF):
            sys.exit("ยังไม่ได้ตั้งรหัสผ่าน: รัน python3 app.py --set-password")
        ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
