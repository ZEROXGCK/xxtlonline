# xxtlonline

SSH over WebSocket + เว็บแดชบอร์ดจัดการ user (+ HTTPS ผ่านโดเมน) ติดตั้งบน VPS ด้วยคำสั่งเดียว
รองรับ Ubuntu 22.04 / 24.04 (Debian ที่ใช้ apt + systemd ก็น่าจะได้)

```
client ──(HTTP Upgrade)──> :80 xxtlonline-ws ──> 127.0.0.1:143 Dropbear
                           badvpn-udpgw 127.0.0.1:7300 (UDP ผ่าน SSH)
dashboard 127.0.0.1:8088 ──(SSH tunnel หรือ nginx HTTPS)
```

## ติดตั้ง



```bash
curl -fsSL https://raw.githubusercontent.com/ZEROXGCK/xxtlonline/main/install.sh | sudo XXTLONLINE_REPO=ZEROXGCK/xxtlonline bash
```

หรือ clone แล้วรัน:

```bash
git clone https://github.com/ZEROXGCK/xxtlonline.git
cd xxtlonline && sudo bash install.sh
```

ตัวเลือก

| ตัวเลือก | ความหมาย |
|---|---|
| `--no-dashboard` | ไม่ติดตั้งเว็บแดชบอร์ด |
| `--domain panel.example.com --email me@x.com` | เปิดแดชบอร์ดผ่าน HTTPS ทันที (ต้องชี้ A record มาที่ VPS ก่อน) |
| `--ws-port N` | พอร์ต WebSocket (ค่าเริ่มต้น 80; ถ้าใช้ `--domain` ต้องเป็น 80) |
| `--no-firewall` | ไม่แตะ ufw |
| `--tune` | จูนเครือข่าย VPS หลังติดตั้งเสร็จ (BBR/FQ/RPS/IRQ ฯลฯ — ดูหัวข้อ "จูนเครือข่าย") |

ใส่รหัสแดชบอร์ดแบบไม่ถามได้ด้วย `XXTLONLINE_DASH_PASSWORD=...` (ไม่ตั้งและไม่มีเทอร์มินัล = สุ่มให้แล้วแสดงตอนจบ)

## ใช้งาน

```bash
sudo xxtlonline                  # เมนู
sudo xxtlonline add somchai 30   # สร้าง user 30 วัน (ใส่รหัสเองเป็นอาร์กิวเมนต์ที่ 3 ได้)
sudo xxtlonline list
sudo xxtlonline extend somchai 30
sudo xxtlonline passwd somchai [รหัสใหม่]   # ว่าง = สุ่มให้
sudo xxtlonline suspend somchai             # ระงับชั่วคราว + ตัดการเชื่อมต่อ
sudo xxtlonline resume somchai
sudo xxtlonline del somchai
sudo xxtlonline status           # สถานะบริการ
```

user หมดอายุจะถูกล็อกและตัด session อัตโนมัติทุกวันเวลา 00:05 (cron)

### แดชบอร์ด (v2)

เข้าสู่ระบบด้วย **ชื่อผู้ใช้ + รหัสผ่าน** (ตั้งตอนติดตั้ง หรือใส่ `XXTLONLINE_DASH_USER` / `XXTLONLINE_DASH_PASSWORD`; ติดตั้งทับของเก่าที่ไม่มีชื่อผู้ใช้ = ใช้ `admin`)
ดีไซน์ธีมดำ-ทอง รองรับมือถือ แบ่งเป็นเมนู:

| เมนู | ทำอะไร |
|---|---|
| ภาพรวม | ออนไลน์ / ผู้ใช้ / RAM / Disk / สถานะบริการ |
| ผู้ใช้ | ค้นหา, เพิ่ม, ต่ออายุ, รีเซ็ตรหัส, ระงับ/เปิดใช้, ลบ + หน้าต่างข้อมูลบัญชีพร้อมปุ่มคัดลอก/ดาวน์โหลด |
| รูปแบบ Config | เพิ่ม / แก้ไข / ลบ รูปแบบ (บัคโฮส, SNI, HTTP proxy, payload, ข้อความ/ไฟล์ที่ส่งลูกค้า) ตั้ง "ค่าหลัก" ได้ |
| API | สร้าง/ยกเลิกคีย์สำหรับ panel ร้านค้า + เอกสารพร้อมตัวอย่าง curl |
| บัญชี | เปลี่ยนชื่อผู้ใช้/รหัสผ่านแอดมิน (อุปกรณ์อื่นจะถูกออกจากระบบ) |

**รูปแบบ Config (บัคโฮส):** แต่ละรูปแบบมี ชื่อ, บัคโฮส, Host/Port (ว่าง = อัตโนมัติ), SNI, HTTP proxy, Payload, ชื่อโปรไฟล์ในแอป, เทมเพลตข้อความ, ชื่อไฟล์/นามสกุล
ตัวแปรที่ใช้ได้: `{host} {port} {user} {pass} {exp} {bug}` (`{bug}` = บัคโฮส ถ้าว่างใช้ host) — มีแม่แบบ "WS + บัคโฮส" / "SSL / SNI" ให้กดเริ่ม
ตอนสร้างบัญชี/รีเซ็ตรหัส หน้าต่างผลลัพธ์จะมี **ปุ่มเลือกรูปแบบ** กดสลับได้ทันที พร้อมแท็บ ข้อความ / ลิงก์ NPV Tunnel (`npvt-ssh://`) / NetMod (เก็บที่ `/etc/xxtlonline/profiles.json`; ค่าจากเวอร์ชันเก่า `npv.json` ถูกย้ายมาเป็นรูปแบบ "ค่าเริ่มต้น" อัตโนมัติ)

หมายเหตุ: WS proxy ตอบ 101 ทันทีหลังรับ request แรก และตัด request ที่ตามมาก่อน SSH banner ทิ้งให้ — รหัสผ่านแสดงได้เฉพาะตอนสร้าง/รีเซ็ต เพราะระบบเก็บแค่ hash ฝั่งแดชบอร์ด

ค่าเริ่มต้นฟังที่ `127.0.0.1:8088` เท่านั้น เข้าผ่าน SSH tunnel:

```bash
ssh -L 8088:127.0.0.1:8088 root@IP_VPS      # แล้วเปิด http://127.0.0.1:8088
```

เปิดผ่านโดเมน: `sudo xxtlonline-https` (nginx ฟังแค่ 443 + Let's Encrypt ต่ออายุเอง;
ตอนขอ/ต่ออายุใบรับรองจะหยุด WS proxy ชั่วคราว ~10–20 วินาที เพราะ certbot ต้องใช้พอร์ต 80)

เปลี่ยนชื่อผู้ใช้/รหัสผ่าน: เมนู "บัญชี" ในแดชบอร์ด หรือ `sudo python3 /opt/xxtlonline-dash/app.py --set-password [--user NAME] && sudo systemctl restart xxtlonline-dash`

ความปลอดภัยของแดชบอร์ด: เก็บรหัสแบบ PBKDF2 hash, CSRF token, จำกัดการเดารหัส (5 ครั้ง/5 นาที), cookie HttpOnly + SameSite=Strict

### REST API สำหรับ panel ร้านค้า

สร้างคีย์ที่เมนู **API** (แสดงคีย์ครั้งเดียว ระบบเก็บเฉพาะ SHA-256 hash; ผูกกับ IP เซิร์ฟเวอร์ร้านค้าได้; สร้างได้ 10 ชุด ยกเลิกได้ทันที)
**ต้องเปิดแดชบอร์ดผ่านโดเมน HTTPS (`sudo xxtlonline-https`) ก่อน** ร้านค้าถึงจะเรียกจากภายนอกได้ — อย่าใช้ผ่าน HTTP เพราะคีย์จะวิ่งแบบไม่เข้ารหัส

ส่งคีย์ใน header `Authorization: Bearer <KEY>` (หรือ `X-API-Key: <KEY>`) ทุก response เป็น JSON `{"ok":true,"data":...}` / `{"ok":false,"error":"..."}`
Base URL: `https://โดเมนของคุณ/api/v1` — เดาคีย์ผิด 10 ครั้ง/5 นาที จะถูกบล็อก IP ชั่วคราว

| Method | Path | ใช้ทำอะไร |
|---|---|---|
| GET | `/ping` | ทดสอบคีย์ |
| GET | `/info` | host, พอร์ต, รายการรูปแบบ (profile id) |
| GET | `/users` | รายชื่อผู้ใช้ |
| POST | `/users` | สร้างบัญชี `{"username","days","password"?,"profile"?}` → 201 + user/pass/วันหมดอายุ/host/port/ข้อความ/ลิงก์ NPV+NetMod ตามรูปแบบที่เลือก (ไม่ระบุ = ค่าหลัก) |
| GET | `/users/{u}` | ดูผู้ใช้คนเดียว |
| POST | `/users/{u}/extend` | `{"days"}` |
| POST | `/users/{u}/passwd` | `{"password"?,"profile"?}` ว่าง = สุ่ม |
| POST | `/users/{u}/suspend` · `/resume` | ระงับ / เปิดใช้ |
| DELETE | `/users/{u}` | ลบ |

รหัส HTTP: 200/201 สำเร็จ, 400 ข้อมูลไม่ถูกต้อง, 401 คีย์ผิด, 403 IP ไม่ได้รับอนุญาต, 404 ไม่พบ user, 409 มี user อยู่แล้ว, 429 ลองมากเกินไป

```bash
curl -X POST https://panel.example.com/api/v1/users \
  -H "Authorization: Bearer xxtl_..." -H "Content-Type: application/json" \
  -d '{"username":"somchai","days":30}'
```

## จูนเครือข่าย (ไม่บังคับ)

ติดตั้งแยกจากระบบหลัก — ไม่ถูกรันถ้าไม่สั่ง (อิงจาก `VPSBOOTPRO.sh` ของ Chaiyakey99/chaiya-vpn เก็บสำเนาไว้ใน `scripts/vpsbootpro.sh`)

```bash
sudo bash install.sh --tune       # ติดตั้ง + จูนเลย
sudo xxtlonline-tune              # จูนทีหลัง (รันซ้ำได้)
sudo xxtlonline-tune --remove     # ยกเลิกค่าที่จูนไว้ (แนะนำรีบูตหลังจากนั้น)
```

ทำอะไรบ้าง: BBR + fq, TCP buffer/keepalive, RPS/RFS, ตรึง IRQ, ปิด THP, ขยาย conntrack, ตั้ง `Nice=-10` ให้ service tunnel
หมายเหตุ: ขั้นตอนสุดท้ายจะ restart dropbear/ws ชั่วครู่ ผู้ใช้ที่ต่ออยู่จะหลุดแล้วต่อใหม่ — ควรรันตอนไม่มีคนใช้เยอะ

## พอร์ตและการเชื่อมต่อ (สรุป)

| พอร์ต | ใช้กับ | ในแอป (NPV / HTTP Custom ฯลฯ) |
|---|---|---|
| `WS_PORT` (80) | SSH over WebSocket / HTTP payload → Dropbear | Host = IP/โดเมน, Port = 80, ใส่ payload |
| 22 | SSH ตรง (OpenSSH) | SSH ปกติ |
| 127.0.0.1:7300 | UDPGW (ต้องต่อผ่าน SSH ก่อน) | ตั้ง UDPGW = 127.0.0.1:7300 |

- อย่าลืมเปิดพอร์ตใน Security Group/Firewall ของผู้ให้บริการ VPS ด้วย (ufw ในเครื่องอย่างเดียวไม่พอ)

## ถอนการติดตั้ง

```bash
sudo bash uninstall.sh            # เก็บ user และ /etc/xxtlonline ไว้
sudo bash uninstall.sh --purge    # ลบ user ที่สร้างด้วย xxtlonline และคอนฟิกทั้งหมด (รวมค่าจูนเครือข่าย)
```

## โครงสร้างรีโป

```
install.sh  uninstall.sh
src/xxtlonline        คำสั่งจัดการ user
src/xxtlonline-ws     WebSocket proxy (ส่งต่อไป Dropbear เท่านั้น ไม่ใช่ open proxy)
dashboard/        app.py (เว็บ + REST API) + index.html
systemd/          unit files
scripts/https.sh  ติดตั้ง nginx + Let's Encrypt (ติดตั้งเป็นคำสั่ง xxtlonline-https)
scripts/vpsbootpro.sh  จูนเครือข่าย VPS (ติดตั้งเป็นคำสั่ง xxtlonline-tune)
```

## หมายเหตุ

- ใช้กับเซิร์ฟเวอร์ของคุณเองและตามกฎหมาย/ข้อกำหนดของผู้ให้บริการ VPS
- `xxtlonline del` ลบได้เฉพาะ user ที่สร้างผ่าน xxtlonline เท่านั้น
- UDPGW: ติดตั้งจาก apt ก่อน ถ้าไม่มีจะ build `badvpn-udpgw` จาก source (v1.999.130) อัตโนมัติ ฟังที่ `127.0.0.1:7300` ใช้ผ่าน SSH ในแอป (ตั้ง UDPGW = 127.0.0.1:7300); ถ้า build ไม่ผ่านระบบหลักยังทำงานปกติ แค่ไม่มี UDP

## พอร์ตของแดชบอร์ด / ร้านค้า
- แดชบอร์ด HTTPS ใช้พอร์ต **8443** (ไม่ใช่ 443): `sudo xxtlonline-https --domain panel.example.com --port 8443` → URL `https://panel.example.com:8443`
- แดชบอร์ดตัวจริงฟังเฉพาะ 127.0.0.1:8088 (ผ่าน nginx เท่านั้น)
- ร้าน wselx (ไม่ใส่โดเมน) ใช้ `http://IP:3000` — ตั้ง `PORT=` ได้ใน install.sh/.env

## ติดตั้งครั้งเดียวพร้อมใช้
`sudo bash install.sh` ติดตั้ง Dropbear + WS proxy + UDPGW + แดชบอร์ด และเปิดพอร์ตใน ufw ให้ครบ

## v2.3 — แก้ยอดการใช้ข้อมูลไม่ขึ้น
- `xxtlonline-acct` จับคู่ connection กับ user ด้วย PID ของ dropbear เป็นตัวสำรอง และอ่านล็อกได้หลายทาง (journal / auth.log / syslog)
- เขียนสถานะตัวนับลง `/run/xxtlonline/acct.json` และแสดงที่ `GET /api/v1/info` (ฟิลด์ `acct`) ไว้วินิจฉัย
- อัปเดตเครื่องเดิม: ติดตั้ง `src/xxtlonline-acct`, `systemd/xxtlonline-acct.service`, `dashboard/app.py` แล้ว `systemctl enable --now xxtlonline-acct` และ restart `xxtlonline-dash`

## ปริมาณการใช้ข้อมูลต่อ user (v2.2)
- `xxtlonline-acct` อ่านตัวนับต่อ connection จาก `ss` ทุก ~1 วินาที แล้วสะสมไบต์ลง `/etc/xxtlonline/usage/<user>` (เลิกใช้ iptables แล้ว)
- ยอดข้อมูลเขียนแบบ atomic (ไฟล์ชั่วคราว + rename) และแดชบอร์ดอ่านซ้ำเมื่อเจอไฟล์ว่าง → ตัวเลขไม่วูบเป็น 0 ตอนอัปเดต
- ดูยอด: `xxtlonline usage USER` หรือ `xxtlonline list` (หน่วย MB) — แดชบอร์ดและ `GET /api/v1/users` คืน `used_bytes`
- นับรวมขึ้น+ลงของ user นั้น ตั้งแต่ติดตั้งเวอร์ชันนี้ (ยอดก่อนหน้าไม่มีข้อมูลย้อนหลัง); รีบูตแล้วยอดสะสมไม่หาย (อาจขาดไม่เกิน ~1 นาที)

## บัญชีแบบนาที (ทดลอง 20 นาที)
- CLI: `xxtlonline add USER 20m` (1-1440 นาที) • API: `POST /users` ส่ง `"minutes": 20` แทน `days`
- เวลาหมดอายุละเอียดเก็บใน `/etc/xxtlonline/until/<user>` — บริการ `xxtlonline-acct` เช็กทุก 1 วินาที เมื่อถึงเวลาจะตัด connection แล้วสั่ง `xxtlonline cut USER` (ล็อกบัญชี + ตั้งวันหมดอายุเป็นเมื่อวาน) ต่ออายุด้วย `extend` จะล้างเวลาละเอียดและกลับไปนับเป็นวัน
- อัปเดตแล้วรัน `sudo bash install.sh --no-firewall` ทับของเดิม

## ดูว่า user เชื่อมต่ออยู่กี่ IP
- `xxtlonline-ws` บันทึก IP จริงของลูกค้าต่อ connection (อ่าน `CF-Connecting-IP` / `X-Forwarded-For` ถ้าอยู่หลัง CDN — ปิดด้วย `WS_TRUST_HEADERS=0` ใน `/etc/xxtlonline/xxtlonline.conf`) และ `xxtlonline-acct` สรุปลง `/run/xxtlonline/online.json` ทุก 1 วินาที
- API `GET /users` ส่ง `connections`, `online_ips`, `ips` เพิ่มต่อ user — ร้านค้าแสดงในหน้า "ออเดอร์" ของแอดมิน
